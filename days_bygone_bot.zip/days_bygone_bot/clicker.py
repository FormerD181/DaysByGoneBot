"""Days Bygone Clicker: a hidden Tap Titans 2 style mini game.

Type "fun" in the bot window to show/hide it. Tap the enemy to hurt it, kill
10 per stage, then beat the stage boss before the timer runs out. Spend gold on
upgrades, and rewind for Elixir (a permanent boost) once you get far enough.
"""
import glob
import os
import random
import time
import winsound

from PIL import Image, ImageTk

from widgets import (ACCENT, ACCENT_TEXT, DISABLED, GREEN, MUTED, PILL, RED, TEXT,
                     CanvasButton, font, rounded_rect, s)

HERE = os.path.dirname(os.path.abspath(__file__))
ENEMY_DIR = os.path.join(HERE, "assets", "enemies")
SFX_DIR = os.path.join(HERE, "assets", "sfx")
TAG = "clicker"

PURPLE = "#c86cff"
ORANGE = "#ff9a3c"
TIER_COLOR = {"basic": TEXT, "siege": ORANGE, "boss": RED}

# -- balance (all the numbers worth tuning live here) ------------------------
KILLS_PER_STAGE = 10
BOSS_SECONDS = 30
SIEGE_CHANCE = 0.15
HP_BASE, HP_GROWTH = 10, 1.45          # enemy HP = HP_BASE * HP_GROWTH^(stage-1)
HP_MULT = {"basic": 1, "siege": 3, "boss": 10}
GOLD_PER_HP = 1 / 3                     # gold dropped per point of basic enemy HP
GOLD_MULT = {"basic": 1, "siege": 4, "boss": 15}
CRIT_MULT = 8
CRIT_PER_LEVEL, CRIT_CAP = 0.03, 0.60
HERO_DPS_PER_LEVEL = 2
GOLD_BONUS_PER_LEVEL = 0.25
MILESTONE_EVERY = 10                    # every 10 levels of Tap/Heroes doubles them
ELIXIR_BOOST = 0.5                      # each Elixir = +50% damage and gold
ELIXIR_PER_STAGES = 5                   # rewind gives stage // 5 Elixir
REWIND_STAGE = 15                       # earliest stage you can rewind at
AWAY_RATE = 0.5                         # heroes earn at 50% while hidden/closed
AWAY_CAP_HOURS = 8
RESPAWN_DELAY_MS = 160

# key: (label, base cost, cost growth, max level or None)
UPGRADES = {
    "tap":   ("Tap Damage", 5, 1.13, None),
    "hero":  ("Heroes (DPS)", 15, 1.14, None),
    "crit":  ("Crit Chance", 50, 1.80, round(CRIT_CAP / CRIT_PER_LEVEL)),
    "gold":  ("Gold Bonus", 30, 1.55, None),
}

SUFFIXES = ["", "K", "M", "B", "T"] + [a + b for a in "abcdefghijklmnopqrstuvwxyz"
                                        for b in "abcdefghijklmnopqrstuvwxyz"]


def fmt(n):
    """Game-style numbers: 999, 1.23K, 4.56M, ... 7.89aa."""
    n = float(n)
    if n < 1000:
        return f"{n:.0f}"
    i = 0
    while n >= 1000 and i < len(SUFFIXES) - 1:
        n /= 1000
        i += 1
    return f"{n:.2f}{SUFFIXES[i]}"


def new_state():
    return {"stage": 1, "kills": 0, "gold": 0.0, "elixir": 0, "rewinds": 0, "best_stage": 1,
            "boss_failed": False, "sfx": True, "saved_at": 0.0,
            "levels": {k: 0 for k in UPGRADES}}


def clean_state(raw):
    """Turn whatever was saved into a valid state. A missing, old or hand-edited
    save never crashes the game -- bad values just fall back to defaults."""
    st = new_state()
    if not isinstance(raw, dict):
        return st
    for key, default in st.items():
        if key == "levels" or key not in raw:
            continue
        try:
            if isinstance(default, bool):
                st[key] = bool(raw[key])
            elif isinstance(default, int):
                st[key] = max(0, int(raw[key]))
            else:
                st[key] = max(0.0, float(raw[key]))
        except (TypeError, ValueError):
            pass
    levels = raw.get("levels") if isinstance(raw.get("levels"), dict) else {}
    for key in UPGRADES:
        try:
            st["levels"][key] = max(0, int(levels.get(key, 0)))
        except (TypeError, ValueError):
            pass
    st["stage"] = max(1, st["stage"])
    st["kills"] = min(st["kills"], KILLS_PER_STAGE)
    return st


def load_enemies():
    enemies = {}
    for tier in ("basic", "siege", "boss"):
        for path in sorted(glob.glob(os.path.join(ENEMY_DIR, tier, "*.png"))):
            name = os.path.splitext(os.path.basename(path))[0].replace("_", " ").title()
            img = Image.open(path).convert("RGBA")
            enemies.setdefault(tier, []).append((name, img, _palette(img)))
    return enemies


def _palette(img, n=4):
    """A few of the sprite's own colours, for its death particles."""
    small = img.resize((16, 16), Image.NEAREST)
    px = [p[:3] for p in small.getdata() if p[3] > 200 and sum(p[:3]) > 90]
    if not px:
        return ["#ffffff"]
    picks = random.Random(len(px)).sample(px, min(n, len(px)))
    return ["#%02x%02x%02x" % p for p in picks]


class Clicker:
    def __init__(self, root, canvas, box, state, save):
        self.root = root
        self.c = canvas
        self.save_cb = save
        self.visible = False
        self.st = clean_state(state)
        self.away_since = self.st["saved_at"] or None
        self.last_save = time.monotonic()
        self.last_tick = time.monotonic()
        self.last_hit_sound = 0.0
        self.enemies = load_enemies()
        self.photos = {}
        self.enemy = None
        self.respawning = False
        self.boss_mode = False
        self.boss_left = 0.0

        x0, y0, x1, y1 = box
        p = s(18)
        x0, x1, y = x0 + p, x1 - p, y0 + p
        self.x0, self.x1 = x0, x1
        gap = s(8)
        T = (TAG,)

        def text(x, yy, **kw):
            return canvas.create_text(x, yy, tags=T, **kw)

        # Header
        text(x0, y, anchor="nw", text="Days Bygone Clicker", fill=TEXT, font=font(15, True))
        self.stage_txt = text(x1, y, anchor="ne", fill=ACCENT, font=font(15, True))
        y += s(30)
        self.stats_txt = text(x0, y, anchor="nw", fill=MUTED, font=font(9))
        y += s(24)

        # Wave / boss line
        self.wave_txt = text(x0, y + s(11), anchor="w", fill=TEXT, font=font(10, True))
        self.boss_btn = CanvasButton(canvas, (x1 - s(110), y, x1, y + s(24)), "Fight Boss",
                                     self.toggle_boss, size=9, tags=T)
        self.sfx_btn = CanvasButton(canvas, (x1 - s(186), y, x1 - s(118), y + s(24)), "",
                                    self.toggle_sfx, size=9, tags=T)
        y += s(32)
        bh = s(8)
        rounded_rect(canvas, x0, y, x1, y + bh, bh / 2, fill=PILL, outline="", tags=T)
        self.timer_bar = rounded_rect(canvas, x0, y, x0 + bh, y + bh, bh / 2, fill=RED, outline="", tags=T)
        self.timer_y = (y, y + bh)
        y += bh + s(10)

        # Enemy area
        self.name_txt = text((x0 + x1) / 2, y, anchor="n", font=font(12, True))
        y += s(24)
        self.sprite_box = (x0, y, x1, y + s(230))
        self.boss_frame = canvas.create_rectangle(x0 + s(4), y - s(4), x1 - s(4), y + s(234),
                                                  outline=RED, width=s(3), tags=T)
        self.sprite_pos = ((x0 + x1) / 2, y + s(230))
        self.sprite = canvas.create_image(*self.sprite_pos, anchor="s", tags=T)
        canvas.tag_bind(self.sprite, "<Button-1>", self.on_tap)
        canvas.tag_bind(self.sprite, "<Enter>", lambda e: canvas.configure(cursor="hand2"))
        canvas.tag_bind(self.sprite, "<Leave>", lambda e: canvas.configure(cursor=""))
        y += s(240)
        hb = s(14)
        rounded_rect(canvas, x0, y, x1, y + hb, hb / 2, fill=PILL, outline="", tags=T)
        self.hp_bar = rounded_rect(canvas, x0, y, x1, y + hb, hb / 2, fill=GREEN, outline="", tags=T)
        self.hp_y = (y, y + hb)
        self.hp_txt = text((x0 + x1) / 2, y + hb / 2, fill=TEXT, font=font(9, True))
        y += hb + s(16)

        # Upgrades (2 x 2)
        uw = (x1 - x0 - gap) / 2
        uh = s(46)
        self.up_btns = {}
        for i, key in enumerate(UPGRADES):
            bx = x0 + (i % 2) * (uw + gap)
            by = y + (i // 2) * (uh + gap)
            self.up_btns[key] = CanvasButton(canvas, (bx, by, bx + uw, by + uh), "",
                                             lambda k=key: self.buy(k), size=9, tags=T)
        y += 2 * uh + gap + s(12)

        # Rewind
        self.rewind_btn = CanvasButton(canvas, (x0, y, x1, y + s(38)), "", self.rewind, size=11, tags=T)
        y += s(38) + s(8)
        self.tip = text(x0, y, anchor="nw", fill=MUTED, font=font(9), width=x1 - x0)

        # Effect pools: made once, reused, so fast tapping doesn't churn canvas items.
        self.popups = [self._pooled(canvas.create_text(0, 0, font=font(12, True), tags=T)) for _ in range(14)]
        self.slashes = [self._pooled(canvas.create_line(0, 0, 0, 0, width=s(5), fill="#ffffff",
                                                        capstyle="round", tags=T)) for _ in range(4)]
        self.particles = [self._pooled(canvas.create_rectangle(0, 0, 0, 0, outline="", tags=T)) for _ in range(18)]
        self.banner_card = canvas.create_rectangle(0, 0, 0, 0, fill="#101014", width=s(2), tags=T,
                                                   state="hidden")
        self.banner = canvas.create_text((x0 + x1) / 2, self.sprite_box[1] + s(110), font=font(30, True),
                                         tags=T, state="hidden")
        self.banner_sub = canvas.create_text((x0 + x1) / 2, self.sprite_box[1] + s(150), font=font(11, True),
                                             fill=TEXT, tags=T, state="hidden")
        self.banner_job = None
        self.pulse = 0

        self.spawn()
        self.c.itemconfigure(TAG, state="hidden")   # hidden until you type "fun"
        self.root.after(100, self.tick)

    def _pooled(self, item):
        self.c.itemconfigure(item, state="hidden")
        return {"item": item, "busy": False}

    # -- show / hide -------------------------------------------------------
    def show(self):
        self.visible = True
        self.last_tick = time.monotonic()
        self.c.itemconfigure(TAG, state="normal")
        for pool in (self.popups, self.slashes, self.particles):
            for p in pool:
                self.c.itemconfigure(p["item"], state="hidden")
                p["busy"] = False
        self.hide_banner()
        self.refresh()
        self.collect_away_gold()

    def hide(self):
        self.visible = False
        self.c.itemconfigure(TAG, state="hidden")
        self.away_since = time.time()
        self.maybe_save(force=True)

    def toggle(self):
        self.hide() if self.visible else self.show()

    def collect_away_gold(self):
        """Heroes keep fighting while the game is hidden or the bot is closed."""
        if not self.away_since:
            return
        secs = min(time.time() - self.away_since, AWAY_CAP_HOURS * 3600)
        self.away_since = None
        if secs < 30 or not self.dps():
            return
        hp = self.enemy_hp("basic")
        gold = self.dps() / hp * secs * hp * GOLD_PER_HP * self.gold_mult() * AWAY_RATE
        self.st["gold"] += gold
        mins = int(secs // 60)
        away = f"{mins // 60}h {mins % 60}m" if mins >= 60 else f"{mins}m"
        self.show_banner("WELCOME BACK", ACCENT, f"Heroes earned +{fmt(gold)} gold while you were away ({away})")
        self.play("kill")
        self.refresh()
        self.maybe_save(force=True)

    # -- numbers -----------------------------------------------------------
    @property
    def boost(self):
        return 1 + ELIXIR_BOOST * self.st["elixir"]

    def lvl(self, key):
        return self.st["levels"][key]

    def cost(self, key):
        _, base, growth, _ = UPGRADES[key]
        return base * growth ** self.lvl(key)

    def maxed(self, key):
        cap = UPGRADES[key][3]
        return cap is not None and self.lvl(key) >= cap

    def tap_damage(self):
        n = self.lvl("tap")
        return (n + 1) * 2 ** (n // MILESTONE_EVERY) * self.boost

    def dps(self):
        n = self.lvl("hero")
        return n * HERO_DPS_PER_LEVEL * 2 ** (n // MILESTONE_EVERY) * self.boost

    def crit_chance(self):
        return min(CRIT_CAP, CRIT_PER_LEVEL * self.lvl("crit"))

    def gold_mult(self):
        return (1 + GOLD_BONUS_PER_LEVEL * self.lvl("gold")) * self.boost

    def elixir_gain(self):
        return max(1, self.st["stage"] // ELIXIR_PER_STAGES)

    def enemy_hp(self, tier):
        return HP_BASE * HP_GROWTH ** (self.st["stage"] - 1) * HP_MULT[tier]

    # -- enemies -----------------------------------------------------------
    def spawn(self):
        if self.boss_mode:
            tier = "boss"
        else:
            tier = "siege" if random.random() < SIEGE_CHANCE else "basic"
        name, img, palette = random.choice(self.enemies[tier])
        hp = self.enemy_hp(tier)
        self.enemy = {"tier": tier, "name": name, "hp": hp, "max": hp, "palette": palette,
                      "gold": hp / HP_MULT[tier] * GOLD_PER_HP * GOLD_MULT[tier]}
        normal, _ = self._photos(name, img)
        self.c.coords(self.sprite, *self.sprite_pos)
        self.c.itemconfigure(self.sprite, image=normal, state="normal" if self.visible else "hidden")
        self.c.itemconfigure(self.name_txt, text=name + ("  (BOSS)" if tier == "boss" else ""),
                             fill=TIER_COLOR[tier])
        self.respawning = False

    def _photos(self, name, img):
        """Scaled sprite plus a white 'hit flash' version, cached per enemy."""
        if name not in self.photos:
            x0, y0, x1, y1 = self.sprite_box
            scale = min((x1 - x0) / img.width, (y1 - y0) / img.height, s(4))
            size = (max(1, int(img.width * scale)), max(1, int(img.height * scale)))
            big = img.resize(size, Image.NEAREST)
            white = Image.new("RGBA", size, (255, 255, 255, 255))
            flash = Image.composite(Image.blend(big, white, 0.65), big, big.split()[3])
            self.photos[name] = (ImageTk.PhotoImage(big), ImageTk.PhotoImage(flash))
        return self.photos[name]

    def hit(self, dmg):
        if self.respawning:
            return
        self.enemy["hp"] -= dmg
        if self.enemy["hp"] <= 0:
            self.kill()

    def kill(self):
        e = self.enemy
        gold = e["gold"] * self.gold_mult()
        self.st["gold"] += gold
        cx = (self.x0 + self.x1) / 2
        self.burst(e["palette"])
        self.popup((cx, self.sprite_box[1] + s(60)), f"+{fmt(gold)} gold", ACCENT, size=13)
        if e["tier"] == "boss":
            self.boss_mode = False
            self.st["boss_failed"] = False
            self.st["stage"] += 1
            self.st["kills"] = 0
            self.st["best_stage"] = max(self.st["best_stage"], self.st["stage"])
            self.show_banner("STAGE CLEAR", ACCENT, f"On to stage {self.st['stage']}  ·  +{fmt(gold)} gold")
            self.play("stage")
        else:
            self.play("kill")
            self.st["kills"] = min(KILLS_PER_STAGE, self.st["kills"] + 1)
            if self.st["kills"] >= KILLS_PER_STAGE and not self.st["boss_failed"]:
                self.start_boss()
        # Brief gap so the death burst reads before the next enemy pops in.
        self.respawning = True
        self.c.itemconfigure(self.sprite, state="hidden")
        self.root.after(RESPAWN_DELAY_MS, self.spawn)
        self.maybe_save()

    def start_boss(self):
        self.boss_mode = True
        self.boss_left = BOSS_SECONDS
        self.show_banner("BOSS!", RED, f"{BOSS_SECONDS} seconds  ·  {fmt(self.enemy_hp('boss'))} HP")
        self.play("boss")

    def toggle_boss(self):
        if self.respawning:
            return
        if self.boss_mode:          # leave the fight, keep farming
            self.boss_mode = False
            self.st["boss_failed"] = True
        elif self.st["kills"] >= KILLS_PER_STAGE:
            self.st["boss_failed"] = False
            self.start_boss()
        else:
            return
        self.spawn()
        self.refresh()

    # -- actions -----------------------------------------------------------
    def on_tap(self, event):
        if not self.visible or self.respawning:
            return
        crit = random.random() < self.crit_chance()
        dmg = self.tap_damage() * (CRIT_MULT if crit else 1)
        self.popup((event.x + random.randint(-s(24), s(24)), event.y - s(14)),
                   ("CRIT " if crit else "") + fmt(dmg), ACCENT if crit else TEXT, size=16 if crit else 12)
        self.slash(event.x, event.y, crit)
        self.flash()
        self.shake(big=crit)
        self.play("crit" if crit else "hit")
        self.hit(dmg)
        self.refresh()

    def buy(self, key):
        if self.maxed(key) or self.st["gold"] < self.cost(key):
            return
        self.st["gold"] -= self.cost(key)
        self.st["levels"][key] += 1
        self.play("buy")
        self.refresh()
        self.maybe_save(force=True)

    def rewind(self):
        if self.st["stage"] < REWIND_STAGE:
            return
        gain = self.elixir_gain()
        keep = {"elixir": self.st["elixir"] + gain, "rewinds": self.st["rewinds"] + 1,
                "best_stage": self.st["best_stage"], "sfx": self.st["sfx"]}
        self.st = new_state()
        self.st.update(keep)
        self.boss_mode = False
        self.spawn()
        self.show_banner("REWIND", PURPLE, f"+{gain} Elixir  ·  everything x{self.boost:.1f}")
        self.play("stage")
        self.refresh()
        self.maybe_save(force=True)

    def toggle_sfx(self):
        self.st["sfx"] = not self.st["sfx"]
        self.refresh()
        self.maybe_save(force=True)

    def tick(self):
        now = time.monotonic()
        dt = now - self.last_tick
        self.last_tick = now
        if self.visible:
            if self.dps():
                self.hit(self.dps() * dt)
            if self.boss_mode and not self.respawning:
                self.boss_left -= dt
                if self.boss_left <= 0:
                    self.boss_mode = False
                    self.st["boss_failed"] = True
                    self.show_banner("BOSS ESCAPED", RED, "Farm some gold, then press Fight Boss")
                    self.play("fail")
                    self.spawn()
            self.pulse += 1
            self.refresh()
            self.maybe_save()
        self.root.after(100, self.tick)

    # -- effects -----------------------------------------------------------
    def play(self, name):
        if not self.st["sfx"]:
            return
        now = time.monotonic()
        if name == "hit" and now - self.last_hit_sound < 0.06:
            return  # don't machine-gun the hit sound on very fast tapping
        self.last_hit_sound = now
        path = os.path.join(SFX_DIR, name + ".wav")
        if os.path.exists(path):
            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)

    def _take(self, pool):
        for p in pool:
            if not p["busy"]:
                p["busy"] = True
                return p
        return None  # pool exhausted: skip this effect rather than creating more items

    def _release(self, p):
        p["busy"] = False
        self.c.itemconfigure(p["item"], state="hidden")

    def popup(self, xy, text, color, size=12):
        p = self._take(self.popups)
        if not p:
            return
        item = p["item"]
        self.c.coords(item, *xy)
        self.c.itemconfigure(item, text=text, fill=color, font=font(size, True), state="normal")
        self.c.tag_raise(item)

        def rise(step=0):
            if step >= 15 or not self.visible:
                self._release(p)
                return
            self.c.move(item, 0, -s(3))
            self.root.after(40, rise, step + 1)
        rise()

    def slash(self, x, y, crit):
        p = self._take(self.slashes)
        if not p:
            return
        L = s(70 if crit else 50)
        dx = random.choice((-1, 1))
        self.c.coords(p["item"], x - L * dx, y - L * 0.6, x + L * dx, y + L * 0.6)
        self.c.itemconfigure(p["item"], fill=ACCENT if crit else "#ffffff",
                             width=s(7 if crit else 5), state="normal")
        self.c.tag_raise(p["item"])
        self.root.after(70, lambda: self._release(p))

    def flash(self):
        name = self.enemy["name"]
        normal, white = self.photos[name]
        self.c.itemconfigure(self.sprite, image=white)

        def back():
            if self.enemy["name"] == name:
                self.c.itemconfigure(self.sprite, image=normal)
        self.root.after(60, back)

    def shake(self, big=False):
        d = s(7 if big else 4)
        self.c.move(self.sprite, d, 0)
        self.root.after(40, lambda: self.c.move(self.sprite, -2 * d, 0))
        self.root.after(80, lambda: self.c.coords(self.sprite, *self.sprite_pos))

    def burst(self, palette):
        """Pixel particles in the enemy's own colours flying out from its body."""
        cx, cy = self.sprite_pos[0], self.sprite_pos[1] - s(90)
        bits = []
        for p in self.particles:
            if p["busy"]:
                continue
            p["busy"] = True
            size = s(random.randint(6, 12))
            self.c.coords(p["item"], cx, cy, cx + size, cy + size)
            self.c.itemconfigure(p["item"], fill=random.choice(palette), state="normal")
            self.c.tag_raise(p["item"])
            bits.append((p, random.uniform(-9, 9), random.uniform(-11, 3)))

        def fly(step=0):
            if step >= 12 or not self.visible:
                for p, _, _ in bits:
                    self._release(p)
                return
            for p, vx, vy in bits:
                self.c.move(p["item"], s(vx), s(vy + step * 1.4))   # a little gravity
            self.root.after(30, fly, step + 1)
        fly()

    def show_banner(self, text, color, sub=""):
        if self.banner_job:
            self.root.after_cancel(self.banner_job)
        self.c.itemconfigure(self.banner, text=text, fill=color, state="normal")
        self.c.itemconfigure(self.banner_sub, text=sub, state="normal" if sub else "hidden")
        # dark card behind the text so it reads over any sprite
        x0, y0, x1, y1 = self.c.bbox(self.banner)
        if sub:
            bx0, _, bx1, by1 = self.c.bbox(self.banner_sub)
            x0, x1, y1 = min(x0, bx0), max(x1, bx1), by1
        pad = s(12)
        self.c.coords(self.banner_card, max(self.x0, x0 - pad), y0 - pad / 2, min(self.x1, x1 + pad), y1 + pad / 2)
        self.c.itemconfigure(self.banner_card, outline=color, state="normal")
        for item in (self.banner_card, self.banner, self.banner_sub):
            self.c.tag_raise(item)
        self.banner_job = self.root.after(1600, self.hide_banner)

    def hide_banner(self):
        self.banner_job = None
        self.c.itemconfigure(self.banner_card, state="hidden")
        self.c.itemconfigure(self.banner, state="hidden")
        self.c.itemconfigure(self.banner_sub, state="hidden")

    # -- drawing -----------------------------------------------------------
    @staticmethod
    def _rr(x0, y0, x1, y1, r):
        return [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y1 - r, x1, y1,
                x1 - r, y1, x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]

    def _bar(self, item, ys, frac):
        y0, y1 = ys
        h = y1 - y0
        x_end = self.x0 + max(h, (self.x1 - self.x0) * max(0.0, min(1.0, frac)))
        self.c.coords(item, *self._rr(self.x0, y0, x_end, y1, h / 2))

    def refresh(self):
        if not self.visible:
            return
        st, e = self.st, self.enemy
        self.c.itemconfigure(self.stage_txt, text=f"Stage {st['stage']}")
        self.c.itemconfigure(self.stats_txt, text=(
            f"Gold {fmt(st['gold'])}    Tap {fmt(self.tap_damage())}    DPS {fmt(self.dps())}"
            f"    Elixir {st['elixir']} (x{self.boost:.1f})"))
        self.sfx_btn.set_text("Sound: on" if st["sfx"] else "Sound: off")
        self.sfx_btn.style(PILL, TEXT if st["sfx"] else MUTED)

        # wave / boss
        if self.boss_mode:
            self.c.itemconfigure(self.wave_txt, text=f"BOSS FIGHT  {max(0, self.boss_left):.1f}s", fill=RED)
            self.boss_btn.set_text("Leave Boss")
            self.boss_btn.style(PILL, TEXT)
            frac = self.boss_left / BOSS_SECONDS
            self._bar(self.timer_bar, self.timer_y, frac)
            urgent = RED if frac < 0.33 else ORANGE if frac < 0.66 else ACCENT
            self.c.itemconfigure(self.timer_bar, fill=urgent)
            # pulsing frame around the boss, faster when time is short
            on = (self.pulse // (2 if frac < 0.33 else 4)) % 2 == 0
            self.c.itemconfigure(self.boss_frame, state="normal", outline=urgent if on else "#5a1a1a")
        else:
            self.c.itemconfigure(self.boss_frame, state="hidden")
            self.c.itemconfigure(self.wave_txt, text=f"Enemies {st['kills']}/{KILLS_PER_STAGE}", fill=TEXT)
            can_boss = st["kills"] >= KILLS_PER_STAGE
            self.boss_btn.set_text("Fight Boss")
            self.boss_btn.style(RED if can_boss else DISABLED, TEXT if can_boss else MUTED, enabled=can_boss)
            self._bar(self.timer_bar, self.timer_y, st["kills"] / KILLS_PER_STAGE)
            self.c.itemconfigure(self.timer_bar, fill=ACCENT)

        # enemy hp
        frac = max(0.0, e["hp"]) / e["max"]
        self._bar(self.hp_bar, self.hp_y, frac)
        self.c.itemconfigure(self.hp_bar, fill=GREEN if frac > 0.5 else ACCENT if frac > 0.2 else RED)
        self.c.itemconfigure(self.hp_txt, text=f"{fmt(max(0, e['hp']))} / {fmt(e['max'])}")

        # upgrades
        for key, btn in self.up_btns.items():
            label = UPGRADES[key][0]
            if self.maxed(key):
                btn.set_text(f"{label}  Lv{self.lvl(key)}\nMAXED")
                btn.style(PILL, MUTED, enabled=False)
                continue
            btn.set_text(f"{label}  Lv{self.lvl(key)}\n{fmt(self.cost(key))} gold")
            afford = st["gold"] >= self.cost(key)
            btn.style(ACCENT if afford else PILL, ACCENT_TEXT if afford else MUTED, enabled=afford)

        if st["stage"] >= REWIND_STAGE:
            self.rewind_btn.set_text(f"REWIND  (+{self.elixir_gain()} Elixir)")
            self.rewind_btn.style(PURPLE, TEXT)
            tip = "Rewind resets stage, gold and upgrades. Each Elixir = +50% to everything."
        else:
            self.rewind_btn.set_text(f"Rewind unlocks at stage {REWIND_STAGE}")
            self.rewind_btn.style(DISABLED, MUTED, enabled=False)
            tip = f"Best stage: {st['best_stage']}   ·   Rewinds: {st['rewinds']}   ·   type fun to hide"
        self.c.itemconfigure(self.tip, text=tip)

    # -- saving ------------------------------------------------------------
    def maybe_save(self, force=False):
        now = time.monotonic()
        if force or now - self.last_save >= 5.0:
            self.last_save = now
            self.st["saved_at"] = time.time()
            self.save_cb(self.st)
