"""World Tree planner, shown in the right-hand panel of the bot window.

Two pages: your stats (with Find best build / Read from game), then the results.
"""
import tkinter as tk
from tkinter import ttk

import worldtree
from widgets import ACCENT, LOG_BG, MUTED, PILL, TEXT

BG = "#121216"
FIELD_BG = "#26262d"
DEFAULTS = {"apples": "15", "elixir_mastery": "", "max_hp": "2500", "mana": "500",
            "fifteen": "1", "starforce": "0", "max_ascension": "15",
            "mage": False, "smite_push": True, "use_bt": True, "use_gw": True,
            "ea_max": "0", "ea_min": "0", "lb_max": "0", "lb_min": "0", "wt4": "None"}

NUMBER_FIELDS = [
    ("apples", "Apples"),
    ("elixir_mastery", "Elixir Mastery lv"),
    ("max_hp", "Max Health"),
    ("mana", "Mana"),
    ("fifteen", "15★ heroes"),
    ("starforce", "Starforce"),
    ("max_ascension", "Max Ascension"),
]
OPTION_FIELDS = [("mage", "Mage mode"), ("smite_push", "Smite push"), ("use_bt", "Use BT"), ("use_gw", "Use GW")]
SMALL_FIELDS = [("ea_max", "EA max"), ("ea_min", "EA min"), ("lb_max", "LB max"), ("lb_min", "LB min")]


def _button(parent, text, cmd, primary=False):
    return tk.Button(parent, text=text, command=cmd, relief="flat", cursor="hand2", padx=10, pady=4,
                     font=("Segoe UI", 9, "bold" if primary else "normal"),
                     bg=ACCENT if primary else PILL, fg="#111111" if primary else TEXT,
                     activebackground="#ffd84d" if primary else "#3a3a43",
                     activeforeground="#111111" if primary else TEXT)


class WorldTreePanel:
    NEXT_APPLES = 5

    def __init__(self, parent, settings, save, read_from_game=None):
        self.settings = settings
        self.save = save
        self.read_from_game = read_from_game
        self.unread = set()          # fields the game reader couldn't read
        self.on_learn = None         # callback(field, value) to teach the reader
        self.vals = {**DEFAULTS, **settings.get("worldtree", {})}
        self.frame = tk.Frame(parent, bg=BG)
        self.frame.pack(fill="both", expand=True)

        # ---- page 1: stats -------------------------------------------------
        p1 = self.page_stats = tk.Frame(self.frame, bg=BG)
        btns = tk.Frame(p1, bg=BG)
        btns.pack(fill="x", pady=(0, 6))
        _button(btns, "Find best build", self.calculate, primary=True).pack(side="left")
        self.read_btn = _button(btns, "Read from game", self.read_game)
        if read_from_game:
            self.read_btn.pack(side="left", padx=6)
        self.status = tk.Label(p1, text="Tip: press Read from game to fill everything in.", bg=BG, fg=MUTED,
                               font=("Segoe UI", 8), wraplength=350, justify="left", anchor="w")
        self.status.pack(fill="x", pady=(0, 6))

        tk.Label(p1, text="YOUR STATS", bg=BG, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(anchor="w")
        grid = tk.Frame(p1, bg=BG)
        grid.pack(fill="x")
        self.vars, self.entries = {}, {}
        for i, (key, label) in enumerate(NUMBER_FIELDS):
            r, c = divmod(i, 2)
            cell = tk.Frame(grid, bg=BG)
            cell.grid(row=r, column=c, sticky="w", padx=(0, 14), pady=2)
            tk.Label(cell, text=label, bg=BG, fg=TEXT, font=("Segoe UI", 9)).pack(anchor="w")
            v = tk.StringVar(value=str(self.vals[key]))
            e = tk.Entry(cell, textvariable=v, width=14, bg=FIELD_BG, fg=TEXT, insertbackground=TEXT,
                         relief="flat", font=("Segoe UI", 10))
            e.pack(anchor="w", ipady=2)
            self.vars[key], self.entries[key] = v, e
        self.milestone_lbl = tk.Label(grid, text="", bg=BG, fg=ACCENT, font=("Segoe UI", 9, "bold"))
        self.milestone_lbl.grid(row=3, column=1, sticky="sw", pady=(0, 6))
        self.vars["elixir_mastery"].trace_add("write", lambda *a: self._show_milestone())

        tk.Label(p1, text="OPTIONS", bg=BG, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(8, 0))
        opts = tk.Frame(p1, bg=BG)
        opts.pack(anchor="w")
        for i, (key, label) in enumerate(OPTION_FIELDS):
            v = tk.BooleanVar(value=bool(self.vals[key]))
            tk.Checkbutton(opts, text=label, variable=v, bg=BG, fg=TEXT, selectcolor=FIELD_BG,
                           activebackground=BG, activeforeground=TEXT, font=("Segoe UI", 9)
                           ).grid(row=0, column=i, sticky="w", padx=(0, 4))
            self.vars[key] = v
        small = tk.Frame(p1, bg=BG)
        small.pack(anchor="w", pady=(2, 0))
        for i, (key, label) in enumerate(SMALL_FIELDS):
            tk.Label(small, text=label, bg=BG, fg=TEXT, font=("Segoe UI", 9)).grid(row=0, column=2 * i, sticky="w")
            v = tk.StringVar(value=str(self.vals[key]))
            tk.Entry(small, textvariable=v, width=3, bg=FIELD_BG, fg=TEXT, insertbackground=TEXT, relief="flat"
                     ).grid(row=0, column=2 * i + 1, padx=(3, 10))
            self.vars[key] = v
        row = tk.Frame(p1, bg=BG)
        row.pack(anchor="w", pady=(6, 0))
        tk.Label(row, text="WT4 type", bg=BG, fg=TEXT, font=("Segoe UI", 9)).pack(side="left")
        v = tk.StringVar(value=self.vals["wt4"])
        ttk.Combobox(row, textvariable=v, values=list(worldtree.WT4_TYPES), width=14, state="readonly"
                     ).pack(side="left", padx=6)
        self.vars["wt4"] = v

        # ---- page 2: results -----------------------------------------------
        p2 = self.page_results = tk.Frame(self.frame, bg=BG)
        top = tk.Frame(p2, bg=BG)
        top.pack(fill="x", pady=(0, 6))
        _button(top, "◂  Edit stats", lambda: self._page(1)).pack(side="left")
        self.summary = tk.Label(top, text="", bg=BG, fg=MUTED, font=("Segoe UI", 9))
        self.summary.pack(side="left", padx=10)
        box = tk.Frame(p2, bg=BG)
        box.pack(fill="both", expand=True)
        self.out = tk.Text(box, bg=LOG_BG, fg="#d8d8de", relief="flat", font=("Segoe UI", 10), wrap="word",
                           padx=10, pady=8, cursor="arrow")
        sb = tk.Scrollbar(box, command=self.out.yview)
        self.out.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.out.pack(fill="both", expand=True)
        for tag, color in (("head", ACCENT), ("best", "#5fd38a"), ("muted", MUTED), ("err", "#ff6b6b")):
            self.out.tag_configure(tag, foreground=color)
        self.out.tag_configure("head", font=("Segoe UI", 12, "bold"))
        self.out.tag_configure("tab", foreground=TEXT, font=("Segoe UI", 10, "bold"))
        self.out.tag_configure("change", foreground=ACCENT, font=("Segoe UI", 9, "bold"))

        self._show_milestone()
        self._page(1)

    # -- helpers -----------------------------------------------------------
    def _page(self, n):
        (self.page_results if n == 1 else self.page_stats).pack_forget()
        (self.page_stats if n == 1 else self.page_results).pack(fill="both", expand=True)

    def _status(self, text, error=False):
        self.status.config(text=text, fg="#ff6b6b" if error else MUTED)

    def _milestone(self):
        text = self.vars["elixir_mastery"].get().strip()
        if not text:
            return None
        return worldtree.milestone_from_level(worldtree.parse_game_number(text))

    def _show_milestone(self):
        try:
            m = self._milestone()
            self.milestone_lbl.config(text=f"→ Milestone {m}" if m is not None else "", fg=ACCENT)
        except (ValueError, IndexError):
            self.milestone_lbl.config(text="→ can't read (e.g. 5.72ab)", fg="#ff6b6b")

    def _write(self, parts):
        self.out.configure(state="normal")
        self.out.delete("1.0", "end")
        for text, tag in parts:
            self.out.insert("end", text, tag)
        self.out.configure(state="disabled")
        self.out.yview_moveto(0)

    def set_values(self, values):
        """Fill boxes from data read off the game screen."""
        for k, v in values.items():
            if k in self.vars and v is not None:
                self.vars[k].set(v)

    def read_game(self):
        self.read_btn.config(state="disabled", text="Reading...")
        self._status("Reading your stats from the game -- don't touch it for ~30 seconds...")
        self._page(1)
        self.read_from_game(self)

    def apply_read(self, values, error=None):
        """Called with what the game reader found (None = couldn't read)."""
        self.read_btn.config(state="normal", text="Read from game")
        if error:
            self._status(str(error), error=True)
            return
        self.unread = {k for k, v in values.items() if v is None}
        for k, v in values.items():
            self.entries[k].config(bg="#5a2a2a" if v is None else FIELD_BG)
            if v is not None:
                self.vars[k].set(v)
        if self.unread:
            labels = dict(NUMBER_FIELDS)
            self._status("Couldn't read: " + ", ".join(labels[k] for k in self.unread) +
                         " (red boxes) -- type them in, the bot will learn them.", error=True)
        else:
            self._status("Read everything from the game. Check the numbers, then press Find best build.")

    # -- calculate ---------------------------------------------------------
    def calculate(self):
        try:
            vals = {k: v.get() for k, v in self.vars.items()}
            milestone = self._milestone()
            if milestone is None:
                raise ValueError("Enter your Elixir Mastery level (e.g. 5.72ab)")
            num = lambda k: int(float(vals[k]))  # noqa: E731
            res = worldtree.plan_exact(
                num("apples"), milestone, num("max_hp"), num("mana"), num("fifteen"),
                num("max_ascension"), num("starforce"),
                mage=vals["mage"], smite_push=vals["smite_push"], use_bt=vals["use_bt"], use_gw=vals["use_gw"],
                max_ea=num("ea_max"), min_ea=num("ea_min"), lb_max=num("lb_max"), lb_min=num("lb_min"),
                wt4=vals["wt4"])
        except Exception as e:  # noqa: BLE001 - show any input problem
            self._status(str(e), error=True)
            return
        self.settings["worldtree"] = vals
        self.save(self.settings)
        # teach the reader the values it couldn't read
        if self.on_learn:
            for k in list(self.unread):
                if self.on_learn(k, vals[k].strip()):
                    self.unread.discard(k)
                    self.entries[k].config(bg=FIELD_BG)
        self.summary.config(text=f"{vals['apples']} apples  ·  milestone {milestone}")
        self._show(res)
        self._page(2)

    def _show(self, res):
        """Best build for your apples, then the best build for each of the next
        few apples (changes from the build before are marked)."""
        parts = []
        prev = None
        for i, blk in enumerate(res[:1 + self.NEXT_APPLES]):
            if not blk["builds"]:
                continue
            b = max(blk["builds"], key=lambda b: b["days"])
            title = "BEST BUILD" if i == 0 else f"+{i} APPLE{'S' if i > 1 else ''}"
            parts.append((f"{title}\n", "head"))
            parts.append((f"{blk['apples']} apples  ·  {b['days']:.1f} days\n", "muted"))
            by_tab = {}
            for h, n in b["levels"].items():
                by_tab.setdefault(worldtree.NODE_TAB[h], []).append((h, n))
            for tab, skills in by_tab.items():
                parts.append((f"  {tab}\n", "tab"))
                for h, n in skills:
                    parts.append((f"      {worldtree.NODE_NAMES[h]}  {n}", "best"))
                    if prev is not None and prev.get(h, 0) != n:
                        old = prev.get(h, 0)
                        parts.append(("   new" if old == 0 else f"   was {old}", "change"))
                    parts.append(("\n", ""))
            if prev is not None:
                gone = [worldtree.NODE_NAMES[h] for h in prev if h not in b["levels"]]
                if gone:
                    parts.append(("      removed: " + ", ".join(gone) + "\n", "change"))
            parts.append(("\n", ""))
            prev = b["levels"]
        parts.append(("Numbers = how many levels to put in each skill.\n"
                      "Days = how many extra days of campaign progress the build is worth.\n", "muted"))
        self._write(parts)
