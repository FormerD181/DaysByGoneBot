"""World Tree planner window: enter your stats, get the best builds."""
import tkinter as tk
from tkinter import ttk

import worldtree
from widgets import ACCENT, LOG_BG, MUTED, PILL, TEXT

BG = "#18181d"
FIELD_BG = "#26262d"
DEFAULTS = {"apples": "15", "elixir_mastery": "", "max_hp": "2500", "mana": "500",
            "fifteen": "1", "starforce": "0", "max_ascension": "15",
            "mage": False, "smite_push": True, "use_bt": True, "use_gw": True,
            "ea_max": "0", "ea_min": "0", "lb_max": "0", "lb_min": "0", "wt4": "None"}

NUMBER_FIELDS = [
    ("apples", "Apples", "Apples you can spend in the World Tree"),
    ("elixir_mastery", "Elixir Mastery level", "e.g. 5.72ab -- sets your milestone"),
    ("max_hp", "Max Health", "Settings > Journal > Overview"),
    ("mana", "Mana", "Settings > Journal > Overview"),
    ("fifteen", "15★ heroes", "World Tree > Traveller > Ascende Superius"),
    ("starforce", "Starforce", "World Tree > Traveller > Raison D'etre"),
    ("max_ascension", "Max Ascension", "Usually 15"),
]
OPTION_FIELDS = [("mage", "Mage mode"), ("smite_push", "Smite push"), ("use_bt", "Use BT"), ("use_gw", "Use GW")]
SMALL_FIELDS = [("ea_max", "EA max"), ("ea_min", "EA min"), ("lb_max", "LB max"), ("lb_min", "LB min")]


class WorldTreeWindow:
    def __init__(self, root, settings, save, read_from_game=None):
        self.settings = settings
        self.save = save
        self.read_from_game = read_from_game
        self.unread = set()          # fields the game reader couldn't read
        self.on_learn = None         # callback(field, value) to teach the reader
        self.vals = {**DEFAULTS, **settings.get("worldtree", {})}

        w = self.win = tk.Toplevel(root)
        w.title("World Tree Planner")
        w.configure(bg=BG)
        w.geometry("860x560")
        w.minsize(760, 480)

        left = tk.Frame(w, bg=BG)
        left.pack(side="left", fill="y", padx=14, pady=12)
        right = tk.Frame(w, bg=BG)
        right.pack(side="left", fill="both", expand=True, padx=(0, 14), pady=12)

        tk.Label(left, text="Your stats", bg=BG, fg=TEXT, font=("Segoe UI", 13, "bold")).pack(anchor="w")
        self.vars = {}
        self.entries = {}
        for key, label, hint in NUMBER_FIELDS:
            row = tk.Frame(left, bg=BG)
            row.pack(fill="x", pady=3)
            tk.Label(row, text=label, bg=BG, fg=TEXT, width=17, anchor="w", font=("Segoe UI", 10)).pack(side="left")
            v = tk.StringVar(value=str(self.vals[key]))
            e = tk.Entry(row, textvariable=v, width=12, bg=FIELD_BG, fg=TEXT, insertbackground=TEXT,
                         relief="flat", font=("Segoe UI", 10))
            e.pack(side="left")
            self.vars[key] = v
            self.entries[key] = e
            if hint:
                tk.Label(left, text=hint, bg=BG, fg=MUTED, font=("Segoe UI", 8)).pack(anchor="w", padx=(2, 0))
        self.milestone_lbl = tk.Label(left, text="", bg=BG, fg=ACCENT, font=("Segoe UI", 9, "bold"))
        self.milestone_lbl.pack(anchor="w", pady=(2, 6))
        self.vars["elixir_mastery"].trace_add("write", lambda *a: self._show_milestone())

        tk.Label(left, text="Options", bg=BG, fg=TEXT, font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(4, 0))
        opts = tk.Frame(left, bg=BG)
        opts.pack(anchor="w")
        for i, (key, label) in enumerate(OPTION_FIELDS):
            v = tk.BooleanVar(value=bool(self.vals[key]))
            tk.Checkbutton(opts, text=label, variable=v, bg=BG, fg=TEXT, selectcolor=FIELD_BG,
                           activebackground=BG, activeforeground=TEXT, font=("Segoe UI", 9)
                           ).grid(row=i // 2, column=i % 2, sticky="w", padx=(0, 10))
            self.vars[key] = v
        small = tk.Frame(left, bg=BG)
        small.pack(anchor="w", pady=4)
        for i, (key, label) in enumerate(SMALL_FIELDS):
            tk.Label(small, text=label, bg=BG, fg=TEXT, font=("Segoe UI", 9)).grid(row=i // 2, column=(i % 2) * 2,
                                                                                    sticky="w")
            v = tk.StringVar(value=str(self.vals[key]))
            tk.Entry(small, textvariable=v, width=4, bg=FIELD_BG, fg=TEXT, insertbackground=TEXT, relief="flat"
                     ).grid(row=i // 2, column=(i % 2) * 2 + 1, padx=(4, 12), pady=2)
            self.vars[key] = v
        row = tk.Frame(left, bg=BG)
        row.pack(anchor="w", pady=2)
        tk.Label(row, text="WT4 type", bg=BG, fg=TEXT, font=("Segoe UI", 9)).pack(side="left")
        v = tk.StringVar(value=self.vals["wt4"])
        ttk.Combobox(row, textvariable=v, values=list(worldtree.WT4_TYPES), width=13, state="readonly"
                     ).pack(side="left", padx=6)
        self.vars["wt4"] = v

        btns = tk.Frame(left, bg=BG)
        btns.pack(fill="x", pady=(10, 0))
        tk.Button(btns, text="Find best build", command=self.calculate, bg=ACCENT, fg="#111111",
                  relief="flat", font=("Segoe UI", 10, "bold"), padx=10, pady=4).pack(side="left")
        if read_from_game:
            self.read_btn = tk.Button(btns, text="Read from game", command=self.read_game, bg=PILL, fg=TEXT,
                                      relief="flat", font=("Segoe UI", 10), padx=10, pady=4)
            self.read_btn.pack(side="left", padx=8)

        tk.Label(right, text="Best builds", bg=BG, fg=TEXT, font=("Segoe UI", 13, "bold")).pack(anchor="w")
        self.out = tk.Text(right, bg=LOG_BG, fg="#d8d8de", relief="flat", font=("Segoe UI", 10), wrap="word",
                           padx=10, pady=8)
        self.out.pack(fill="both", expand=True)
        for tag, color in (("head", ACCENT), ("best", "#5fd38a"), ("muted", MUTED), ("err", "#ff6b6b")):
            self.out.tag_configure(tag, foreground=color)
        self.out.tag_configure("head", font=("Segoe UI", 12, "bold"))
        self.out.tag_configure("tab", foreground=TEXT, font=("Segoe UI", 10, "bold"))
        self.out.tag_configure("change", foreground=ACCENT, font=("Segoe UI", 9, "bold"))
        self._show_milestone()
        self._write([("Fill in your stats and press  Find best build.\n", "muted")])

    # -- helpers -----------------------------------------------------------
    def _milestone(self):
        text = self.vars["elixir_mastery"].get().strip()
        if not text:
            return None
        return worldtree.milestone_from_level(worldtree.parse_game_number(text))

    def _show_milestone(self):
        try:
            m = self._milestone()
            self.milestone_lbl.config(text=f"Milestone {m}" if m is not None else "", fg=ACCENT)
        except (ValueError, IndexError):
            self.milestone_lbl.config(text="Can't read that level (e.g. 5.72ab)", fg="#ff6b6b")

    def _write(self, parts):
        self.out.configure(state="normal")
        self.out.delete("1.0", "end")
        for text, tag in parts:
            self.out.insert("end", text, tag)
        self.out.configure(state="disabled")

    def set_values(self, values):
        """Fill boxes from data read off the game screen."""
        for k, v in values.items():
            if k in self.vars and v is not None:
                self.vars[k].set(v)

    def read_game(self):
        self.read_btn.config(state="disabled")
        self._write([("Reading your stats from the game -- don't touch it for ~15 seconds...\n", "muted")])
        self.read_from_game(self)

    def apply_read(self, values, error=None):
        """Called with what the game reader found (None = couldn't read)."""
        self.read_btn.config(state="normal")
        if error:
            self._write([(f"{error}\n", "err")])
            return
        self.unread = {k for k, v in values.items() if v is None}
        for k, v in values.items():
            self.entries[k].config(bg="#5a2a2a" if v is None else FIELD_BG)
            if v is not None:
                self.vars[k].set(v)
        labels = dict((k, label) for k, label, _ in NUMBER_FIELDS)
        parts = [("Read from the game:\n", "head")]
        for k, v in values.items():
            parts.append((f"  {labels[k]}: {v}\n", "") if v else
                         (f"  {labels[k]}: couldn't read it -- type it in (the bot will learn it)\n", "err"))
        parts.append(("\nCheck the numbers, then press  Find best build.\n", "muted"))
        self._write(parts)

    # -- calculate ---------------------------------------------------------
    def calculate(self):
        try:
            vals = {k: v.get() for k, v in self.vars.items()}
            milestone = self._milestone()
            if milestone is None:
                raise ValueError("Enter your Elixir Mastery level (e.g. 5.72ab)")
            num = lambda k: int(float(vals[k]))  # noqa: E731
            res = worldtree.plan(
                num("apples"), milestone, num("max_hp"), num("mana"), num("fifteen"),
                num("max_ascension"), num("starforce"),
                mage=vals["mage"], smite_push=vals["smite_push"], use_bt=vals["use_bt"], use_gw=vals["use_gw"],
                max_ea=num("ea_max"), min_ea=num("ea_min"), lb_max=num("lb_max"), lb_min=num("lb_min"),
                wt4=vals["wt4"])
        except Exception as e:  # noqa: BLE001 - show any input problem in the window
            self._write([(f"{e}\n", "err")])
            return
        self.settings["worldtree"] = vals
        self.save(self.settings)
        # teach the reader the values it couldn't read
        if self.on_learn:
            for k in list(self.unread):
                if self.on_learn(k, vals[k].strip()):
                    self.unread.discard(k)
                    self.entries[k].config(bg=FIELD_BG)
        self._show(res)

    NEXT_APPLES = 5

    def _show(self, res):
        """Best build for your apples, then the best build for each of the next
        few apples (changes from the build before are marked)."""
        parts = []
        prev = None
        for i, blk in enumerate(res[:1 + self.NEXT_APPLES]):
            if not blk["builds"]:
                continue
            b = max(blk["builds"], key=lambda b: b["days"])
            title = "BEST BUILD" if i == 0 else f"+{i} APPLE{'S' if i > 1 else ''}"
            parts.append((f"{title}\n", "head"))
            parts.append((f"{blk['apples']} apples  ·  {b['days']:.1f} days\n", "muted"))
            by_tab = {}
            for h, n in b["levels"].items():
                by_tab.setdefault(worldtree.NODE_TAB[h], []).append((h, n))
            for tab, skills in by_tab.items():
                parts.append((f"  {tab}\n", "tab"))
                for h, n in skills:
                    parts.append((f"      {worldtree.NODE_NAMES[h]}  {n}", "best"))
                    if prev is not None and prev.get(h, 0) != n:
                        old = prev.get(h, 0)
                        parts.append(("   new" if old == 0 else f"   was {old}", "change"))
                    parts.append(("\n", ""))
            if prev is not None:
                gone = [worldtree.NODE_NAMES[h] for h in prev if h not in b["levels"]]
                if gone:
                    parts.append(("      removed: " + ", ".join(gone) + "\n", "change"))
            parts.append(("\n", ""))
            prev = b["levels"]
        parts.append(("Numbers = how many levels to put in each skill.\n"
                      "Days = how many extra days of campaign progress the build is worth.\n", "muted"))
        self._write(parts)
