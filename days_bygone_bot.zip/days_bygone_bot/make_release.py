"""Build a release: the shareable zip + latest.json, in the release folder.

    python make_release.py "what changed"

Writes Documents/days_bygone_bot_release/ (a git repo) and commits it.
Publishing is a separate, manual step: open GitHub Desktop and press Push.
"""
import json
import os
import re
import subprocess
import sys
import zipfile

from version import UPDATE_URL, VERSION

HERE = os.path.dirname(os.path.abspath(__file__))
RELEASE_DIR = os.path.join(os.path.dirname(HERE), "days_bygone_bot_release")
ZIP_NAME = "days_bygone_bot.zip"           # fixed name: the repo always holds the newest
SKIP_DIRS = {"debug", "samples", "__pycache__"}
SKIP_FILES = {"settings.json", "settings.bak", "error.log"}


def build_zip(path):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(HERE):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for f in files:
                if f in SKIP_FILES:
                    continue
                p = os.path.join(root, f)
                z.write(p, os.path.join("days_bygone_bot", os.path.relpath(p, HERE)))


def main():
    notes = " ".join(sys.argv[1:]).strip()
    m = re.match(r"https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/latest\.json$", UPDATE_URL)
    if not m or m.group(1) == "YOUR_GITHUB_NAME":
        sys.exit("Set UPDATE_URL in version.py to your GitHub repo first.")
    owner, repo, branch = m.groups()
    os.makedirs(RELEASE_DIR, exist_ok=True)

    build_zip(os.path.join(RELEASE_DIR, ZIP_NAME))
    info = {"version": VERSION,
            "zip": f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{ZIP_NAME}",
            "notes": notes}
    with open(os.path.join(RELEASE_DIR, "latest.json"), "w") as f:
        json.dump(info, f, indent=2)
    with open(os.path.join(RELEASE_DIR, "README.md"), "w") as f:
        f.write(f"# Days Bygone Bot releases\n\nNewest: **v{VERSION}** -- download `{ZIP_NAME}`.\n"
                "Installed bots update themselves from here (Update button).\n")

    def git(*args):
        return subprocess.run(["git", "-C", RELEASE_DIR, *args], capture_output=True, text=True)
    if not os.path.isdir(os.path.join(RELEASE_DIR, ".git")):
        git("init", "-b", branch)
    git("add", "-A")
    r = git("commit", "-m", f"v{VERSION}" + (f": {notes}" if notes else ""))
    print(f"Release v{VERSION} built in {RELEASE_DIR}")
    print(r.stdout.strip() or r.stderr.strip())
    print("Now open GitHub Desktop and press Push to publish it.")


if __name__ == "__main__":
    main()
