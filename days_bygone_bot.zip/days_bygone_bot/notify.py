"""Phone alerts for human checks.

The "phone alert" setting is either
  - an ntfy topic name (e.g. dbg-bot-7f3k2q): install the free ntfy app on the
    phone, subscribe to the same topic, done. Sent to https://ntfy.sh/<topic>.
  - a Discord webhook link (https://discord.com/api/webhooks/...): the alert is
    posted in that channel, so Discord pings the phone.
Sending happens on a background thread so the bot never waits on the network.
"""
import json
import re
import threading
import urllib.request

import netssl

NTFY_SERVER = "https://ntfy.sh/"
DISCORD_HOOK = re.compile(r"^https://(?:ptb\.|canary\.)?discord(?:app)?\.com/api/webhooks/\d+/[\w-]+$")
TOPIC = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def kind(target):
    """'discord', 'ntfy' or None (not usable)."""
    target = (target or "").strip()
    if DISCORD_HOOK.match(target):
        return "discord"
    if TOPIC.match(target):
        return "ntfy"
    return None


def _send(target, title, message, click=None):
    target = target.strip()
    if kind(target) == "discord":
        body = json.dumps({"content": f"**{title}**\n{message}", "username": "Days Bygone Bot"}).encode()
        req = urllib.request.Request(target, data=body, method="POST",
                                     headers={"Content-Type": "application/json", "User-Agent": "DaysBygoneBot"})
    else:
        req = urllib.request.Request(NTFY_SERVER + target, data=message.encode("utf-8"), method="POST",
                                     headers={"Title": title, "Priority": "high", "Tags": "rotating_light",
                                              **({"Click": click} if click else {})})
    netssl.urlopen(req, timeout=15).read()


TAG = ""          # e.g. "[App Player 3] " when several BlueStacks instances are used


def send(target, title, message, done=None, click=None):
    """Send in the background. done(error_text_or_None) is called afterwards
    (from the background thread)."""
    if not kind(target):
        if done:
            done("Not a valid ntfy topic or Discord webhook link")
        return

    title = TAG + title

    def work():
        try:
            _send(target, title, message, click)
            err = None
        except Exception as e:  # noqa: BLE001 - report any network problem
            err = str(e)
        if done:
            done(err)
    threading.Thread(target=work, daemon=True).start()
