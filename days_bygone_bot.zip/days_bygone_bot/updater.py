"""Checks GitHub for a newer version of the bot and installs it.

The release repo holds two files: latest.json  {"version": "1.2", "zip": "<url>", "notes": "..."}
and the zip it points to. See make_release.py.
"""
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

from version import UPDATE_URL, VERSION

HERE = os.path.dirname(os.path.abspath(__file__))
# Never overwritten by an update: the user's own stuff.
KEEP = {"settings.json", "error.log"}
KEEP_DIRS = {"debug", "samples", "__pycache__"}
TIMEOUT = 8


def _ver(v):
    return tuple(int(p) for p in str(v).strip().lstrip("v").split(".") if p.isdigit())


def configured():
    return bool(UPDATE_URL) and "YOUR_GITHUB_NAME" not in UPDATE_URL


def check():
    """Return {"version", "zip", "notes"} if a newer version exists, else None.
    Raises on network/format problems."""
    with urllib.request.urlopen(UPDATE_URL, timeout=TIMEOUT) as r:
        info = json.loads(r.read().decode("utf-8"))
    if not info.get("version") or not info.get("zip"):
        raise ValueError("latest.json is missing 'version' or 'zip'")
    return info if _ver(info["version"]) > _ver(VERSION) else None


def install(info):
    """Download the new zip and copy its files over this folder."""
    with urllib.request.urlopen(info["zip"], timeout=60) as r:
        data = r.read()
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = z.namelist()
        if not any(n.endswith("/version.py") or n == "version.py" for n in names):
            raise ValueError("downloaded file doesn't look like the bot")
        tmp = tempfile.mkdtemp(prefix="dbb_update_")
        try:
            z.extractall(tmp)
            # the zip has one top folder (days_bygone_bot/)
            root = tmp
            entries = os.listdir(tmp)
            if len(entries) == 1 and os.path.isdir(os.path.join(tmp, entries[0])):
                root = os.path.join(tmp, entries[0])
            for dirpath, dirs, files in os.walk(root):
                dirs[:] = [d for d in dirs if d not in KEEP_DIRS]
                rel = os.path.relpath(dirpath, root)
                dest = os.path.join(HERE, rel) if rel != "." else HERE
                os.makedirs(dest, exist_ok=True)
                for f in files:
                    if rel == "." and f in KEEP:
                        continue
                    shutil.copy2(os.path.join(dirpath, f), os.path.join(dest, f))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


def restart():
    """Start a fresh copy of the bot window (the caller then closes itself)."""
    exe = sys.executable
    pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
    if os.path.exists(pyw):
        exe = pyw
    subprocess.Popen([exe, os.path.join(HERE, "ui.py")], cwd=HERE,
                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
