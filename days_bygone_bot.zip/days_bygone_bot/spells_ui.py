"""Spells tool panel: which hot-bar slots to cast while pushing the campaign,
tap or drag for each, and where drags land (a box drawn on a game screenshot)."""
import threading
import tkinter as tk

import cv2
from PIL import Image, ImageTk

from campaign_spells import DEFAULT_AREA, default_slots
from widgets import ACCENT, ACCENT_TEXT, MUTED, PILL, TEXT, CanvasButton, Toggle, font, rounded_rect, s

TOOL_BG = "#121216"
TILE_BG = "#1d1d24"
PICK_W, PICK_H = 960, 540              # area picker picture (half the game's 1920x1080)


class SpellsPanel:
    def __init__(self, parent, width, settings, save, log, root, grab_screen):
        """grab_screen() -> a 1920x1080 BGR game screenshot (runs on a thread)."""
        self.settings, self.save, self.log, self.root = settings, save, log, root
        self.grab_screen = grab_screen
        slots = default_slots()
        slots.update(settings.get("cast_slots") or {})
        settings["cast_slots"] = slots
        self.slots = slots

        c = self.c = tk.Canvas(parent, width=width, height=s(560), bg=TOOL_BG, highlightthickness=0)
        c.pack(anchor="nw")
        x0, x1, y = 0, width - s(4), s(2)
        c.create_text(x0, y + s(12), anchor="w", text="Cast spells while pushing the campaign", fill=TEXT,
                      font=font(10))
        c.create_text(x0, y + s(30), anchor="w", text="When they're off cooldown and you have the mana",
                      fill=MUTED, font=font(8))
        Toggle(c, x1 - s(50), y + s(4), bool(settings.get("cast_spells")), self.on_master)
        y += s(52)
        c.create_line(x0, y, x1, y, fill="#33333c")
        y += s(12)

        self.mode_btns = {}
        for n in range(1, 7):
            key = str(n)
            rounded_rect(c, x0, y, x1, y + s(40), s(10), fill=TILE_BG, outline="")
            c.create_text(x0 + s(12), y + s(20), anchor="w", text=f"Spell {n}", fill=TEXT, font=font(10, True))
            Toggle(c, x0 + s(80), y + s(6), bool(slots[key].get("on")), lambda v, k=key: self.on_slot(k, v))
            bx = x0 + s(144)
            self.mode_btns[key] = {
                m: CanvasButton(c, (bx + i * s(58), y + s(8), bx + i * s(58) + s(54), y + s(32)), label,
                                lambda k=key, m=m: self.on_mode(k, m), size=8)
                for i, (m, label) in enumerate((("tap", "Tap"), ("drag", "Drag")))}
            self.mode_btns[key]["area"] = CanvasButton(c, (x1 - s(96), y + s(8), x1 - s(8), y + s(32)),
                                                       "Set area", lambda k=key: self.pick_area(k), size=8)
            y += s(48)
        y += s(4)
        c.create_text(x0, y, anchor="nw", width=x1 - x0, fill=MUTED, font=font(8),
                      text="Tap = the spell casts with one click (e.g. Tornado).\n"
                           "Drag = drag it onto the enemies: it lands on a random spot inside the "
                           "area you set (Set area -> draw a box on the game picture).\n"
                           "Spell 1 is the left slot of the bar.")
        self._refresh()

    def _refresh(self):
        for key, btns in self.mode_btns.items():
            mode = self.slots[key].get("mode", "drag")
            for m in ("tap", "drag"):
                on = m == mode
                btns[m].style(ACCENT if on else PILL, ACCENT_TEXT if on else TEXT)
            btns["area"].style(PILL, TEXT if mode == "drag" else MUTED, enabled=mode == "drag")

    def on_master(self, value):
        self.settings["cast_spells"] = bool(value)
        self.save(self.settings)
        on = [k for k, v in sorted(self.slots.items()) if v.get("on")]
        self.log("Campaign spells: " + (("casting spell " + ", ".join(on)) if value and on else
                                        "on -- pick which spells below" if value else "off"))

    def on_slot(self, key, value):
        self.slots[key]["on"] = bool(value)
        self.save(self.settings)

    def on_mode(self, key, mode):
        self.slots[key]["mode"] = mode
        self.save(self.settings)
        self._refresh()

    # -- area picker -----------------------------------------------------
    def pick_area(self, key):
        if self.slots[key].get("mode") != "drag":
            return
        self.log("Taking a picture of the game for the area picker...")

        def work():
            try:
                img = self.grab_screen()
            except Exception as e:  # noqa: BLE001 - show any ADB problem
                self.root.after(0, lambda: self.log(f"Couldn't get a game picture: {e}"))
                return
            self.root.after(0, lambda: AreaPicker(self.root, img, key, self.slots, self._saved))
        threading.Thread(target=work, daemon=True).start()

    def _saved(self, keys):
        self.save(self.settings)
        x0, y0, x1, y1 = self.slots[keys[0]]["area"]
        self.log(f"Spell {', '.join(keys)}: drags land in x {x0}-{x1}, y {y0}-{y1}")


class AreaPicker:
    """A window with the game picture: drag a box where the spell should land."""

    def __init__(self, root, img, key, slots, on_save):
        self.slots, self.key, self.on_save = slots, key, on_save
        self.k = PICK_W / img.shape[1]
        w = self.w = tk.Toplevel(root)
        w.title(f"Where should spell {key} land?")
        w.configure(bg=TOOL_BG)
        w.resizable(False, False)
        w.transient(root)
        rgb = cv2.cvtColor(cv2.resize(img, (PICK_W, PICK_H), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
        self.photo = ImageTk.PhotoImage(Image.fromarray(rgb))
        tk.Label(w, text="Drag a box where the spell should land (a random spot inside it each time)",
                 bg=TOOL_BG, fg=TEXT, font=("Segoe UI", 10)).pack(pady=(8, 4))
        c = self.c = tk.Canvas(w, width=PICK_W, height=PICK_H, highlightthickness=0, cursor="crosshair")
        c.pack(padx=8)
        c.create_image(0, 0, anchor="nw", image=self.photo)
        x0, y0, x1, y1 = [v * self.k for v in (slots[key].get("area") or DEFAULT_AREA)]
        self.box = (x0, y0, x1, y1)
        self.rect = c.create_rectangle(x0, y0, x1, y1, outline="#ffd400", width=3, fill="#ffd400",
                                       stipple="gray25")
        c.bind("<ButtonPress-1>", self._down)
        c.bind("<B1-Motion>", self._move)
        bar = tk.Frame(w, bg=TOOL_BG)
        bar.pack(fill="x", pady=8)
        for text, fn in (("Save", self.save), ("Save for every Drag spell", self.save_all), ("Cancel", w.destroy)):
            tk.Button(bar, text=text, command=fn, bg="#2e2e36", fg=TEXT, activebackground="#3a3a44",
                      activeforeground=TEXT, relief="flat", padx=14, pady=4).pack(side="left", padx=8)
        w.grab_set()
        w.focus_force()

    def _down(self, e):
        self.start = (e.x, e.y)
        self.box = (e.x, e.y, e.x, e.y)
        self.c.coords(self.rect, *self.box)

    def _move(self, e):
        x = max(0, min(PICK_W, e.x))
        y = max(0, min(PICK_H, e.y))
        sx, sy = self.start
        self.box = (min(sx, x), min(sy, y), max(sx, x), max(sy, y))
        self.c.coords(self.rect, *self.box)

    def _area(self):
        x0, y0, x1, y1 = (int(round(v / self.k)) for v in self.box)
        if x1 - x0 < 20 or y1 - y0 < 20:          # a click, not a box: small square around it
            cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
            x0, y0, x1, y1 = cx - 40, cy - 40, cx + 40, cy + 40
        # keep drags off the spell bar and the top of the screen
        return [max(0, x0), max(130, y0), min(1919, x1), min(900, y1)]

    def save(self):
        self.slots[self.key]["area"] = self._area()
        self.on_save([self.key])
        self.w.destroy()

    def save_all(self):
        area = self._area()
        keys = [k for k, v in sorted(self.slots.items()) if v.get("mode") == "drag"] or [self.key]
        for k in keys:
            self.slots[k]["area"] = list(area)
        self.on_save(keys)
        self.w.destroy()
