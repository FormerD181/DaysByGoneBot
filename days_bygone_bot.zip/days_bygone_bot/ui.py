"""Control window for the Days Bygone bot."""
import os
import queue
import threading
import sys
import time
import tkinter as tk
import traceback
import ctypes
from tkinter import filedialog

import notify
import sound
from revive_watch import ReviveWatcher
from campaign_spells import SpellWatcher
import dock
import remote
from collections import deque
from daily import Daily
import instances
import updater

from PIL import Image, ImageDraw, ImageTk

from bot import STAT_BUTTONS, Bot, load_settings, save_settings
from clicker import Clicker
from guide_ui import GuidePanel
from heroes_ui import HeroesPanel
from spells_ui import SpellsPanel
from worldtree_ui import WorldTreePanel
from version import VERSION

HERE = os.path.dirname(os.path.abspath(__file__))
BACKGROUND = os.path.join(HERE, "assets", "background.png")
ERROR_LOG = os.path.join(HERE, "error.log")

from widgets import (ACCENT, ACCENT_TEXT, DISABLED, GREEN, LOG_BG, MUTED, PILL, RED, SCALE, TEXT,
                     CanvasButton, RangeSlider, Slider, Toggle, font, rounded_rect, s)
from chrome import BAR_H, BORDER, TitleBar, set_app_icon

TILE_BG = "#1d1d24"
TOOL_BG = "#121216"      # right-hand tool panel

WIDTH, HEIGHT = s(920), s(696)                  # same aspect as the background picture
PANEL = (s(14), s(14), s(396), s(HEIGHT / SCALE - 14))  # dark see-through panel on the left
PAD = s(22)                                     # inner padding of the panel
GAME_PANEL = (s(412), s(14), s(906), s(682))    # hidden clicker game (type "fun")

STAT_LABELS = {"Damage": "Damage", "Gold": "Gold", "Critical Damage": "Crit Damage"}


class App:
    def __init__(self, root):
        self.root = root
        self.settings = load_settings()
        self.logq = queue.Queue()
        self.uiq = queue.Queue()      # calls from other threads, run on the main thread
        root.report_callback_exception = self._tk_error
        self.bot = None
        self.thread = None
        self.stat = self.settings["stat"]
        self.elixir = bool(self.settings["elixir_mastery"])
        self.start_mode = "push"
        self.resume_phase = None   # set after a human check so START continues
        self.alarm_job = None
        self.alarm_started = 0.0

        root.title(f"Days Bygone Bot v{VERSION}")
        set_app_icon(root)
        root.resizable(False, False)
        # Pin the size: when restored from the taskbar, Windows briefly reports
        # the tiny minimised size and Tk would otherwise keep it (blank window).
        total_h = HEIGHT + BAR_H + 1
        root.geometry(f"{WIDTH + 2}x{total_h}")
        root.minsize(WIDTH + 2, total_h)
        root.maxsize(WIDTH + 2, total_h)
        root.configure(bg=BORDER)            # 1px border around the whole window
        self.bar = TitleBar(root, "Days Bygone Bot", VERSION, self.on_close)
        self.bar.c.pack_configure(padx=1, pady=(1, 0))
        self.bar.place_controls(WIDTH)
        self.update_info = None
        self.update_btn = self.bar.add_button("Check for update", self.on_update_click, s(128), tags=("full",))
        self.dock_btn = self.bar.add_button("Attach BlueStacks", self.toggle_dock, s(128), tags=("dockbtn",))
        # which BlueStacks instance this window runs (click: open a window for another one)
        self.instance = instances.current()
        self.multi = len(instances.list_instances()) > 1
        if self.multi:
            short = self.instance["display"].replace("BlueStacks App Player", "Player").replace("BlueStacks", "Main")
            self.inst_btn = self.bar.add_button(f"{short} ▾", self.instance_menu, s(96), tags=("full",))
            notify.TAG = f"[{self.instance['display']}] "
            root.title(f"Days Bygone Bot – {self.instance['display']}")
        # right-click the dock button: compact mode (just the game + this bar)
        self.bar.c.tag_bind("dockbtn", "<Button-3>", lambda e: self.toggle_compact())
        self.compact = False
        self.compact_body = None
        self.dock = dock.BlueStacksDock(root, self._dock_target, self.log)
        root.bind("<Configure>", lambda e: e.widget is root and self.dock.move_now(), add="+")
        self.bar.on_move = self.dock.move_now
        # the moment the bot comes forward (taskbar click, alt-tab), bring BlueStacks with it
        root.bind("<FocusIn>", lambda e: e.widget is root and self.dock.stack(), add="+")
        root.bind("<Activate>", lambda e: self.dock.stack(), add="+")
        self.c = tk.Canvas(root, width=WIDTH, height=HEIGHT, highlightthickness=0, bd=0)
        self.c.pack(padx=1, pady=(0, 1))
        self._draw_background()

        px0, py0, px1, _ = PANEL
        x0, x1 = px0 + PAD, px1 - PAD
        y = py0 + s(20)
        gap = s(8)

        # Status
        dot = s(12)
        self.dot = self.c.create_oval(x0, y + s(6), x0 + dot, y + s(6) + dot, fill=MUTED, outline="")
        self.status_main = self.c.create_text(x0 + s(22), y, anchor="nw", text="Idle", fill=TEXT,
                                              font=font(15, True))
        # Run timer: total time the bot has been running, kept across restarts
        # (pauses on Stop / human check, saved in settings.json)
        self.run_seconds = float(self.settings.get("run_seconds_total", 0))
        self.daily = Daily(self.settings, save_settings)
        self._timer_saved = time.monotonic()
        self._tick_last = time.monotonic()
        self.timer_text = self.c.create_text(x1, y + s(3), anchor="ne", text="0:00:00", fill=MUTED,
                                             font=("Consolas", max(8, s(14)), "bold"))
        self.root.after(500, self._tick_timer)
        y += s(30)
        self.status_sub = self.c.create_text(x0, y, anchor="nw", text="Press Start when the game is open",
                                             fill=MUTED, font=font(9), width=x1 - x0)
        y += s(30)

        # Stat tiles: rewinds and ghost losses
        tw = (x1 - x0 - gap) / 2
        th = s(76)
        self.rewind_tile = self._tile(x0, y, x0 + tw, y + th, "REWINDS")
        self.loss_tile = self._tile(x0 + tw + gap, y, x1, y + th, "GHOST LOSSES")
        CanvasButton(self.c, (x0 + tw - s(52), y + s(8), x0 + tw - s(8), y + s(28)), "Reset",
                     self.reset_counter, size=7)
        self._show_rewinds()
        self._show_losses()
        y += th + s(14)

        # Stat to upgrade
        y = self._section(x0, y, "UPGRADE AFTER MAX DAY")
        bh = s(34)
        self.stat_btns = self._segmented(x0, y, x1, bh, [(n, STAT_LABELS[n]) for n in STAT_BUTTONS],
                                         self.on_stat)
        y += bh + s(14)

        # Elixir toggle
        self.c.create_text(x0, y + s(15), anchor="w", text="Upgrade Elixir Mastery", fill=TEXT, font=font(11))
        self.c.create_text(x0, y + s(34), anchor="w", text="Off = save elixir", fill=MUTED, font=font(8))
        Toggle(self.c, x1 - s(50), y + s(6), self.elixir, self.on_elixir)
        y += s(46)

        # Campaign defeat -> Revive
        self.c.create_text(x0, y + s(15), anchor="w", text="Revive on campaign defeat", fill=TEXT, font=font(11))
        self.c.create_text(x0, y + s(34), anchor="w", text="Off = go back, upgrade + rewind", fill=MUTED, font=font(8))
        Toggle(self.c, x1 - s(50), y + s(6), bool(self.settings.get("auto_revive")), self.on_revive)
        y += s(50)

        # Wasteland: collect the Ticket Usher / Elixir Generator when the map shows them ready
        self.c.create_text(x0, y + s(15), anchor="w", text="Collect in Wasteland", fill=TEXT, font=font(11))
        pw = s(70)
        self.wl_btns = {}
        for i, (key, label) in enumerate((("wl_elixir", "Elixir"), ("wl_tickets", "Tickets"))):
            bx1 = x1 - i * (pw + s(6))
            self.wl_btns[key] = CanvasButton(self.c, (bx1 - pw, y + s(3), bx1, y + s(27)), label,
                                             lambda k=key: self.on_wasteland(k), size=8)
        self._show_wasteland()
        y += s(36) + s(6)

        # Start mode
        y = self._section(x0, y, "WHEN STARTING")
        self.mode_btns = self._segmented(x0, y, x1, bh, [("push", "Push campaign"), ("upgrade", "Upgrade + rewind")],
                                         self.on_mode)
        y += bh + s(18)

        # Start / Stop
        w2 = (x1 - x0 - gap) / 2
        big = s(42)
        self.start_btn = CanvasButton(self.c, (x0, y, x0 + w2, y + big), "START", self.start, size=13)
        self.stop_btn = CanvasButton(self.c, (x0 + w2 + gap, y, x1, y + big), "STOP", self.stop, size=13)
        y += big + s(14)

        # Tools
        y = self._section(x0, y, "TOOLS")
        tools = [("Tree", self.open_worldtree), ("Heroes", self.open_heroes),
                 ("Guide", self.open_guide), ("Alarm", self.open_alarm), ("Rest", self.open_rest),
                 ("Spells", self.open_spells)]
        w4 = (x1 - x0 - gap * (len(tools) - 1)) / len(tools)
        for i, (label, fn) in enumerate(tools):
            bx = x0 + i * (w4 + gap)
            CanvasButton(self.c, (bx, y, bx + w4, y + s(32)), label, fn, size=9)
        y += s(32) + s(12)

        # Log
        self.logbox = tk.Text(self.c, bg=LOG_BG, fg="#cfcfd6", relief="flat", bd=0, highlightthickness=0,
                              font=("Consolas", max(7, s(9))), wrap="word", padx=s(10), pady=s(8),
                              state="disabled", cursor="arrow")
        self.c.create_window(x0, y, anchor="nw", window=self.logbox,
                             width=x1 - x0, height=PANEL[3] - s(18) - y)

        # Hidden clicker game on the right: type "fun" to show/hide it.
        self.game = Clicker(root, self.c, GAME_PANEL, self.settings.get("clicker_tt"), self.save_game)
        self.keybuf = ""
        root.bind("<Key>", self.on_key, add="+")

        self._style_dropdowns()
        self.tool = None              # which tool is open in the right panel
        self._build_tool_panel()
        self._refresh_choices()
        self._set_running(False)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.drain_log)
        root.after(1500, self.check_update)      # quiet check on launch
        root.after(2500, self._update_revive_watch)
        self.remote = None
        root.after(3000, self._update_remote)
        root.after(700, self._make_visible)       # launched behind/minimized? bring it forward
        root.after(2500, self._make_visible)
        root.after(5000, self._check_daily)
        root.after(1200, self._dock_startup)
        # Clicking anywhere in the window silences the alarm.
        self.c.bind("<Button-1>", self._click_silences, add="+")

    # -- drawing -----------------------------------------------------------
    def _draw_background(self):
        try:
            bg = Image.open(BACKGROUND).convert("RGBA").resize((WIDTH, HEIGHT), Image.LANCZOS)
        except OSError:
            bg = Image.new("RGBA", (WIDTH, HEIGHT), (30, 30, 36, 255))
        shade = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
        draw = ImageDraw.Draw(shade)
        draw.rounded_rectangle(PANEL, radius=s(18), fill=(14, 14, 18, 232))
        base = Image.alpha_composite(bg, shade)
        draw.rounded_rectangle(GAME_PANEL, radius=s(18), fill=(18, 18, 22, 255))
        with_game = Image.alpha_composite(bg, shade)
        self._bg_photo = ImageTk.PhotoImage(base)
        self._bg_game_photo = ImageTk.PhotoImage(with_game)
        self.bg_item = self.c.create_image(0, 0, anchor="nw", image=self._bg_photo)

    def _section(self, x, y, title):
        self.c.create_text(x, y, anchor="nw", text=title, fill=MUTED, font=font(8, True))
        return y + s(20)

    def _tile(self, x0, y0, x1, y1, label):
        """A small stat card: label, big number, small detail line."""
        rounded_rect(self.c, x0, y0, x1, y1, s(12), fill=TILE_BG, outline="")
        self.c.create_text(x0 + s(12), y0 + s(10), anchor="nw", text=label, fill=MUTED, font=font(7, True))
        big = self.c.create_text(x0 + s(12), y0 + s(30), anchor="nw", text="", fill=TEXT, font=font(16, True))
        small = self.c.create_text(x0 + s(12), y1 - s(9), anchor="sw", text="", fill=MUTED, font=font(8))
        return big, small

    def _segmented(self, x0, y, x1, h, options, on_pick):
        """Pill-style option group: a dark track with one highlighted choice."""
        rounded_rect(self.c, x0, y, x1, y + h, s(12), fill=TILE_BG, outline="")
        pad = s(3)
        w = (x1 - x0 - 2 * pad) / len(options)
        btns = {}
        for i, (key, label) in enumerate(options):
            bx = x0 + pad + i * w
            btns[key] = CanvasButton(self.c, (bx, y + pad, bx + w, y + h - pad), label,
                                     lambda k=key: on_pick(k), size=10)
        return btns

    def _refresh_choices(self):
        for name, btn in self.stat_btns.items():
            btn.style(*((ACCENT, ACCENT_TEXT) if name == self.stat else (TILE_BG, TEXT)))
        if getattr(self, "rest_c", None) is not None and self.tool == "rest":
            self._refresh_rest()
        running = self.is_running()
        for mode, btn in self.mode_btns.items():
            if mode == self.start_mode:
                btn.style(ACCENT, ACCENT_TEXT, enabled=not running)
            else:
                btn.style(TILE_BG, TEXT if not running else MUTED, enabled=not running)

    def _set_running(self, running):
        for start, stop in [(self.start_btn, self.stop_btn)] + ([self.mini_btns] if getattr(self, "mini_btns", None) else []):
            start.style(DISABLED if running else GREEN, MUTED if running else TEXT, enabled=not running)
            stop.style(RED if running else DISABLED, TEXT if running else MUTED, enabled=running)
        if self.resume_phase and not running:
            self.c.itemconfigure(self.dot, fill=RED)
            self.c.itemconfigure(self.status_main, text="Human check!", fill=RED)
            self.c.itemconfigure(self.status_sub, text="Answer it in the game yourself, then press START")
        else:
            self.c.itemconfigure(self.dot, fill=GREEN if running else MUTED)
            self.c.itemconfigure(self.status_main, text="Running" if running else "Idle", fill=TEXT)
            if not running:
                self.c.itemconfigure(self.status_sub, text="Press Start when the game is open")
        self._refresh_choices()

    def _tick_timer(self):
        now = time.monotonic()
        running = self.is_running()
        if running:
            self.run_seconds += now - self._tick_last
            self.daily.add("run_seconds", now - self._tick_last)
            if now - self._timer_saved > 30:
                self._save_timer()
        self._tick_last = now
        sec = int(self.run_seconds)
        self.c.itemconfigure(self.timer_text, text=f"{sec // 3600}:{sec // 60 % 60:02d}:{sec % 60:02d}",
                             fill=TEXT if running else MUTED)
        if getattr(self, "mini_timer", None):
            self.bar.c.itemconfigure(self.mini_timer, text=f"{sec // 3600}:{sec // 60 % 60:02d}:{sec % 60:02d}",
                                     fill=TEXT if running else MUTED)
        self.root.after(500, self._tick_timer)

    def _save_timer(self):
        self.settings["run_seconds_total"] = int(self.run_seconds)
        save_settings(self.settings)
        self._timer_saved = time.monotonic()

    # -- rewind counters ---------------------------------------------------
    def _show_rewinds(self):
        big, small = self.rewind_tile
        self.c.itemconfigure(big, text=f"{self.settings['rewinds_total']:,}")
        self.c.itemconfigure(small, text=f"this session: {self.settings['rewinds_counter']:,}")

    def on_rewind(self):
        """Called from the bot thread each time a rewind is confirmed."""
        self.call_soon(self._add_rewind)

    def _add_rewind(self):
        self.daily.add("rewinds")
        self.settings["rewinds_total"] += 1
        self.settings["rewinds_counter"] += 1
        save_settings(self.settings)
        self._show_rewinds()

    # -- ghost loss streak -------------------------------------------------
    def _show_losses(self):
        st = self.settings
        big, small = self.loss_tile
        self.c.itemconfigure(big, text=f"{st['ghost_loss_streak']} in a row",
                             fill=RED if st["ghost_loss_streak"] >= 3 else TEXT)
        self.c.itemconfigure(small, text=f"longest {st['ghost_loss_streak_best']}  ·  total {st['ghost_losses_total']}")

    def on_ghost_result(self, won):
        """Called from the bot thread when a ghost battle is won or lost."""
        self.call_soon(self._add_ghost_result, won)

    def _add_ghost_result(self, won):
        self.daily.add("ghost_wins" if won else "ghost_losses")
        st = self.settings
        if won:
            st["ghost_loss_streak"] = 0
        else:
            st["ghost_losses_total"] += 1
            st["ghost_loss_streak"] += 1
            st["ghost_loss_streak_best"] = max(st["ghost_loss_streak_best"], st["ghost_loss_streak"])
        save_settings(st)
        self._show_losses()

    def reset_counter(self):
        self.settings["rewinds_counter"] = 0
        save_settings(self.settings)
        self._show_rewinds()
        self.log("Rewind counter reset (total kept)")

    # -- human check alert -------------------------------------------------
    def on_check(self, phase):
        """Called from the bot thread when the game shows a human check."""
        self.call_soon(self._alert, phase)

    def _alert(self, phase):
        self.daily.add("human_checks")
        # free the game window so the check can be answered at full size
        if self.dock.attached and self.settings.get("detach_on_check", True):
            self.toggle_dock()
            self._reattach_on_start = True
        self.resume_phase = phase
        self._set_running(self.is_running())
        # Pop the window to the front and flash it on the taskbar.
        self.bar.restore()
        self.root.attributes("-topmost", True)
        self.root.after(1500, lambda: self.root.attributes("-topmost", False))
        self._flash_taskbar()
        self.start_alarm()
        self._phone_alert(phase)

    # -- alarm sound -------------------------------------------------------
    ALARM_SECONDS = 3

    def start_alarm(self):
        self.stop_alarm()
        vol = self.settings.get("alert_volume", 100)
        if not sound.play(self.settings.get("alert_sound"), loop=True, volume=vol):
            sound.play(None, loop=True, volume=vol)  # custom file failed -> built-in alarm
        self.alarm_job = self.root.after(self.ALARM_SECONDS * 1000, self.stop_alarm)
        self.alarm_started = time.monotonic()

    def _click_silences(self, event):
        # The click that pressed Test also reaches the window -- don't let it
        # cancel the sound it just started.
        if time.monotonic() - self.alarm_started > 0.3:
            self.stop_alarm()

    def open_alarm(self):
        """Human-check alarm settings (sound file, test, volume) in the right panel."""
        body = self._open_tool("alarm", "Human check alarm")
        if body is None:
            return
        cw = self.tool_w
        c = self.alarm_c = tk.Canvas(body, width=cw, height=s(860), bg=TOOL_BG, highlightthickness=0)
        c.pack(anchor="nw")
        x0, x1, y = 0, cw - s(4), s(4)
        c.create_text(x0, y, anchor="nw", fill=MUTED, font=font(9), width=x1 - x0,
                      text="Plays for 3 seconds when the game shows a human check, so you can answer it.")
        y += s(44)
        self.sound_label = c.create_text(x0, y, anchor="nw", text="", fill=TEXT, font=font(10), width=x1 - x0)
        self._show_sound()
        y += s(28)
        gap = s(8)
        w3 = (x1 - x0 - 2 * gap) / 3
        for i, (label, fn) in enumerate((("Choose…", self.choose_sound), ("Test", self.test_sound),
                                         ("Default", self.default_sound))):
            bx = x0 + i * (w3 + gap)
            CanvasButton(c, (bx, y, bx + w3, y + s(32)), label, fn, size=9)
        y += s(32) + s(28)
        c.create_text(x0, y, anchor="w", text="Volume", fill=TEXT, font=font(10))
        self.volume_label = c.create_text(x1, y, anchor="e", fill=MUTED, font=font(10),
                                          text=f"{self.settings['alert_volume']}%")
        self.volume = Slider(c, x0 + s(70), y, x1 - s(48), self.settings["alert_volume"], self.on_volume)
        y += s(24)
        c.create_text(x0, y + s(12), anchor="w", text="Detach BlueStacks on human check", fill=TEXT, font=font(10))
        c.create_text(x0, y + s(30), anchor="w", text="So you can answer it full size (attaches again on START)",
                      fill=MUTED, font=font(8))
        Toggle(c, x1 - s(50), y + s(4), bool(self.settings.get("detach_on_check", True)), self.on_detach_on_check)
        y += s(30)

        # -- phone alert --
        y += s(40)
        c.create_line(x0, y, x1, y, fill="#33333c")
        y += s(14)
        c.create_text(x0, y, anchor="nw", text="Phone alert", fill=TEXT, font=font(11, "bold"))
        y += s(26)
        c.create_text(x0, y, anchor="nw", fill=MUTED, font=font(9), width=x1 - x0,
                      text="Also ping your phone when a human check shows up. Easiest: install the free "
                           "\"ntfy\" app, subscribe to a made-up topic name (hard to guess, like "
                           "dbg-bot-7f3k2q) and type the same name here. Or paste a Discord webhook link "
                           "from your own server.")
        y += s(72)
        self.phone_var = tk.StringVar(value=self.settings.get("phone_alert", ""))
        entry = tk.Entry(c, textvariable=self.phone_var, bg="#26262d", fg=TEXT, insertbackground=TEXT,
                         relief="flat", font=("Segoe UI", max(8, s(10))))
        c.create_window(x0, y, anchor="nw", window=entry, width=x1 - x0, height=s(28))
        y += s(38)
        w2 = (x1 - x0 - gap) / 2
        CanvasButton(c, (x0, y, x0 + w2, y + s(32)), "Save", self.save_phone, size=9)
        CanvasButton(c, (x0 + w2 + gap, y, x1, y + s(32)), "Send test", self.test_phone, size=9)
        y += s(44)
        self.phone_status = c.create_text(x0, y, anchor="nw", fill=MUTED, font=font(9), width=x1 - x0,
                                          text=self._phone_status_text())

        # -- daily summary --
        y += s(40)
        c.create_line(x0, y, x1, y, fill="#33333c")
        y += s(14)
        c.create_text(x0, y + s(12), anchor="w", text="Daily summary at 8:00 AM", fill=TEXT, font=font(11, "bold"))
        c.create_text(x0, y + s(32), anchor="w", text="Sent to the phone alert above (game reset)",
                      fill=MUTED, font=font(8))
        Toggle(c, x1 - s(50), y + s(4), bool(self.settings.get("daily_summary", True)), self.on_daily_toggle)
        y += s(52)
        CanvasButton(c, (x0, y, x1, y + s(32)), "Send today's summary now", self.send_daily_now, size=9)

        # -- phone remote --
        y += s(46)
        c.create_line(x0, y, x1, y, fill="#33333c")
        y += s(14)
        c.create_text(x0, y + s(12), anchor="w", text="Phone remote", fill=TEXT, font=font(11, "bold"))
        c.create_text(x0, y + s(32), anchor="w", text="See the game + answer checks from your phone",
                      fill=MUTED, font=font(8))
        Toggle(c, x1 - s(50), y + s(4), bool(self.settings.get("remote_on")), self.on_remote_toggle)
        y += s(50)
        c.create_text(x0, y + s(14), anchor="w", text="PIN", fill=TEXT, font=font(10))
        self.pin_var = tk.StringVar(value=str(self.settings.get("remote_pin", "")))
        pin = tk.Entry(c, textvariable=self.pin_var, bg="#26262d", fg=TEXT, insertbackground=TEXT,
                       relief="flat", font=("Segoe UI", max(8, s(10))), show="•")
        c.create_window(x0 + s(40), y, anchor="nw", window=pin, width=s(110), height=s(28))
        CanvasButton(c, (x0 + s(160), y, x1, y + s(28)), "Save PIN", self.save_pin, size=9)
        y += s(40)
        self.remote_txt = c.create_text(x0, y, anchor="nw", fill=MUTED, font=font(9), width=x1 - x0, text="")
        self._show_remote()
        # the panel is taller than the space: scroll it with the mouse wheel
        c.configure(scrollregion=(0, 0, cw, y + s(90)))
        c.pack_configure(fill="both", expand=True)
        wheel = lambda e: c.yview_scroll(-1 if e.delta > 0 else 1, "units")
        c.bind("<Enter>", lambda e: c.bind_all("<MouseWheel>", wheel))
        c.bind("<Leave>", lambda e: c.unbind_all("<MouseWheel>"))

    # -- daily summary -------------------------------------------------------
    def on_bot_event(self, key, value=None):
        """Called from the bot thread: things to count for the daily summary."""
        if key == "day":
            self.daily.saw_day(value)
        elif key == "stuck":
            target = self.settings.get("phone_alert", "")
            if target:
                notify.send(target, "Days Bygone Bot: looks stuck",
                            f"The game screen hasn't changed for 10 minutes ({value}). Check on it.",
                            done=lambda err: err and self.call_soon(self.log, f"Phone alert failed: {err}"))
        else:
            self.daily.add(key)

    def on_detach_on_check(self, value):
        self.settings["detach_on_check"] = bool(value)
        save_settings(self.settings)
        self.log("Human check: " + ("detach BlueStacks" if value else "leave BlueStacks attached"))

    def on_remote_toggle(self, value):
        self.settings["remote_on"] = bool(value)
        save_settings(self.settings)
        self._update_remote()

    def save_pin(self):
        pin = self.pin_var.get().strip()
        if len(pin) < 4:
            self._show_remote("PIN must be at least 4 characters.")
            return
        self.settings["remote_pin"] = pin
        save_settings(self.settings)
        self._update_remote()

    def _show_remote(self, note=None):
        if self.tool != "alarm" or getattr(self, "alarm_c", None) is None or not hasattr(self, "remote_txt"):
            return
        if note:
            text = note
        elif not self.settings.get("remote_on"):
            text = "Off."
        elif len(str(self.settings.get("remote_pin", ""))) < 4:
            text = "Set a PIN (4+ characters) to turn it on."
        elif self.remote is None:
            text = "Couldn't start -- see the log."
        else:
            urls = self.remote.urls()
            text = "Open on your phone:\n" + "\n".join(f"{n}:  {u}" for n, u in urls)
            if not any(n.startswith("Anywhere") for n, _ in urls):
                text += "\n(For use away from home, sign in to Tailscale on this PC and your phone.)"
        try:
            self.alarm_c.itemconfigure(self.remote_txt, text=text)
        except tk.TclError:
            pass

    def on_daily_toggle(self, value):
        self.settings["daily_summary"] = bool(value)
        save_settings(self.settings)
        self.log("Daily summary " + ("on (8:00 AM)" if value else "off"))

    def _check_daily(self):
        """At the 8:00 AM reset: send yesterday's summary and start counting again.
        If the PC was off at 8:00, it's sent the next time the bot is opened."""
        try:
            if self.daily.due():
                msg = self.daily.message()
                target = self.settings.get("phone_alert", "")
                if self.settings.get("daily_summary", True) and target:
                    notify.send(target, "Days Bygone Bot: daily summary", msg,
                                done=lambda err: self.call_soon(
                                    self.log, "Daily summary sent" if not err else f"Daily summary failed: {err}"))
                self.log("New game day -- daily counts reset")
                self.daily.roll()
            else:
                save_settings(self.settings)       # keep today's counts if the PC is turned off
        finally:
            self.root.after(60 * 1000, self._check_daily)

    def send_daily_now(self):
        target = self.settings.get("phone_alert", "")
        if not target:
            self._set_phone_status("Set up the phone alert first (above).")
            return
        self._set_phone_status("Sending summary…")
        notify.send(target, "Days Bygone Bot: summary so far", self.daily.message(),
                    done=lambda err: self.call_soon(
                        self._set_phone_status, "Summary sent -- check your phone." if not err else f"Failed: {err}"))

    # -- phone alert -------------------------------------------------------
    def _phone_status_text(self):
        target = self.settings.get("phone_alert", "")
        k = notify.kind(target)
        if not target:
            return "Off."
        return {"ntfy": f"On: ntfy topic \"{target}\".", "discord": "On: Discord webhook."}.get(k, "Not valid.")

    def _set_phone_status(self, text):
        if self.tool == "alarm" and getattr(self, "alarm_c", None):
            try:
                self.alarm_c.itemconfigure(self.phone_status, text=text)
            except tk.TclError:
                pass

    def save_phone(self):
        target = self.phone_var.get().strip()
        if target and not notify.kind(target):
            self._set_phone_status("That's not an ntfy topic (letters, numbers, - and _) "
                                   "or a Discord webhook link -- not saved.")
            return
        self.settings["phone_alert"] = target
        save_settings(self.settings)
        self._set_phone_status(self._phone_status_text())
        self.log("Phone alert " + ("saved" if target else "turned off"))

    def test_phone(self):
        self.save_phone()
        target = self.settings.get("phone_alert", "")
        if not target:
            self._set_phone_status("Type a topic or webhook first.")
            return
        self._set_phone_status("Sending test…")
        notify.send(target, "Days Bygone Bot", "Test alert -- phone alerts are working.",
                    done=lambda err: self.call_soon(
                        self._set_phone_status, "Test sent -- check your phone." if not err else f"Failed: {err}"))

    def _phone_alert(self, phase):
        target = self.settings.get("phone_alert", "")
        if not target:
            return
        link = self.remote_link()
        notify.send(target, "Human check!",
                    "The game is showing a human check. Answer it, then press START in the bot."
                    + (f"\nAnswer from your phone: {link}" if link else ""), click=link or None,
                    done=lambda err: err and self.call_soon(self.log, f"Phone alert failed: {err}"))

    # -- right-hand tool panel ---------------------------------------------------
    def _style_dropdowns(self):
        """Dark dropdowns to match the panels."""
        from tkinter import ttk
        st = ttk.Style(self.root)
        st.theme_use("clam")
        st.configure("TCombobox", fieldbackground="#26262d", background="#26262d", foreground=TEXT,
                     arrowcolor=TEXT, bordercolor="#26262d", lightcolor="#26262d", darkcolor="#26262d",
                     selectbackground="#26262d", selectforeground=TEXT)
        st.map("TCombobox", fieldbackground=[("readonly", "#26262d"), ("disabled", "#1d1d24")],
               foreground=[("disabled", MUTED)], selectbackground=[("readonly", "#26262d")])
        self.root.option_add("*TCombobox*Listbox.background", "#1d1d24")
        self.root.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.root.option_add("*TCombobox*Listbox.selectBackground", ACCENT)
        self.root.option_add("*TCombobox*Listbox.selectForeground", "#111111")

    def _build_tool_panel(self):
        """The right side shows one tool at a time (World Tree, Day Guide, Alarm),
        in the same space as the hidden clicker game."""
        gx0, gy0, gx1, gy1 = GAME_PANEL
        pad = s(16)
        self.tool_w = gx1 - gx0 - 2 * pad
        box = self.tool_box = tk.Frame(self.c, bg=TOOL_BG)
        head = tk.Frame(box, bg=TOOL_BG)
        head.pack(fill="x", pady=(0, s(10)))
        self.tool_title = tk.Label(head, text="", bg=TOOL_BG, fg=TEXT, font=("Segoe UI", max(9, s(14)), "bold"))
        self.tool_title.pack(side="left")
        x = tk.Label(head, text="✕", bg=TOOL_BG, fg=MUTED, font=("Segoe UI", max(9, s(13))), cursor="hand2", padx=6)
        x.pack(side="right")
        x.bind("<Button-1>", lambda e: self.close_tool())
        x.bind("<Enter>", lambda e: x.config(fg=TEXT))
        x.bind("<Leave>", lambda e: x.config(fg=MUTED))
        self.tool_body = tk.Frame(box, bg=TOOL_BG)
        self.tool_body.pack(fill="both", expand=True)
        self.tool_item = self.c.create_window(gx0 + pad, gy0 + pad, anchor="nw", window=box,
                                              width=self.tool_w, height=gy1 - gy0 - 2 * pad, state="hidden")

    def _open_tool(self, key, title):
        """Show the panel for a tool. Returns its (empty) body frame, or None if
        that tool was already open (clicking its button again closes it)."""
        if self.tool == key:
            self.close_tool()
            return None
        if self.game.visible:
            self.game.hide()
        for child in self.tool_body.winfo_children():
            child.destroy()
        self.tool = key
        self.tool_title.config(text=title)
        self.c.itemconfigure(self.tool_item, state="normal")
        self._place_tool_panel()
        self.c.itemconfigure(self.bg_item, image=self._bg_game_photo)
        return self.tool_body

    def close_tool(self):
        self.tool = None
        for child in self.tool_body.winfo_children():
            child.destroy()
        self.c.itemconfigure(self.tool_item, state="hidden")
        self.c.itemconfigure(self.bg_item, image=self._bg_game_photo if self.game.visible else self._bg_photo)

    def on_volume(self, value):
        self.settings["alert_volume"] = value
        if self.tool == "alarm":
            self.alarm_c.itemconfigure(self.volume_label, text=f"{value}%")
        sound.set_volume(value)  # live if the alarm is playing
        self._save_volume_later()

    def _save_volume_later(self):
        # Dragging fires many events; save once the slider settles.
        if getattr(self, "_vol_job", None):
            self.root.after_cancel(self._vol_job)
        self._vol_job = self.root.after(400, lambda: save_settings(self.settings))

    def stop_alarm(self):
        if self.alarm_job:
            self.root.after_cancel(self.alarm_job)
            self.alarm_job = None
            sound.stop()

    def _show_sound(self):
        path = self.settings.get("alert_sound") or ""
        name = os.path.basename(path) if path and os.path.exists(path) else "Built-in alarm"
        if len(name) > 40:
            name = name[:37] + "…"
        if self.tool == "alarm":
            self.alarm_c.itemconfigure(self.sound_label, text="Sound: " + name)

    def choose_sound(self):
        path = filedialog.askopenfilename(
            title="Pick an alarm sound",
            filetypes=[("Sound files", "*.wav *.mp3 *.wma"), ("All files", "*.*")])
        if not path:
            return
        if not path.lower().endswith(sound.SUPPORTED):
            self.log("That file type isn't supported -- use .wav, .mp3 or .wma")
            return
        self.settings["alert_sound"] = path
        save_settings(self.settings)
        self._show_sound()
        self.log(f"Alarm sound set to {os.path.basename(path)}")

    def default_sound(self):
        self.settings["alert_sound"] = ""
        save_settings(self.settings)
        self._show_sound()
        self.log("Alarm sound reset to the built-in alarm")

    def test_sound(self):
        path = self.settings.get("alert_sound")
        if path and os.path.exists(path) and not sound.play(path, volume=0):
            self.log("Couldn't play that sound file -- the built-in alarm will be used")
        self.start_alarm()

    def _flash_taskbar(self):
        class FLASHWINFO(ctypes.Structure):
            _fields_ = [("cbSize", ctypes.c_uint), ("hwnd", ctypes.c_void_p), ("dwFlags", ctypes.c_uint),
                        ("uCount", ctypes.c_uint), ("dwTimeout", ctypes.c_uint)]
        try:
            hwnd = int(self.root.frame(), 16)
            # FLASHW_ALL | FLASHW_TIMERNOFG: flash until the window is focused.
            info = FLASHWINFO(ctypes.sizeof(FLASHWINFO), hwnd, 0x3 | 0xC, 0, 0)
            ctypes.windll.user32.FlashWindowEx(ctypes.byref(info))
        except (AttributeError, OSError):
            pass

    # -- events ------------------------------------------------------------
    def on_stat(self, name):
        self.stat = name
        self.settings["stat"] = name
        save_settings(self.settings)
        self._refresh_choices()
        self.log(f"Will upgrade: {name}")

    def on_wasteland(self, key):
        self.settings[key] = not self.settings.get(key)
        save_settings(self.settings)
        self._show_wasteland()
        want = [n for k, n in (("wl_tickets", "tickets"), ("wl_elixir", "elixir")) if self.settings.get(k)]
        self.log("Wasteland: " + ("collect " + " + ".join(want) + " when the map shows them ready"
                                  if want else "don't collect anything"))

    def _show_wasteland(self):
        for key, btn in self.wl_btns.items():
            on = bool(self.settings.get(key))
            btn.style(ACCENT if on else PILL, ACCENT_TEXT if on else TEXT)

    def on_revive(self, value):
        self.settings["auto_revive"] = bool(value)
        save_settings(self.settings)
        self.log("Campaign defeat: " + ("press Revive (also while the bot is stopped)" if value
                                         else "go back, upgrade + rewind"))
        self._update_revive_watch()

    def _update_revive_watch(self):
        """Auto-Revive keeps working while the bot is stopped (you playing yourself)."""
        if not hasattr(self, "revive_watch"):
            self.revive_watch = ReviveWatcher(self.log, on_revive=lambda: self.daily.add("revives"))
        if self.settings.get("auto_revive") and not self.is_running():
            self.revive_watch.start()
        else:
            self.revive_watch.stop()
        # spell casting too (it idles while casting is off); the bot casts itself while running
        if not hasattr(self, "spell_watch"):
            self.spell_watch = SpellWatcher(
                lambda: (bool(self.settings.get("cast_spells")), self.settings.get("cast_slots") or {}), self.log)
        if self.is_running():
            self.spell_watch.stop()
        else:
            self.spell_watch.start()

    def on_expedition(self, value):
        self.settings["expedition_on_max"] = bool(value)
        save_settings(self.settings)
        self.log("Out of rewinds: " + ("start a Hell Expedition, save, then stop" if value else "stop and alert"))

    def on_team(self, n):
        self.settings["expedition_team"] = n
        save_settings(self.settings)
        self._refresh_rest()

    # -- Rest panel ------------------------------------------------------------
    def get_rest(self):
        st = self.settings
        return {"on": bool(st.get("rest_on")), "every": int(st.get("rest_every", 10)),
                "style": st.get("rest_style", "idle"), "min": int(st.get("rest_min", 10)),
                "max": int(st.get("rest_max", 20)), "rewind_team": int(st.get("rewind_team", 1)),
                "mode": st.get("rest_mode", "expedition"), "boss": st.get("hunt_boss", "Asmodeus"),
                "level": int(st.get("hunt_level", 1))}

    def open_spells(self):
        """Campaign spell casting: which slots, tap or drag, where drags land."""
        body = self._open_tool("spells", "Auto-cast Spells")
        if body is None:
            return

        def grab():
            from adb import Device
            d = Device()
            d.connect()
            try:
                return d.screenshot()
            finally:
                d.close()
        SpellsPanel(body, self.tool_w, self.settings, save_settings, self.log, self.root, grab)

    def open_rest(self):
        """Hell Expedition + rest mode settings in the right panel."""
        body = self._open_tool("rest", "Rest & Expedition")
        if body is None:
            return
        cw = self.tool_w
        c = self.rest_c = tk.Canvas(body, width=cw, height=s(640), bg=TOOL_BG, highlightthickness=0)
        c.pack(anchor="nw")
        x0, x1, y = 0, cw - s(4), s(2)
        st = self.settings

        def seg(y, options, on_pick, h=s(28)):
            rounded_rect(c, x0, y, x1, y + h, s(12), fill=TILE_BG, outline="")
            w = (x1 - x0 - 2 * s(3)) / len(options)
            out = {}
            for i, (key, label) in enumerate(options):
                bx = x0 + s(3) + i * w
                out[key] = CanvasButton(c, (bx, y + s(3), bx + w, y + h - s(3)), label,
                                        lambda k=key: on_pick(k), size=9)
            return out

        def section(y, title):
            c.create_text(x0, y, anchor="nw", text=title, fill=MUTED, font=font(8, True))
            return y + s(20)

        # ---- Hell Expedition --------------------------------------------------
        y = section(y, "EXPEDITION / DUNGEON")
        c.create_text(x0, y, anchor="nw", text="Hero team for Expedition / Dungeon", fill=TEXT, font=font(10))
        y += s(20)
        self.exp_team_btns = seg(y, [(n, f"Team {n}") for n in (1, 2, 3, 4)], self.on_team)
        y += s(28) + s(14)
        c.create_text(x0, y + s(12), anchor="w", text="Out of rewinds: go idle", fill=TEXT, font=font(10))
        c.create_text(x0, y + s(30), anchor="w", text="Starts it, saves to the menu, stops. Off = stop + alert",
                      fill=MUTED, font=font(8))
        Toggle(c, x1 - s(50), y + s(4), bool(st.get("expedition_on_max")), self.on_expedition)
        y += s(44)
        self.out_mode_btns = seg(y, [("expedition", "Hell Expedition"), ("dungeon", "Dungeon")], self.on_out_mode)
        y += s(36)
        c.create_line(x0, y, x1, y, fill="#33333c")
        y += s(10)

        # ---- Rest mode --------------------------------------------------------------
        y = section(y, "REST MODE")
        c.create_text(x0, y + s(12), anchor="w", text="Rest every few rewinds", fill=TEXT, font=font(10))
        c.create_text(x0, y + s(30), anchor="w", text="Takes a break in Expedition, Dungeon or Hunt", fill=MUTED, font=font(8))
        Toggle(c, x1 - s(50), y + s(4), bool(st.get("rest_on")), self.on_rest_toggle)
        y += s(44)
        c.create_text(x0, y + s(14), anchor="w", text="Rewinds between rests", fill=TEXT, font=font(10))
        bw = s(30)
        CanvasButton(c, (x1 - s(150), y, x1 - s(150) + bw, y + s(28)), "−", lambda: self.on_rest_every(-1), size=11)
        self.rest_every_txt = c.create_text(x1 - s(150) + bw + s(42), y + s(14), anchor="center",
                                            fill=ACCENT, font=font(12, True), text="")
        CanvasButton(c, (x1 - s(150) + bw + s(84), y, x1 - s(150) + 2 * bw + s(84), y + s(28)), "+",
                     lambda: self.on_rest_every(1), size=11)
        y += s(36)
        c.create_text(x0, y, anchor="nw", text="Where to rest", fill=TEXT, font=font(10))
        y += s(20)
        self.rest_mode_btns = seg(y, [("expedition", "Expedition"), ("dungeon", "Dungeon"), ("hunt", "Hunt")],
                                  self.on_rest_mode)
        y += s(32)
        self.hunt_items = []
        bosses = ["Asmodeus", "Leviathan", "Belphegor", "Mammon"]
        self.hunt_boss_btns = seg(y, [(b, b) for b in bosses], self.on_hunt_boss, h=s(26))
        self.hunt_y = y
        y += s(30)
        self.hunt_items.append(c.create_text(x0, y + s(13), anchor="w", text="Boss level", fill=TEXT, font=font(9)))
        bw = s(30)
        bx = x1 - s(150)
        CanvasButton(c, (bx, y, bx + bw, y + s(26)), "−", lambda: self.on_hunt_level(-1), size=10)
        self.hunt_level_txt = c.create_text(bx + bw + s(42), y + s(13), anchor="center", fill=ACCENT,
                                            font=font(11, True), text="")
        CanvasButton(c, (bx + bw + s(84), y, bx + 2 * bw + s(84), y + s(26)), "+",
                     lambda: self.on_hunt_level(1), size=10)
        y += s(32)
        self.rest_mode_txt = c.create_text(x0, y, anchor="nw", fill=MUTED, font=font(8), width=x1 - x0, text="")
        y += s(30)
        c.create_text(x0, y, anchor="nw", text="How to rest", fill=TEXT, font=font(10))
        y += s(20)
        self.rest_style_btns = seg(y, [("idle", "Idle"), ("active", "Active")], self.on_rest_style)
        y += s(32)
        self.rest_style_txt = c.create_text(x0, y, anchor="nw", fill=MUTED, font=font(8), width=x1 - x0, text="")
        y += s(30)
        c.create_text(x0, y, anchor="nw", text="Rest length (random in this range)", fill=TEXT, font=font(10))
        self.rest_len_txt = c.create_text(x1, y, anchor="ne", fill=ACCENT, font=font(10, True), text="")
        y += s(32)
        RangeSlider(c, x0 + s(10), y, x1 - s(10), st.get("rest_min", 10), st.get("rest_max", 20), 1, 60,
                    self.on_rest_len)
        c.create_text(x0, y + s(14), anchor="nw", text="1 min", fill=MUTED, font=font(7))
        c.create_text(x1, y + s(14), anchor="ne", text="1 hour", fill=MUTED, font=font(7))
        y += s(36)
        c.create_text(x0, y, anchor="nw", text="Rewind team (switched back to after resting)", fill=TEXT,
                      font=font(10))
        y += s(20)
        self.rewind_team_btns = seg(y, [(n, f"Team {n}") for n in (1, 2, 3, 4)], self.on_rewind_team)
        self._refresh_rest()

    def _refresh_rest(self):
        if self.tool != "rest" or getattr(self, "rest_c", None) is None:
            return
        st, c = self.settings, self.rest_c
        try:
            out = st.get("out_mode", "expedition")
            for k, b in self.out_mode_btns.items():
                b.style(*((ACCENT, ACCENT_TEXT) if k == out else (TILE_BG, TEXT)))
            for n, b in self.exp_team_btns.items():
                b.style(*((ACCENT, ACCENT_TEXT) if n == st.get("expedition_team", 1) else (TILE_BG, TEXT)))
            for n, b in self.rewind_team_btns.items():
                b.style(*((ACCENT, ACCENT_TEXT) if n == st.get("rewind_team", 1) else (TILE_BG, TEXT)))
            mode = st.get("rest_mode", "expedition")
            style = {"hunt": "active", "dungeon": "idle"}.get(mode, st.get("rest_style", "idle"))
            for k, b in self.rest_style_btns.items():
                if mode in ("hunt", "dungeon"):
                    b.style(*((ACCENT, ACCENT_TEXT) if k == style else (TILE_BG, MUTED)), enabled=False)
                else:
                    b.style(*((ACCENT, ACCENT_TEXT) if k == style else (TILE_BG, TEXT)))
            every = int(st.get("rest_every", 10))
            c.itemconfigure(self.rest_every_txt, text=f"{every}")
            c.itemconfigure(self.rest_style_txt, text=(
                "Idle: cloud-saves to the title screen and waits, then comes back with X2 LOOT."
                if style == "idle" else
                "Active: lets it play on auto, then Pause > Leave/Forfeit > OK > back."))
            mode = st.get("rest_mode", "expedition")
            for k, b in self.rest_mode_btns.items():
                b.style(*((ACCENT, ACCENT_TEXT) if k == mode else (TILE_BG, TEXT)))
            boss = st.get("hunt_boss", "Asmodeus")
            for k, b in self.hunt_boss_btns.items():
                if mode == "hunt":
                    b.style(*((ACCENT, ACCENT_TEXT) if k == boss else (TILE_BG, TEXT)))
                else:
                    b.style(TILE_BG, MUTED, enabled=False)
            c.itemconfigure(self.hunt_level_txt, text=str(st.get("hunt_level", 1)),
                            fill=ACCENT if mode == "hunt" else MUTED)
            c.itemconfigure(self.rest_mode_txt, text={
                "expedition": "Hell Expedition with your expedition team.",
                "dungeon": "Dungeon: ENTER the top floor with X2 loot, with your expedition team (always idle).",
                "hunt": "Hunt: fights the chosen boss on auto (always active, Hunt has no cloud save), "
                        "then Pause > Return > OK. A locked level uses the highest open one."}[mode])
            lo, hi = int(st.get("rest_min", 10)), int(st.get("rest_max", 20))
            c.itemconfigure(self.rest_len_txt, text=f"{lo} min" if lo == hi else f"{lo}–{hi} min")
        except tk.TclError:
            pass

    def on_out_mode(self, mode):
        self.settings["out_mode"] = mode
        save_settings(self.settings)
        self.log("Out of rewinds: idle in " + ("the Dungeon" if mode == "dungeon" else "a Hell Expedition"))
        self._refresh_rest()

    def on_rest_toggle(self, value):
        self.settings["rest_on"] = bool(value)
        save_settings(self.settings)
        r = self.get_rest()
        self.log("Rest mode " + (f"ON: every {r['every']} rewinds, {r['style']}, {r['min']}-{r['max']} min"
                                 if value else "off"))

    def on_rest_every(self, d):
        self.settings["rest_every"] = max(1, min(500, int(self.settings.get("rest_every", 10)) + d))
        save_settings(self.settings)
        self._refresh_rest()

    def on_rest_style(self, style):
        self.settings["rest_style"] = style
        save_settings(self.settings)
        self._refresh_rest()

    def on_rest_len(self, lo, hi):
        self.settings["rest_min"], self.settings["rest_max"] = lo, hi
        save_settings(self.settings)
        self._refresh_rest()

    def on_rest_mode(self, mode):
        self.settings["rest_mode"] = mode
        save_settings(self.settings)
        self._refresh_rest()

    def on_hunt_boss(self, boss):
        if self.settings.get("rest_mode") != "hunt":
            return
        self.settings["hunt_boss"] = boss
        save_settings(self.settings)
        self._refresh_rest()

    def on_hunt_level(self, d):
        if self.settings.get("rest_mode") != "hunt":
            return
        self.settings["hunt_level"] = max(1, min(11, int(self.settings.get("hunt_level", 1)) + d))
        save_settings(self.settings)
        self._refresh_rest()

    def on_rewind_team(self, n):
        self.settings["rewind_team"] = n
        save_settings(self.settings)
        self._refresh_rest()

    def on_bot_done(self, reason):
        """Called from the bot thread when it stops on purpose (out of rewinds / expedition)."""
        self.call_soon(self._bot_done, reason)

    def _bot_done(self, reason):
        msg = {"rewinds_out": ("Out of rewinds", "The Rewind button shows a timer. Bot stopped."),
               "expedition": ("Idle started", ("Dungeon" if self.settings.get("out_mode") == "dungeon" else "Hell Expedition") + " running and saved. Bot stopped."),
               "rest_stuck": ("Stuck after resting",
                              "Couldn't get back into the game after the rest. Bot stopped."),
               "expedition_unsaved": ("Expedition not saved",
                                      "Expedition is running but the bot couldn't save it. Pause + cloud save yourself.")
               }.get(reason, ("Bot stopped", reason))
        self.c.itemconfigure(self.status_sub, text=msg[1])
        target = self.settings.get("phone_alert", "")
        if target:
            notify.send(target, msg[0], msg[1],
                        done=lambda err: err and self.call_soon(self.log, f"Phone alert failed: {err}"))
        if reason != "expedition":
            self.bar.restore()
            self._flash_taskbar()
            self.start_alarm()

    def on_elixir(self, value):
        self.elixir = value
        self.settings["elixir_mastery"] = value
        save_settings(self.settings)
        self.log("Elixir Mastery upgrade: " + ("ON" if value else "OFF (saving elixir)"))

    def on_mode(self, mode):
        self.start_mode = mode
        self._refresh_choices()

    def is_running(self):
        return bool(self.thread and self.thread.is_alive())

    def log(self, msg):
        line = f"{time.strftime('%H:%M:%S')}  {msg}"
        self.logq.put(line)
        if not hasattr(self, "recent_log"):
            self.recent_log = deque(maxlen=30)
        self.recent_log.append(line)

    def set_status(self, screen, phase, cycles):
        text = f"Screen: {screen}  ·  Step: {phase}  ·  Cycles: {cycles}"
        self._status_text = text
        self.call_soon(self.c.itemconfigure, self.status_sub, text=text)

    def call_soon(self, fn, *args, **kwargs):
        """Thread-safe: run fn on the Tk main thread (Tk isn't thread-safe)."""
        self.uiq.put((fn, args, kwargs))

    def _tk_error(self, exc, val, tb):
        with open(ERROR_LOG, "a") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S  window error\n")
                    + "".join(traceback.format_exception(exc, val, tb)) + "\n")
        self.log("Window error -- details in error.log")

    def drain_log(self):
        while not self.uiq.empty():
            fn, args, kwargs = self.uiq.get_nowait()
            try:
                fn(*args, **kwargs)
            except Exception:  # noqa: BLE001 - keep the window alive, log it
                self._tk_error(*__import__("sys").exc_info())
        lines = []
        while not self.logq.empty():
            lines.append(self.logq.get_nowait())
        if lines:
            self.logbox.configure(state="normal")
            self.logbox.insert("end", "\n".join(lines) + "\n")
            if int(self.logbox.index("end-1c").split(".")[0]) > 1000:
                self.logbox.delete("1.0", "200.0")
            self.logbox.see("end")
            self.logbox.configure(state="disabled")
        self.root.after(100, self.drain_log)

    def start(self):
        self.stop_alarm()
        if self.is_running():
            return
        if hasattr(self, "revive_watch"):
            self.revive_watch.stop()          # the bot handles defeats itself
        if hasattr(self, "spell_watch"):
            self.spell_watch.stop()           # ... and casts spells itself
        if getattr(self, "_reattach_on_start", False):
            self._reattach_on_start = False
            if not self.dock.attached:
                self.toggle_dock()            # it was attached before the human check
        self.bot = Bot(get_stat=lambda: self.stat, get_elixir=lambda: self.elixir,
                       log=self.log, status=self.set_status, on_check=self.on_check,
                       on_rewind=self.on_rewind, on_ghost_result=self.on_ghost_result,
                       get_expedition=lambda: (bool(self.settings.get("expedition_on_max")),
                                               self.settings.get("expedition_team", 1)),
                       on_done=self.on_bot_done, get_rest=self.get_rest,
                       get_revive=lambda: bool(self.settings.get("auto_revive")),
                       on_event=self.on_bot_event)
        self.bot.get_out_mode = lambda: self.settings.get("out_mode", "expedition")
        self.bot.get_casting = lambda: (bool(self.settings.get("cast_spells")), self.settings.get("cast_slots") or {})
        self.bot.get_wasteland = lambda: (bool(self.settings.get("wl_tickets")), bool(self.settings.get("wl_elixir")))
        phase = self.resume_phase or self.start_mode
        if self.resume_phase:
            self.log(f"Resuming where it stopped (step: {phase})")
        self.resume_phase = None
        self.thread = threading.Thread(target=self._run_bot, args=(phase,), daemon=True)
        self.thread.start()
        self._set_running(True)
        self.root.after(500, self.watch_thread)

    def _run_bot(self, phase):
        # There's no console when launched without one, so log crashes instead
        # of letting them disappear.
        try:
            self.bot.run(phase)
        except Exception:  # noqa: BLE001
            with open(ERROR_LOG, "a") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S\n") + traceback.format_exc() + "\n")
            self.log("Bot crashed -- details in error.log")

    def watch_thread(self):
        if self.is_running():
            self.root.after(500, self.watch_thread)
        else:
            self._set_running(False)
            self._save_timer()
            self._update_revive_watch()

    def stop(self):
        if self.bot:
            self.bot.stop_event.set()
        self.log("Stopping...")

    def save_game(self, state):
        self.settings["clicker_tt"] = state
        self.settings.pop("clicker", None)   # old version of the game
        save_settings(self.settings)

    def on_key(self, event):
        if not event.char or not event.char.isprintable():
            return
        self.keybuf = (self.keybuf + event.char.lower())[-3:]
        if self.keybuf == "fun":
            self.keybuf = ""
            if self.tool:
                self.close_tool()
            self.game.toggle()
            self.c.itemconfigure(self.bg_item,
                                 image=self._bg_game_photo if self.game.visible else self._bg_photo)

    # -- world tree ----------------------------------------------------------
    def open_guide(self):
        body = self._open_tool("guide", "Day Guide")
        if body is not None:
            self.guide_win = GuidePanel(body, self.settings, save_settings, read_day=self.guide_read_day,
                                        width=self.tool_w)

    def guide_read_day(self, window):
        if self.is_running():
            window.apply_day(None, "Stop the bot first, then press Read day from game.")
            return
        from adb import Device
        from gameread import GameReader
        from vision import Vision
        if not getattr(self, "game_reader", None):
            self.game_reader = GameReader(Device(), Vision(), self.log)

        def work():
            try:
                day, err = self.game_reader.read_day(), None
            except Exception as e:  # noqa: BLE001 - show any problem in the window
                day, err = None, e
            self.call_soon(window.apply_day, day, err)
        threading.Thread(target=work, daemon=True).start()

    def open_heroes(self):
        body = self._open_tool("heroes", "Heroes")
        if body is not None:
            self.heroes_panel = HeroesPanel(body, self.tool_w)

    def open_worldtree(self):
        body = self._open_tool("worldtree", "World Tree Planner")
        if body is not None:
            self.wt_win = WorldTreePanel(body, self.settings, save_settings, read_from_game=self.wt_read)

    def wt_read(self, window):
        if self.is_running():
            window.apply_read({}, "Stop the bot first, then press Read from game.")
            return
        from adb import Device
        from gameread import GameReader
        from vision import Vision

        if not getattr(self, "game_reader", None):
            self.game_reader = GameReader(Device(), Vision(), self.log)
        window.on_learn = self.game_reader.learn

        def work():
            try:
                values, err = self.game_reader.read_all(), None
            except Exception as e:  # noqa: BLE001 - show any problem in the window
                values, err = {}, e
            self.call_soon(window.apply_read, values, err)
        threading.Thread(target=work, daemon=True).start()

    # -- updates -----------------------------------------------------------
    def check_update(self, manual=False):
        if not updater.configured():
            self.update_btn.set_text("Updates: not set up")
            self.update_btn.style(PILL, MUTED, enabled=False)
            return
        self.update_btn.set_text("Checking…")
        self.update_btn.style(PILL, MUTED, enabled=False)

        def work():
            try:
                info, err = updater.check(), None
            except Exception as e:  # noqa: BLE001 - offline, GitHub down, bad file
                info, err = None, e
            self.call_soon(self._update_checked, info, err, manual)
        threading.Thread(target=work, daemon=True).start()

    def _update_checked(self, info, err, manual):
        self.update_info = info
        if info:
            self.update_btn.set_text(f"Update to v{info['version']}")
            self.update_btn.style(ACCENT, ACCENT_TEXT)
            notes = f" -- {info['notes']}" if info.get("notes") else ""
            self.log(f"Update available: v{info['version']}{notes}. Press the yellow button to install.")
            return
        self.update_btn.set_text("Check for update")
        self.update_btn.style(PILL, TEXT)
        if err and manual:
            self.log(f"Couldn't check for updates: {err}")
        elif manual:
            self.log(f"You're on the newest version (v{VERSION}).")

    def on_update_click(self):
        if not self.update_info:
            self.check_update(manual=True)
            return
        if self.is_running():
            self.log("Stop the bot first, then press Update.")
            return
        info = self.update_info
        self.update_btn.set_text("Updating…")
        self.update_btn.style(PILL, MUTED, enabled=False)
        self.log(f"Downloading v{info['version']}…")

        def work():
            try:
                updater.install(info)
                err = None
            except Exception as e:  # noqa: BLE001
                err = e
            self.call_soon(self._update_installed, info, err)
        threading.Thread(target=work, daemon=True).start()

    def _update_installed(self, info, err):
        if err:
            self.log(f"Update failed: {err}. Your current version is unchanged.")
            self.update_btn.set_text(f"Update to v{info['version']}")
            self.update_btn.style(ACCENT, ACCENT_TEXT)
            return
        self.log(f"Installed v{info['version']}. Restarting…")
        self.game.maybe_save(force=True)
        updater.restart()
        self.root.after(400, self.root.destroy)

    # -- BlueStacks dock ----------------------------------------------------------
    def instance_menu(self):
        """Pick a BlueStacks instance: open a bot window for it."""
        m = tk.Menu(self.root, tearoff=0, bg="#1d1d24", fg=TEXT, activebackground=ACCENT,
                    activeforeground="#111111", font=("Segoe UI", 9))
        for inst in instances.list_instances():
            if inst["name"] == self.instance["name"]:
                m.add_command(label=f"✓  {inst['display']}  (this window)", state="disabled")
            else:
                m.add_command(label=f"Open bot for {inst['display']}",
                              command=lambda i=inst: (instances.open_window(i),
                                                      self.log(f"Opening a bot window for {i['display']}")))
        x0, _, _, y1 = self.bar.c.bbox("full")
        m.tk_popup(self.root.winfo_pointerx(), self.root.winfo_rooty() + 4)

    def _make_visible(self):
        """After start-up the window sometimes stays minimized or behind other windows
        (Windows won't always let a new program take focus). Restore it, keep it on a
        screen, and bring it to the front."""
        try:
            instances.bring_forward(int(self.root.frame(), 16))
        except (tk.TclError, ValueError, OSError):
            pass

    def _dock_target(self):
        """Screen rect (x, y, w, h) for the BlueStacks game picture: top of the right
        panel, or the whole body in compact mode."""
        gx0, gy0, gx1, gy1 = GAME_PANEL
        pad = s(16)
        w = gx1 - gx0 - 2 * pad
        h = round(w * 9 / 16)
        if self.compact and self.compact_body is not None:
            cp = s(8)
            return self.compact_body.winfo_rootx() + cp, self.compact_body.winfo_rooty() + cp, w, h
        return self.c.winfo_rootx() + gx0 + pad, self.c.winfo_rooty() + gy0 + pad, w, h

    def toggle_compact(self):
        """Compact mode: the window shrinks to the attached game with a slim bar
        (icon + Detach). Right-click Detach again to go back to full size."""
        if not self.compact and not self.dock.attached:
            return
        bar = self.bar.c
        _, _, w, h = self._dock_target()
        cp = s(8)
        if not self.compact:
            self.compact = True
            bar.itemconfigure("full", state="hidden")
            x0, _, x1, _ = bar.bbox("dockbtn")
            self._dock_btn_dx = s(52) - x0
            bar.move("dockbtn", self._dock_btn_dx, 0)
            self._build_mini_controls(w + 2 * cp)
            bar.itemconfigure("compact", state="normal")
            self.c.pack_forget()
            self.compact_body = tk.Frame(self.root, bg=TOOL_BG, width=w + 2 * cp, height=h + 2 * cp)
            self.compact_body.pack(padx=1, pady=(0, 1))
            self._resize_window(w + 2 * cp, h + 2 * cp)
        else:
            self.compact = False
            bar.itemconfigure("full", state="normal")
            bar.move("dockbtn", -self._dock_btn_dx, 0)
            bar.itemconfigure("compact", state="hidden")
            if self.compact_body is not None:
                self.compact_body.destroy()
                self.compact_body = None
            self.c.pack(padx=1, pady=(0, 1))
            self._resize_window(WIDTH, HEIGHT)
        self.settings["compact"] = self.compact
        save_settings(self.settings)
        self.root.update_idletasks()
        self.dock.move_now()

    def _build_mini_controls(self, width):
        """START / STOP next to Detach and the run timer on the right, for compact mode."""
        if getattr(self, "mini_btns", None):
            return
        bar = self.bar.c
        mid = BAR_H / 2
        _, _, x, _ = bar.bbox("dockbtn")
        x += s(8)
        bw = s(54)
        start = CanvasButton(bar, (x, mid - s(12), x + bw, mid + s(12)), "START", self.start, size=8, tags=("compact",))
        stop = CanvasButton(bar, (x + bw + s(6), mid - s(12), x + 2 * bw + s(6), mid + s(12)), "STOP", self.stop,
                            size=8, tags=("compact",))
        self.mini_btns = (start, stop)
        self.mini_timer = bar.create_text(width - s(10), mid, anchor="e", text="", fill=MUTED,
                                          font=("Consolas", max(8, s(12)), "bold"), tags=("compact",))
        self._set_running(self.is_running())

    def _resize_window(self, w, h):
        total_w, total_h = w + 2, h + BAR_H + 1
        self.root.minsize(1, 1)
        self.root.maxsize(10000, 10000)
        self.root.geometry(f"{total_w}x{total_h}")
        self.root.minsize(total_w, total_h)
        self.root.maxsize(total_w, total_h)

    def _place_tool_panel(self):
        """While BlueStacks is attached, tool panels open under it instead of behind it."""
        gx0, gy0, gx1, gy1 = GAME_PANEL
        pad = s(16)
        top = gy0 + pad
        if self.dock.attached:
            top += self._dock_target()[3] + s(12)
        self.c.coords(self.tool_item, gx0 + pad, top)
        self.c.itemconfigure(self.tool_item, height=gy1 - pad - top)

    def toggle_dock(self):
        if self.dock.attached:
            if self.compact:
                self.toggle_compact()           # back to full size first
            self.dock.detach()
        elif not self.dock.attach():
            return
        on = self.dock.attached
        self.settings["dock_bluestacks"] = on
        save_settings(self.settings)
        self.dock_btn.set_text("Detach BlueStacks" if on else "Attach BlueStacks")
        self.dock_btn.style(ACCENT if on else PILL, ACCENT_TEXT if on else TEXT)
        self._place_tool_panel()

    def _dock_startup(self):
        if self.settings.get("dock_bluestacks"):
            self.toggle_dock()                  # attach again, like last time
            if self.dock.attached and self.settings.get("compact"):
                self.root.after(300, self.toggle_compact)
        else:
            dock.unclip()

    # -- phone remote (remote.py) ----------------------------------------------------
    def remote_port(self):
        names = [i["name"] for i in instances.list_instances()]
        return remote.PORT_BASE + (names.index(self.instance["name"]) if self.instance["name"] in names else 0)

    def _update_remote(self):
        want = bool(self.settings.get("remote_on")) and len(str(self.settings.get("remote_pin", ""))) >= 4
        if want and self.remote is None:
            try:
                self.remote = remote.RemoteServer(self, self.remote_port())
                self.remote.start()
                self.log("Phone remote on: " + ", ".join(u for _, u in self.remote.urls()))
            except OSError as e:
                self.remote = None
                self.log(f"Phone remote couldn't start: {e}")
        elif not want and self.remote is not None:
            self.remote.stop()
            self.remote = None
            self.log("Phone remote off")
        self._show_remote()

    def remote_pin(self):
        return str(self.settings.get("remote_pin", ""))

    def remote_log(self, msg):
        self.log(msg)

    def remote_command(self, cmd):
        """START / STOP pressed on the phone (called from the web server thread)."""
        self.call_soon(self.start if cmd == "start" else self.stop)
        self.log(f"Phone: {cmd.upper()} pressed")

    def remote_status(self):
        sec = int(getattr(self, "run_seconds", 0))
        check = bool(self.resume_phase) and not self.is_running()
        title = "Days Bygone Bot" + (f" – {self.instance['display']}" if self.multi else "")
        return {"title": title, "running": self.is_running(), "check": check,
                "timer": f"{sec // 3600}:{sec // 60 % 60:02d}:{sec % 60:02d}",
                "status": ("Human check -- answer it, then START" if check else
                           getattr(self, "_status_text", "Idle") if self.is_running() else "Stopped"),
                "log": list(getattr(self, "recent_log", []))[-12:]}

    def remote_link(self):
        if self.remote is None:
            return ""
        urls = self.remote.urls()
        return urls[0][1] if urls else ""

    def on_close(self):
        if getattr(self, "remote", None) is not None:
            self.remote.stop()
        if self.dock.attached:
            self.dock.detach(quiet=True)
        if hasattr(self, "revive_watch"):
            self.revive_watch.stop()
        if hasattr(self, "spell_watch"):
            self.spell_watch.stop()
        self._save_timer()
        self.game.maybe_save(force=True)
        self.stop_alarm()
        sound.stop()
        self.stop()
        self.root.after(300, self.root.destroy)


def main():
    from chrome import set_app_id
    inst = instances.current()
    ok = instances.claim(inst)
    if not ok and "--restart" in sys.argv:      # after an update: wait for the old window to close
        for _ in range(20):
            time.sleep(0.5)
            ok = instances.claim(inst)
            if ok:
                break
    if not ok:
        # Another copy has this instance. If its window exists, just show it.
        h = instances.find_window(inst)
        if h:
            instances.bring_forward(h)
            return
        # No window: it's probably still closing -- give it a few seconds.
        for _ in range(10):
            time.sleep(0.5)
            ok = instances.claim(inst)
            if ok:
                break
    if not ok:
        h = instances.find_window(inst)
        if h:
            instances.bring_forward(h)
            return
        import tkinter.messagebox as mb
        r = tk.Tk()
        r.withdraw()
        if mb.askyesno("Days Bygone Bot",
                       f"An old copy of the bot for {inst['display']} is stuck in the background "
                       "(no window).\n\nClose it and start the bot?"):
            instances.kill(instances.stuck_pids(inst))
            for _ in range(10):
                time.sleep(0.5)
                ok = instances.claim(inst)
                if ok:
                    break
        r.destroy()
        if not ok:
            return
    set_app_id()          # before the window exists: own taskbar icon, not Python's
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
