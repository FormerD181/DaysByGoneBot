"""Control window for the Days Bygone bot."""
import os
import queue
import threading
import time
import tkinter as tk
import traceback
import ctypes
from tkinter import filedialog

import sound
import updater

from PIL import Image, ImageDraw, ImageTk

from bot import STAT_BUTTONS, Bot, load_settings, save_settings
from clicker import Clicker
from version import VERSION

HERE = os.path.dirname(os.path.abspath(__file__))
BACKGROUND = os.path.join(HERE, "assets", "background.png")
ERROR_LOG = os.path.join(HERE, "error.log")

from widgets import (ACCENT, ACCENT_TEXT, DISABLED, GREEN, LOG_BG, MUTED, PILL, RED, SCALE, TEXT,
                     CanvasButton, Slider, Toggle, font, rounded_rect, s)

WIDTH, HEIGHT = s(920), s(696)                  # same aspect as the background picture
PANEL = (s(14), s(14), s(396), s(HEIGHT / SCALE - 14))  # dark see-through panel on the left
PAD = s(22)                                     # inner padding of the panel
GAME_PANEL = (s(412), s(14), s(906), s(682))    # hidden clicker game (type "fun")

STAT_LABELS = {"Damage": "Damage", "Gold": "Gold", "Critical Damage": "Crit Damage"}


class App:
    def __init__(self, root):
        self.root = root
        self.settings = load_settings()
        self.logq = queue.Queue()
        self.bot = None
        self.thread = None
        self.stat = self.settings["stat"]
        self.elixir = bool(self.settings["elixir_mastery"])
        self.start_mode = "push"
        self.resume_phase = None   # set after a human check so START continues
        self.alarm_job = None
        self.alarm_started = 0.0

        root.title(f"Days Bygone Bot v{VERSION}")
        root.resizable(False, False)
        root.configure(bg="#000000")
        self.c = tk.Canvas(root, width=WIDTH, height=HEIGHT, highlightthickness=0, bd=0)
        self.c.pack()
        self._draw_background()

        px0, py0, px1, _ = PANEL
        x0, x1 = px0 + PAD, px1 - PAD
        y = py0 + PAD
        gap = s(8)

        # Header
        self.c.create_text(x0, y, anchor="nw", text="Days Bygone Bot", fill=TEXT, font=font(20, True))
        self.c.create_text(x1, y + s(6), anchor="ne", text=f"v{VERSION}", fill=MUTED, font=font(10, True))
        y += s(38)
        dot = s(10)
        self.dot = self.c.create_oval(x0, y + s(5), x0 + dot, y + s(5) + dot, fill=MUTED, outline="")
        self.status_main = self.c.create_text(x0 + s(18), y, anchor="nw", text="Idle", fill=TEXT,
                                              font=font(11, True))
        self.update_info = None
        self.update_btn = CanvasButton(self.c, (x1 - s(132), y - s(2), x1, y + s(22)), "Check for update",
                                       self.on_update_click, size=8)
        y += s(22)
        self.status_sub = self.c.create_text(x0, y, anchor="nw", text="Press Start when the game is open",
                                             fill=MUTED, font=font(9), width=x1 - x0)
        y += s(26)

        # Rewind counters
        self.rewind_text = self.c.create_text(x0, y + s(13), anchor="w", text="", fill=TEXT, font=font(10))
        CanvasButton(self.c, (x1 - s(64), y, x1, y + s(26)), "Reset", self.reset_counter, size=9)
        self._show_rewinds()
        y += s(26) + s(14)

        # Stat to upgrade
        y = self._section(x0, y, "UPGRADE AFTER MAX DAY")
        self.stat_btns = {}
        bh = s(34)
        w = (x1 - x0 - gap * 2) / 3
        for i, name in enumerate(STAT_BUTTONS):
            bx = x0 + i * (w + gap)
            self.stat_btns[name] = CanvasButton(self.c, (bx, y, bx + w, y + bh), STAT_LABELS[name],
                                                lambda n=name: self.on_stat(n), size=10)
        y += bh + s(16)

        # Elixir toggle
        y = self._section(x0, y, "ELIXIR")
        self.c.create_text(x0, y + s(4), anchor="nw", text="Upgrade Elixir Mastery", fill=TEXT, font=font(11))
        self.c.create_text(x0, y + s(25), anchor="nw", text="Off = save elixir", fill=MUTED, font=font(9))
        Toggle(self.c, x1 - s(50), y + s(6), self.elixir, self.on_elixir)
        y += s(56)

        # Alert sound
        y = self._section(x0, y, "HUMAN CHECK ALARM")
        self.sound_label = self.c.create_text(x0, y, anchor="nw", text="", fill=TEXT, font=font(10),
                                              width=x1 - x0)
        y += s(22)
        sh = s(28)
        w3 = (x1 - x0 - gap * 2) / 3
        CanvasButton(self.c, (x0, y, x0 + w3, y + sh), "Choose…", self.choose_sound, size=9)
        CanvasButton(self.c, (x0 + w3 + gap, y, x0 + 2 * w3 + gap, y + sh), "Test", self.test_sound, size=9)
        CanvasButton(self.c, (x0 + 2 * (w3 + gap), y, x1, y + sh), "Default", self.default_sound, size=9)
        self._show_sound()
        y += sh + s(10)
        self.c.create_text(x0, y + s(10), anchor="w", text="Volume", fill=TEXT, font=font(10))
        self.volume_label = self.c.create_text(x1, y + s(10), anchor="e", fill=MUTED, font=font(10),
                                               text=f"{self.settings['alert_volume']}%")
        self.volume = Slider(self.c, x0 + s(70), y + s(10), x1 - s(48), self.settings["alert_volume"],
                             self.on_volume)
        y += s(20) + s(12)

        # Start mode
        y = self._section(x0, y, "WHEN STARTING")
        w2 = (x1 - x0 - gap) / 2
        self.mode_btns = {
            "push": CanvasButton(self.c, (x0, y, x0 + w2, y + bh), "Push campaign",
                                 lambda: self.on_mode("push"), size=10),
            "upgrade": CanvasButton(self.c, (x0 + w2 + gap, y, x1, y + bh), "Upgrade + rewind",
                                    lambda: self.on_mode("upgrade"), size=10),
        }
        y += bh + s(16)

        # Start / Stop
        big = s(44)
        self.start_btn = CanvasButton(self.c, (x0, y, x0 + w2, y + big), "START", self.start, size=13)
        self.stop_btn = CanvasButton(self.c, (x0 + w2 + gap, y, x1, y + big), "STOP", self.stop, size=13)
        y += big + s(14)

        # Log
        self.logbox = tk.Text(self.c, bg=LOG_BG, fg="#cfcfd6", relief="flat", bd=0, highlightthickness=0,
                              font=("Consolas", max(7, s(9))), wrap="word", padx=s(10), pady=s(8),
                              state="disabled", cursor="arrow")
        self.c.create_window(x0, y, anchor="nw", window=self.logbox,
                             width=x1 - x0, height=PANEL[3] - PAD - y)

        # Hidden clicker game on the right: type "fun" to show/hide it.
        self.game = Clicker(root, self.c, GAME_PANEL, self.settings.get("clicker_tt"), self.save_game)
        self.keybuf = ""
        root.bind("<Key>", self.on_key, add="+")

        self._refresh_choices()
        self._set_running(False)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.drain_log)
        root.after(1500, self.check_update)      # quiet check on launch
        # Clicking anywhere in the window silences the alarm.
        self.c.bind("<Button-1>", self._click_silences, add="+")

    # -- drawing -----------------------------------------------------------
    def _draw_background(self):
        try:
            bg = Image.open(BACKGROUND).convert("RGBA").resize((WIDTH, HEIGHT), Image.LANCZOS)
        except OSError:
            bg = Image.new("RGBA", (WIDTH, HEIGHT), (30, 30, 36, 255))
        shade = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
        draw = ImageDraw.Draw(shade)
        draw.rounded_rectangle(PANEL, radius=s(18), fill=(14, 14, 18, 232))
        base = Image.alpha_composite(bg, shade)
        draw.rounded_rectangle(GAME_PANEL, radius=s(18), fill=(14, 14, 18, 250))
        with_game = Image.alpha_composite(bg, shade)
        self._bg_photo = ImageTk.PhotoImage(base)
        self._bg_game_photo = ImageTk.PhotoImage(with_game)
        self.bg_item = self.c.create_image(0, 0, anchor="nw", image=self._bg_photo)

    def _section(self, x, y, title):
        self.c.create_text(x, y, anchor="nw", text=title, fill=MUTED, font=font(8, True))
        return y + s(18)

    def _refresh_choices(self):
        for name, btn in self.stat_btns.items():
            btn.style(*((ACCENT, ACCENT_TEXT) if name == self.stat else (PILL, TEXT)))
        running = self.is_running()
        for mode, btn in self.mode_btns.items():
            if mode == self.start_mode:
                btn.style(ACCENT, ACCENT_TEXT, enabled=not running)
            else:
                btn.style(PILL, TEXT if not running else MUTED, enabled=not running)

    def _set_running(self, running):
        self.start_btn.style(DISABLED if running else GREEN, MUTED if running else TEXT, enabled=not running)
        self.stop_btn.style(RED if running else DISABLED, TEXT if running else MUTED, enabled=running)
        if self.resume_phase and not running:
            self.c.itemconfigure(self.dot, fill=RED)
            self.c.itemconfigure(self.status_main, text="Human check!", fill=RED)
            self.c.itemconfigure(self.status_sub, text="Answer it in the game yourself, then press START")
        else:
            self.c.itemconfigure(self.dot, fill=GREEN if running else MUTED)
            self.c.itemconfigure(self.status_main, text="Running" if running else "Idle", fill=TEXT)
            if not running:
                self.c.itemconfigure(self.status_sub, text="Press Start when the game is open")
        self._refresh_choices()

    # -- rewind counters ---------------------------------------------------
    def _show_rewinds(self):
        self.c.itemconfigure(
            self.rewind_text,
            text=f"Rewinds   Total: {self.settings['rewinds_total']}   Counter: {self.settings['rewinds_counter']}")

    def on_rewind(self):
        """Called from the bot thread each time a rewind is confirmed."""
        self.root.after(0, self._add_rewind)

    def _add_rewind(self):
        self.settings["rewinds_total"] += 1
        self.settings["rewinds_counter"] += 1
        save_settings(self.settings)
        self._show_rewinds()

    def reset_counter(self):
        self.settings["rewinds_counter"] = 0
        save_settings(self.settings)
        self._show_rewinds()
        self.log("Rewind counter reset (total kept)")

    # -- human check alert -------------------------------------------------
    def on_check(self, phase):
        """Called from the bot thread when the game shows a human check."""
        self.root.after(0, self._alert, phase)

    def _alert(self, phase):
        self.resume_phase = phase
        self._set_running(self.is_running())
        # Pop the window to the front and flash it on the taskbar.
        self.root.deiconify()
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after(1500, lambda: self.root.attributes("-topmost", False))
        self._flash_taskbar()
        self.start_alarm()

    # -- alarm sound -------------------------------------------------------
    ALARM_SECONDS = 3

    def start_alarm(self):
        self.stop_alarm()
        vol = self.settings.get("alert_volume", 100)
        if not sound.play(self.settings.get("alert_sound"), loop=True, volume=vol):
            sound.play(None, loop=True, volume=vol)  # custom file failed -> built-in alarm
        self.alarm_job = self.root.after(self.ALARM_SECONDS * 1000, self.stop_alarm)
        self.alarm_started = time.monotonic()

    def _click_silences(self, event):
        # The click that pressed Test also reaches the window -- don't let it
        # cancel the sound it just started. Dragging the volume slider doesn't
        # silence it either.
        if self.volume.contains(event.x, event.y):
            return
        if time.monotonic() - self.alarm_started > 0.3:
            self.stop_alarm()

    def on_volume(self, value):
        self.settings["alert_volume"] = value
        self.c.itemconfigure(self.volume_label, text=f"{value}%")
        sound.set_volume(value)  # live if the alarm is playing
        self._save_volume_later()

    def _save_volume_later(self):
        # Dragging fires many events; save once the slider settles.
        if getattr(self, "_vol_job", None):
            self.root.after_cancel(self._vol_job)
        self._vol_job = self.root.after(400, lambda: save_settings(self.settings))

    def stop_alarm(self):
        if self.alarm_job:
            self.root.after_cancel(self.alarm_job)
            self.alarm_job = None
            sound.stop()

    def _show_sound(self):
        path = self.settings.get("alert_sound") or ""
        name = os.path.basename(path) if path and os.path.exists(path) else "Built-in alarm"
        if len(name) > 34:
            name = name[:31] + "…"
        self.c.itemconfigure(self.sound_label, text="Sound: " + name)

    def choose_sound(self):
        path = filedialog.askopenfilename(
            title="Pick an alarm sound",
            filetypes=[("Sound files", "*.wav *.mp3 *.wma"), ("All files", "*.*")])
        if not path:
            return
        if not path.lower().endswith(sound.SUPPORTED):
            self.log("That file type isn't supported -- use .wav, .mp3 or .wma")
            return
        self.settings["alert_sound"] = path
        save_settings(self.settings)
        self._show_sound()
        self.log(f"Alarm sound set to {os.path.basename(path)}")

    def default_sound(self):
        self.settings["alert_sound"] = ""
        save_settings(self.settings)
        self._show_sound()
        self.log("Alarm sound reset to the built-in alarm")

    def test_sound(self):
        path = self.settings.get("alert_sound")
        if path and os.path.exists(path) and not sound.play(path, volume=0):
            self.log("Couldn't play that sound file -- the built-in alarm will be used")
        self.start_alarm()

    def _flash_taskbar(self):
        class FLASHWINFO(ctypes.Structure):
            _fields_ = [("cbSize", ctypes.c_uint), ("hwnd", ctypes.c_void_p), ("dwFlags", ctypes.c_uint),
                        ("uCount", ctypes.c_uint), ("dwTimeout", ctypes.c_uint)]
        try:
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            # FLASHW_ALL | FLASHW_TIMERNOFG: flash until the window is focused.
            info = FLASHWINFO(ctypes.sizeof(FLASHWINFO), hwnd, 0x3 | 0xC, 0, 0)
            ctypes.windll.user32.FlashWindowEx(ctypes.byref(info))
        except (AttributeError, OSError):
            pass

    # -- events ------------------------------------------------------------
    def on_stat(self, name):
        self.stat = name
        self.settings["stat"] = name
        save_settings(self.settings)
        self._refresh_choices()
        self.log(f"Will upgrade: {name}")

    def on_elixir(self, value):
        self.elixir = value
        self.settings["elixir_mastery"] = value
        save_settings(self.settings)
        self.log("Elixir Mastery upgrade: " + ("ON" if value else "OFF (saving elixir)"))

    def on_mode(self, mode):
        self.start_mode = mode
        self._refresh_choices()

    def is_running(self):
        return bool(self.thread and self.thread.is_alive())

    def log(self, msg):
        self.logq.put(f"{time.strftime('%H:%M:%S')}  {msg}")

    def set_status(self, screen, phase, cycles):
        text = f"Screen: {screen}  ·  Step: {phase}  ·  Cycles: {cycles}"
        self.root.after(0, lambda: self.c.itemconfigure(self.status_sub, text=text))

    def drain_log(self):
        lines = []
        while not self.logq.empty():
            lines.append(self.logq.get_nowait())
        if lines:
            self.logbox.configure(state="normal")
            self.logbox.insert("end", "\n".join(lines) + "\n")
            if int(self.logbox.index("end-1c").split(".")[0]) > 1000:
                self.logbox.delete("1.0", "200.0")
            self.logbox.see("end")
            self.logbox.configure(state="disabled")
        self.root.after(100, self.drain_log)

    def start(self):
        self.stop_alarm()
        if self.is_running():
            return
        self.bot = Bot(get_stat=lambda: self.stat, get_elixir=lambda: self.elixir,
                       log=self.log, status=self.set_status, on_check=self.on_check,
                       on_rewind=self.on_rewind)
        phase = self.resume_phase or self.start_mode
        if self.resume_phase:
            self.log(f"Resuming where it stopped (step: {phase})")
        self.resume_phase = None
        self.thread = threading.Thread(target=self._run_bot, args=(phase,), daemon=True)
        self.thread.start()
        self._set_running(True)
        self.root.after(500, self.watch_thread)

    def _run_bot(self, phase):
        # There's no console when launched without one, so log crashes instead
        # of letting them disappear.
        try:
            self.bot.run(phase)
        except Exception:  # noqa: BLE001
            with open(ERROR_LOG, "a") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S\n") + traceback.format_exc() + "\n")
            self.log("Bot crashed -- details in error.log")

    def watch_thread(self):
        if self.is_running():
            self.root.after(500, self.watch_thread)
        else:
            self._set_running(False)

    def stop(self):
        if self.bot:
            self.bot.stop_event.set()
        self.log("Stopping...")

    def save_game(self, state):
        self.settings["clicker_tt"] = state
        self.settings.pop("clicker", None)   # old version of the game
        save_settings(self.settings)

    def on_key(self, event):
        if not event.char or not event.char.isprintable():
            return
        self.keybuf = (self.keybuf + event.char.lower())[-3:]
        if self.keybuf == "fun":
            self.keybuf = ""
            self.game.toggle()
            self.c.itemconfigure(self.bg_item,
                                 image=self._bg_game_photo if self.game.visible else self._bg_photo)

    # -- updates -----------------------------------------------------------
    def check_update(self, manual=False):
        if not updater.configured():
            self.update_btn.set_text("Updates: not set up")
            self.update_btn.style(PILL, MUTED, enabled=False)
            return
        self.update_btn.set_text("Checking…")
        self.update_btn.style(PILL, MUTED, enabled=False)

        def work():
            try:
                info, err = updater.check(), None
            except Exception as e:  # noqa: BLE001 - offline, GitHub down, bad file
                info, err = None, e
            self.root.after(0, self._update_checked, info, err, manual)
        threading.Thread(target=work, daemon=True).start()

    def _update_checked(self, info, err, manual):
        self.update_info = info
        if info:
            self.update_btn.set_text(f"Update to v{info['version']}")
            self.update_btn.style(ACCENT, ACCENT_TEXT)
            notes = f" -- {info['notes']}" if info.get("notes") else ""
            self.log(f"Update available: v{info['version']}{notes}. Press the yellow button to install.")
            return
        self.update_btn.set_text("Check for update")
        self.update_btn.style(PILL, TEXT)
        if err and manual:
            self.log(f"Couldn't check for updates: {err}")
        elif manual:
            self.log(f"You're on the newest version (v{VERSION}).")

    def on_update_click(self):
        if not self.update_info:
            self.check_update(manual=True)
            return
        if self.is_running():
            self.log("Stop the bot first, then press Update.")
            return
        info = self.update_info
        self.update_btn.set_text("Updating…")
        self.update_btn.style(PILL, MUTED, enabled=False)
        self.log(f"Downloading v{info['version']}…")

        def work():
            try:
                updater.install(info)
                err = None
            except Exception as e:  # noqa: BLE001
                err = e
            self.root.after(0, self._update_installed, info, err)
        threading.Thread(target=work, daemon=True).start()

    def _update_installed(self, info, err):
        if err:
            self.log(f"Update failed: {err}. Your current version is unchanged.")
            self.update_btn.set_text(f"Update to v{info['version']}")
            self.update_btn.style(ACCENT, ACCENT_TEXT)
            return
        self.log(f"Installed v{info['version']}. Restarting…")
        self.game.maybe_save(force=True)
        updater.restart()
        self.root.after(400, self.root.destroy)

    def on_close(self):
        self.game.maybe_save(force=True)
        self.stop_alarm()
        sound.stop()
        self.stop()
        self.root.after(300, self.root.destroy)


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
