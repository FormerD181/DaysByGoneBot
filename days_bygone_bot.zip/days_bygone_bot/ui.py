"""Control window for the Days Bygone bot."""
import os
import queue
import threading
import time
import tkinter as tk
import traceback
import ctypes
from tkinter import filedialog

import notify
import sound
import updater

from PIL import Image, ImageDraw, ImageTk

from bot import STAT_BUTTONS, Bot, load_settings, save_settings
from clicker import Clicker
from guide_ui import GuidePanel
from heroes_ui import HeroesPanel
from worldtree_ui import WorldTreePanel
from version import VERSION

HERE = os.path.dirname(os.path.abspath(__file__))
BACKGROUND = os.path.join(HERE, "assets", "background.png")
ERROR_LOG = os.path.join(HERE, "error.log")

from widgets import (ACCENT, ACCENT_TEXT, DISABLED, GREEN, LOG_BG, MUTED, PILL, RED, SCALE, TEXT,
                     CanvasButton, Slider, Toggle, font, rounded_rect, s)
from chrome import BAR_H, BORDER, TitleBar, set_app_icon

TILE_BG = "#1d1d24"
TOOL_BG = "#121216"      # right-hand tool panel

WIDTH, HEIGHT = s(920), s(696)                  # same aspect as the background picture
PANEL = (s(14), s(14), s(396), s(HEIGHT / SCALE - 14))  # dark see-through panel on the left
PAD = s(22)                                     # inner padding of the panel
GAME_PANEL = (s(412), s(14), s(906), s(682))    # hidden clicker game (type "fun")

STAT_LABELS = {"Damage": "Damage", "Gold": "Gold", "Critical Damage": "Crit Damage"}


class App:
    def __init__(self, root):
        self.root = root
        self.settings = load_settings()
        self.logq = queue.Queue()
        self.uiq = queue.Queue()      # calls from other threads, run on the main thread
        root.report_callback_exception = self._tk_error
        self.bot = None
        self.thread = None
        self.stat = self.settings["stat"]
        self.elixir = bool(self.settings["elixir_mastery"])
        self.start_mode = "push"
        self.resume_phase = None   # set after a human check so START continues
        self.alarm_job = None
        self.alarm_started = 0.0

        root.title(f"Days Bygone Bot v{VERSION}")
        set_app_icon(root)
        root.resizable(False, False)
        # Pin the size: when restored from the taskbar, Windows briefly reports
        # the tiny minimised size and Tk would otherwise keep it (blank window).
        total_h = HEIGHT + BAR_H + 1
        root.geometry(f"{WIDTH + 2}x{total_h}")
        root.minsize(WIDTH + 2, total_h)
        root.maxsize(WIDTH + 2, total_h)
        root.configure(bg=BORDER)            # 1px border around the whole window
        self.bar = TitleBar(root, "Days Bygone Bot", VERSION, self.on_close)
        self.bar.c.pack_configure(padx=1, pady=(1, 0))
        self.bar.place_controls(WIDTH)
        self.update_info = None
        self.update_btn = self.bar.add_button("Check for update", self.on_update_click, s(128))
        self.c = tk.Canvas(root, width=WIDTH, height=HEIGHT, highlightthickness=0, bd=0)
        self.c.pack(padx=1, pady=(0, 1))
        self._draw_background()

        px0, py0, px1, _ = PANEL
        x0, x1 = px0 + PAD, px1 - PAD
        y = py0 + s(20)
        gap = s(8)

        # Status
        dot = s(12)
        self.dot = self.c.create_oval(x0, y + s(6), x0 + dot, y + s(6) + dot, fill=MUTED, outline="")
        self.status_main = self.c.create_text(x0 + s(22), y, anchor="nw", text="Idle", fill=TEXT,
                                              font=font(15, True))
        y += s(30)
        self.status_sub = self.c.create_text(x0, y, anchor="nw", text="Press Start when the game is open",
                                             fill=MUTED, font=font(9), width=x1 - x0)
        y += s(30)

        # Stat tiles: rewinds and ghost losses
        tw = (x1 - x0 - gap) / 2
        th = s(84)
        self.rewind_tile = self._tile(x0, y, x0 + tw, y + th, "REWINDS")
        self.loss_tile = self._tile(x0 + tw + gap, y, x1, y + th, "GHOST LOSSES")
        CanvasButton(self.c, (x0 + tw - s(52), y + s(8), x0 + tw - s(8), y + s(28)), "Reset",
                     self.reset_counter, size=7)
        self._show_rewinds()
        self._show_losses()
        y += th + s(18)

        # Stat to upgrade
        y = self._section(x0, y, "UPGRADE AFTER MAX DAY")
        bh = s(34)
        self.stat_btns = self._segmented(x0, y, x1, bh, [(n, STAT_LABELS[n]) for n in STAT_BUTTONS],
                                         self.on_stat)
        y += bh + s(14)

        # Elixir toggle
        self.c.create_text(x0, y + s(15), anchor="w", text="Upgrade Elixir Mastery", fill=TEXT, font=font(11))
        self.c.create_text(x0, y + s(34), anchor="w", text="Off = save elixir", fill=MUTED, font=font(8))
        Toggle(self.c, x1 - s(50), y + s(6), self.elixir, self.on_elixir)
        y += s(50) + s(12)

        # Start mode
        y = self._section(x0, y, "WHEN STARTING")
        self.mode_btns = self._segmented(x0, y, x1, bh, [("push", "Push campaign"), ("upgrade", "Upgrade + rewind")],
                                         self.on_mode)
        y += bh + s(18)

        # Start / Stop
        w2 = (x1 - x0 - gap) / 2
        big = s(46)
        self.start_btn = CanvasButton(self.c, (x0, y, x0 + w2, y + big), "START", self.start, size=13)
        self.stop_btn = CanvasButton(self.c, (x0 + w2 + gap, y, x1, y + big), "STOP", self.stop, size=13)
        y += big + s(18)

        # Tools
        y = self._section(x0, y, "TOOLS")
        tools = [("World Tree", self.open_worldtree), ("Heroes", self.open_heroes),
                 ("Guide", self.open_guide), ("Alarm", self.open_alarm)]
        w4 = (x1 - x0 - gap * (len(tools) - 1)) / len(tools)
        for i, (label, fn) in enumerate(tools):
            bx = x0 + i * (w4 + gap)
            CanvasButton(self.c, (bx, y, bx + w4, y + s(32)), label, fn, size=9)
        y += s(32) + s(16)

        # Log
        self.logbox = tk.Text(self.c, bg=LOG_BG, fg="#cfcfd6", relief="flat", bd=0, highlightthickness=0,
                              font=("Consolas", max(7, s(9))), wrap="word", padx=s(10), pady=s(8),
                              state="disabled", cursor="arrow")
        self.c.create_window(x0, y, anchor="nw", window=self.logbox,
                             width=x1 - x0, height=PANEL[3] - s(18) - y)

        # Hidden clicker game on the right: type "fun" to show/hide it.
        self.game = Clicker(root, self.c, GAME_PANEL, self.settings.get("clicker_tt"), self.save_game)
        self.keybuf = ""
        root.bind("<Key>", self.on_key, add="+")

        self._style_dropdowns()
        self.tool = None              # which tool is open in the right panel
        self._build_tool_panel()
        self._refresh_choices()
        self._set_running(False)
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.drain_log)
        root.after(1500, self.check_update)      # quiet check on launch
        # Clicking anywhere in the window silences the alarm.
        self.c.bind("<Button-1>", self._click_silences, add="+")

    # -- drawing -----------------------------------------------------------
    def _draw_background(self):
        try:
            bg = Image.open(BACKGROUND).convert("RGBA").resize((WIDTH, HEIGHT), Image.LANCZOS)
        except OSError:
            bg = Image.new("RGBA", (WIDTH, HEIGHT), (30, 30, 36, 255))
        shade = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
        draw = ImageDraw.Draw(shade)
        draw.rounded_rectangle(PANEL, radius=s(18), fill=(14, 14, 18, 232))
        base = Image.alpha_composite(bg, shade)
        draw.rounded_rectangle(GAME_PANEL, radius=s(18), fill=(18, 18, 22, 255))
        with_game = Image.alpha_composite(bg, shade)
        self._bg_photo = ImageTk.PhotoImage(base)
        self._bg_game_photo = ImageTk.PhotoImage(with_game)
        self.bg_item = self.c.create_image(0, 0, anchor="nw", image=self._bg_photo)

    def _section(self, x, y, title):
        self.c.create_text(x, y, anchor="nw", text=title, fill=MUTED, font=font(8, True))
        return y + s(20)

    def _tile(self, x0, y0, x1, y1, label):
        """A small stat card: label, big number, small detail line."""
        rounded_rect(self.c, x0, y0, x1, y1, s(12), fill=TILE_BG, outline="")
        self.c.create_text(x0 + s(12), y0 + s(10), anchor="nw", text=label, fill=MUTED, font=font(7, True))
        big = self.c.create_text(x0 + s(12), y0 + s(30), anchor="nw", text="", fill=TEXT, font=font(16, True))
        small = self.c.create_text(x0 + s(12), y1 - s(9), anchor="sw", text="", fill=MUTED, font=font(8))
        return big, small

    def _segmented(self, x0, y, x1, h, options, on_pick):
        """Pill-style option group: a dark track with one highlighted choice."""
        rounded_rect(self.c, x0, y, x1, y + h, s(12), fill=TILE_BG, outline="")
        pad = s(3)
        w = (x1 - x0 - 2 * pad) / len(options)
        btns = {}
        for i, (key, label) in enumerate(options):
            bx = x0 + pad + i * w
            btns[key] = CanvasButton(self.c, (bx, y + pad, bx + w, y + h - pad), label,
                                     lambda k=key: on_pick(k), size=10)
        return btns

    def _refresh_choices(self):
        for name, btn in self.stat_btns.items():
            btn.style(*((ACCENT, ACCENT_TEXT) if name == self.stat else (TILE_BG, TEXT)))
        running = self.is_running()
        for mode, btn in self.mode_btns.items():
            if mode == self.start_mode:
                btn.style(ACCENT, ACCENT_TEXT, enabled=not running)
            else:
                btn.style(TILE_BG, TEXT if not running else MUTED, enabled=not running)

    def _set_running(self, running):
        self.start_btn.style(DISABLED if running else GREEN, MUTED if running else TEXT, enabled=not running)
        self.stop_btn.style(RED if running else DISABLED, TEXT if running else MUTED, enabled=running)
        if self.resume_phase and not running:
            self.c.itemconfigure(self.dot, fill=RED)
            self.c.itemconfigure(self.status_main, text="Human check!", fill=RED)
            self.c.itemconfigure(self.status_sub, text="Answer it in the game yourself, then press START")
        else:
            self.c.itemconfigure(self.dot, fill=GREEN if running else MUTED)
            self.c.itemconfigure(self.status_main, text="Running" if running else "Idle", fill=TEXT)
            if not running:
                self.c.itemconfigure(self.status_sub, text="Press Start when the game is open")
        self._refresh_choices()

    # -- rewind counters ---------------------------------------------------
    def _show_rewinds(self):
        big, small = self.rewind_tile
        self.c.itemconfigure(big, text=f"{self.settings['rewinds_total']:,}")
        self.c.itemconfigure(small, text=f"this session: {self.settings['rewinds_counter']:,}")

    def on_rewind(self):
        """Called from the bot thread each time a rewind is confirmed."""
        self.call_soon(self._add_rewind)

    def _add_rewind(self):
        self.settings["rewinds_total"] += 1
        self.settings["rewinds_counter"] += 1
        save_settings(self.settings)
        self._show_rewinds()

    # -- ghost loss streak -------------------------------------------------
    def _show_losses(self):
        st = self.settings
        big, small = self.loss_tile
        self.c.itemconfigure(big, text=f"{st['ghost_loss_streak']} in a row",
                             fill=RED if st["ghost_loss_streak"] >= 3 else TEXT)
        self.c.itemconfigure(small, text=f"longest {st['ghost_loss_streak_best']}  ·  total {st['ghost_losses_total']}")

    def on_ghost_result(self, won):
        """Called from the bot thread when a ghost battle is won or lost."""
        self.call_soon(self._add_ghost_result, won)

    def _add_ghost_result(self, won):
        st = self.settings
        if won:
            st["ghost_loss_streak"] = 0
        else:
            st["ghost_losses_total"] += 1
            st["ghost_loss_streak"] += 1
            st["ghost_loss_streak_best"] = max(st["ghost_loss_streak_best"], st["ghost_loss_streak"])
        save_settings(st)
        self._show_losses()

    def reset_counter(self):
        self.settings["rewinds_counter"] = 0
        save_settings(self.settings)
        self._show_rewinds()
        self.log("Rewind counter reset (total kept)")

    # -- human check alert -------------------------------------------------
    def on_check(self, phase):
        """Called from the bot thread when the game shows a human check."""
        self.call_soon(self._alert, phase)

    def _alert(self, phase):
        self.resume_phase = phase
        self._set_running(self.is_running())
        # Pop the window to the front and flash it on the taskbar.
        self.bar.restore()
        self.root.attributes("-topmost", True)
        self.root.after(1500, lambda: self.root.attributes("-topmost", False))
        self._flash_taskbar()
        self.start_alarm()
        self._phone_alert(phase)

    # -- alarm sound -------------------------------------------------------
    ALARM_SECONDS = 3

    def start_alarm(self):
        self.stop_alarm()
        vol = self.settings.get("alert_volume", 100)
        if not sound.play(self.settings.get("alert_sound"), loop=True, volume=vol):
            sound.play(None, loop=True, volume=vol)  # custom file failed -> built-in alarm
        self.alarm_job = self.root.after(self.ALARM_SECONDS * 1000, self.stop_alarm)
        self.alarm_started = time.monotonic()

    def _click_silences(self, event):
        # The click that pressed Test also reaches the window -- don't let it
        # cancel the sound it just started.
        if time.monotonic() - self.alarm_started > 0.3:
            self.stop_alarm()

    def open_alarm(self):
        """Human-check alarm settings (sound file, test, volume) in the right panel."""
        body = self._open_tool("alarm", "Human check alarm")
        if body is None:
            return
        cw = self.tool_w
        c = self.alarm_c = tk.Canvas(body, width=cw, height=s(470), bg=TOOL_BG, highlightthickness=0)
        c.pack(anchor="nw")
        x0, x1, y = 0, cw - s(4), s(4)
        c.create_text(x0, y, anchor="nw", fill=MUTED, font=font(9), width=x1 - x0,
                      text="Plays for 3 seconds when the game shows a human check, so you can answer it.")
        y += s(44)
        self.sound_label = c.create_text(x0, y, anchor="nw", text="", fill=TEXT, font=font(10), width=x1 - x0)
        self._show_sound()
        y += s(28)
        gap = s(8)
        w3 = (x1 - x0 - 2 * gap) / 3
        for i, (label, fn) in enumerate((("Choose…", self.choose_sound), ("Test", self.test_sound),
                                         ("Default", self.default_sound))):
            bx = x0 + i * (w3 + gap)
            CanvasButton(c, (bx, y, bx + w3, y + s(32)), label, fn, size=9)
        y += s(32) + s(28)
        c.create_text(x0, y, anchor="w", text="Volume", fill=TEXT, font=font(10))
        self.volume_label = c.create_text(x1, y, anchor="e", fill=MUTED, font=font(10),
                                          text=f"{self.settings['alert_volume']}%")
        self.volume = Slider(c, x0 + s(70), y, x1 - s(48), self.settings["alert_volume"], self.on_volume)

        # -- phone alert --
        y += s(40)
        c.create_line(x0, y, x1, y, fill="#33333c")
        y += s(14)
        c.create_text(x0, y, anchor="nw", text="Phone alert", fill=TEXT, font=font(11, "bold"))
        y += s(26)
        c.create_text(x0, y, anchor="nw", fill=MUTED, font=font(9), width=x1 - x0,
                      text="Also ping your phone when a human check shows up. Easiest: install the free "
                           "\"ntfy\" app, subscribe to a made-up topic name (hard to guess, like "
                           "dbg-bot-7f3k2q) and type the same name here. Or paste a Discord webhook link "
                           "from your own server.")
        y += s(72)
        self.phone_var = tk.StringVar(value=self.settings.get("phone_alert", ""))
        entry = tk.Entry(c, textvariable=self.phone_var, bg="#26262d", fg=TEXT, insertbackground=TEXT,
                         relief="flat", font=("Segoe UI", max(8, s(10))))
        c.create_window(x0, y, anchor="nw", window=entry, width=x1 - x0, height=s(28))
        y += s(38)
        w2 = (x1 - x0 - gap) / 2
        CanvasButton(c, (x0, y, x0 + w2, y + s(32)), "Save", self.save_phone, size=9)
        CanvasButton(c, (x0 + w2 + gap, y, x1, y + s(32)), "Send test", self.test_phone, size=9)
        y += s(44)
        self.phone_status = c.create_text(x0, y, anchor="nw", fill=MUTED, font=font(9), width=x1 - x0,
                                          text=self._phone_status_text())

    # -- phone alert -------------------------------------------------------
    def _phone_status_text(self):
        target = self.settings.get("phone_alert", "")
        k = notify.kind(target)
        if not target:
            return "Off."
        return {"ntfy": f"On: ntfy topic \"{target}\".", "discord": "On: Discord webhook."}.get(k, "Not valid.")

    def _set_phone_status(self, text):
        if self.tool == "alarm" and getattr(self, "alarm_c", None):
            try:
                self.alarm_c.itemconfigure(self.phone_status, text=text)
            except tk.TclError:
                pass

    def save_phone(self):
        target = self.phone_var.get().strip()
        if target and not notify.kind(target):
            self._set_phone_status("That's not an ntfy topic (letters, numbers, - and _) "
                                   "or a Discord webhook link -- not saved.")
            return
        self.settings["phone_alert"] = target
        save_settings(self.settings)
        self._set_phone_status(self._phone_status_text())
        self.log("Phone alert " + ("saved" if target else "turned off"))

    def test_phone(self):
        self.save_phone()
        target = self.settings.get("phone_alert", "")
        if not target:
            self._set_phone_status("Type a topic or webhook first.")
            return
        self._set_phone_status("Sending test…")
        notify.send(target, "Days Bygone Bot", "Test alert -- phone alerts are working.",
                    done=lambda err: self.call_soon(
                        self._set_phone_status, "Test sent -- check your phone." if not err else f"Failed: {err}"))

    def _phone_alert(self, phase):
        target = self.settings.get("phone_alert", "")
        if not target:
            return
        notify.send(target, "Human check!",
                    "The game is showing a human check. Answer it, then press START in the bot.",
                    done=lambda err: err and self.call_soon(self.log, f"Phone alert failed: {err}"))

    # -- right-hand tool panel ---------------------------------------------------
    def _style_dropdowns(self):
        """Dark dropdowns to match the panels."""
        from tkinter import ttk
        st = ttk.Style(self.root)
        st.theme_use("clam")
        st.configure("TCombobox", fieldbackground="#26262d", background="#26262d", foreground=TEXT,
                     arrowcolor=TEXT, bordercolor="#26262d", lightcolor="#26262d", darkcolor="#26262d",
                     selectbackground="#26262d", selectforeground=TEXT)
        st.map("TCombobox", fieldbackground=[("readonly", "#26262d"), ("disabled", "#1d1d24")],
               foreground=[("disabled", MUTED)], selectbackground=[("readonly", "#26262d")])
        self.root.option_add("*TCombobox*Listbox.background", "#1d1d24")
        self.root.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.root.option_add("*TCombobox*Listbox.selectBackground", ACCENT)
        self.root.option_add("*TCombobox*Listbox.selectForeground", "#111111")

    def _build_tool_panel(self):
        """The right side shows one tool at a time (World Tree, Day Guide, Alarm),
        in the same space as the hidden clicker game."""
        gx0, gy0, gx1, gy1 = GAME_PANEL
        pad = s(16)
        self.tool_w = gx1 - gx0 - 2 * pad
        box = self.tool_box = tk.Frame(self.c, bg=TOOL_BG)
        head = tk.Frame(box, bg=TOOL_BG)
        head.pack(fill="x", pady=(0, s(10)))
        self.tool_title = tk.Label(head, text="", bg=TOOL_BG, fg=TEXT, font=("Segoe UI", max(9, s(14)), "bold"))
        self.tool_title.pack(side="left")
        x = tk.Label(head, text="✕", bg=TOOL_BG, fg=MUTED, font=("Segoe UI", max(9, s(13))), cursor="hand2", padx=6)
        x.pack(side="right")
        x.bind("<Button-1>", lambda e: self.close_tool())
        x.bind("<Enter>", lambda e: x.config(fg=TEXT))
        x.bind("<Leave>", lambda e: x.config(fg=MUTED))
        self.tool_body = tk.Frame(box, bg=TOOL_BG)
        self.tool_body.pack(fill="both", expand=True)
        self.tool_item = self.c.create_window(gx0 + pad, gy0 + pad, anchor="nw", window=box,
                                              width=self.tool_w, height=gy1 - gy0 - 2 * pad, state="hidden")

    def _open_tool(self, key, title):
        """Show the panel for a tool. Returns its (empty) body frame, or None if
        that tool was already open (clicking its button again closes it)."""
        if self.tool == key:
            self.close_tool()
            return None
        if self.game.visible:
            self.game.hide()
        for child in self.tool_body.winfo_children():
            child.destroy()
        self.tool = key
        self.tool_title.config(text=title)
        self.c.itemconfigure(self.tool_item, state="normal")
        self.c.itemconfigure(self.bg_item, image=self._bg_game_photo)
        return self.tool_body

    def close_tool(self):
        self.tool = None
        for child in self.tool_body.winfo_children():
            child.destroy()
        self.c.itemconfigure(self.tool_item, state="hidden")
        self.c.itemconfigure(self.bg_item, image=self._bg_game_photo if self.game.visible else self._bg_photo)

    def on_volume(self, value):
        self.settings["alert_volume"] = value
        if self.tool == "alarm":
            self.alarm_c.itemconfigure(self.volume_label, text=f"{value}%")
        sound.set_volume(value)  # live if the alarm is playing
        self._save_volume_later()

    def _save_volume_later(self):
        # Dragging fires many events; save once the slider settles.
        if getattr(self, "_vol_job", None):
            self.root.after_cancel(self._vol_job)
        self._vol_job = self.root.after(400, lambda: save_settings(self.settings))

    def stop_alarm(self):
        if self.alarm_job:
            self.root.after_cancel(self.alarm_job)
            self.alarm_job = None
            sound.stop()

    def _show_sound(self):
        path = self.settings.get("alert_sound") or ""
        name = os.path.basename(path) if path and os.path.exists(path) else "Built-in alarm"
        if len(name) > 40:
            name = name[:37] + "…"
        if self.tool == "alarm":
            self.alarm_c.itemconfigure(self.sound_label, text="Sound: " + name)

    def choose_sound(self):
        path = filedialog.askopenfilename(
            title="Pick an alarm sound",
            filetypes=[("Sound files", "*.wav *.mp3 *.wma"), ("All files", "*.*")])
        if not path:
            return
        if not path.lower().endswith(sound.SUPPORTED):
            self.log("That file type isn't supported -- use .wav, .mp3 or .wma")
            return
        self.settings["alert_sound"] = path
        save_settings(self.settings)
        self._show_sound()
        self.log(f"Alarm sound set to {os.path.basename(path)}")

    def default_sound(self):
        self.settings["alert_sound"] = ""
        save_settings(self.settings)
        self._show_sound()
        self.log("Alarm sound reset to the built-in alarm")

    def test_sound(self):
        path = self.settings.get("alert_sound")
        if path and os.path.exists(path) and not sound.play(path, volume=0):
            self.log("Couldn't play that sound file -- the built-in alarm will be used")
        self.start_alarm()

    def _flash_taskbar(self):
        class FLASHWINFO(ctypes.Structure):
            _fields_ = [("cbSize", ctypes.c_uint), ("hwnd", ctypes.c_void_p), ("dwFlags", ctypes.c_uint),
                        ("uCount", ctypes.c_uint), ("dwTimeout", ctypes.c_uint)]
        try:
            hwnd = int(self.root.frame(), 16)
            # FLASHW_ALL | FLASHW_TIMERNOFG: flash until the window is focused.
            info = FLASHWINFO(ctypes.sizeof(FLASHWINFO), hwnd, 0x3 | 0xC, 0, 0)
            ctypes.windll.user32.FlashWindowEx(ctypes.byref(info))
        except (AttributeError, OSError):
            pass

    # -- events ------------------------------------------------------------
    def on_stat(self, name):
        self.stat = name
        self.settings["stat"] = name
        save_settings(self.settings)
        self._refresh_choices()
        self.log(f"Will upgrade: {name}")

    def on_elixir(self, value):
        self.elixir = value
        self.settings["elixir_mastery"] = value
        save_settings(self.settings)
        self.log("Elixir Mastery upgrade: " + ("ON" if value else "OFF (saving elixir)"))

    def on_mode(self, mode):
        self.start_mode = mode
        self._refresh_choices()

    def is_running(self):
        return bool(self.thread and self.thread.is_alive())

    def log(self, msg):
        self.logq.put(f"{time.strftime('%H:%M:%S')}  {msg}")

    def set_status(self, screen, phase, cycles):
        text = f"Screen: {screen}  ·  Step: {phase}  ·  Cycles: {cycles}"
        self.call_soon(self.c.itemconfigure, self.status_sub, text=text)

    def call_soon(self, fn, *args, **kwargs):
        """Thread-safe: run fn on the Tk main thread (Tk isn't thread-safe)."""
        self.uiq.put((fn, args, kwargs))

    def _tk_error(self, exc, val, tb):
        with open(ERROR_LOG, "a") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S  window error\n")
                    + "".join(traceback.format_exception(exc, val, tb)) + "\n")
        self.log("Window error -- details in error.log")

    def drain_log(self):
        while not self.uiq.empty():
            fn, args, kwargs = self.uiq.get_nowait()
            try:
                fn(*args, **kwargs)
            except Exception:  # noqa: BLE001 - keep the window alive, log it
                self._tk_error(*__import__("sys").exc_info())
        lines = []
        while not self.logq.empty():
            lines.append(self.logq.get_nowait())
        if lines:
            self.logbox.configure(state="normal")
            self.logbox.insert("end", "\n".join(lines) + "\n")
            if int(self.logbox.index("end-1c").split(".")[0]) > 1000:
                self.logbox.delete("1.0", "200.0")
            self.logbox.see("end")
            self.logbox.configure(state="disabled")
        self.root.after(100, self.drain_log)

    def start(self):
        self.stop_alarm()
        if self.is_running():
            return
        self.bot = Bot(get_stat=lambda: self.stat, get_elixir=lambda: self.elixir,
                       log=self.log, status=self.set_status, on_check=self.on_check,
                       on_rewind=self.on_rewind, on_ghost_result=self.on_ghost_result)
        phase = self.resume_phase or self.start_mode
        if self.resume_phase:
            self.log(f"Resuming where it stopped (step: {phase})")
        self.resume_phase = None
        self.thread = threading.Thread(target=self._run_bot, args=(phase,), daemon=True)
        self.thread.start()
        self._set_running(True)
        self.root.after(500, self.watch_thread)

    def _run_bot(self, phase):
        # There's no console when launched without one, so log crashes instead
        # of letting them disappear.
        try:
            self.bot.run(phase)
        except Exception:  # noqa: BLE001
            with open(ERROR_LOG, "a") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S\n") + traceback.format_exc() + "\n")
            self.log("Bot crashed -- details in error.log")

    def watch_thread(self):
        if self.is_running():
            self.root.after(500, self.watch_thread)
        else:
            self._set_running(False)

    def stop(self):
        if self.bot:
            self.bot.stop_event.set()
        self.log("Stopping...")

    def save_game(self, state):
        self.settings["clicker_tt"] = state
        self.settings.pop("clicker", None)   # old version of the game
        save_settings(self.settings)

    def on_key(self, event):
        if not event.char or not event.char.isprintable():
            return
        self.keybuf = (self.keybuf + event.char.lower())[-3:]
        if self.keybuf == "fun":
            self.keybuf = ""
            if self.tool:
                self.close_tool()
            self.game.toggle()
            self.c.itemconfigure(self.bg_item,
                                 image=self._bg_game_photo if self.game.visible else self._bg_photo)

    # -- world tree ----------------------------------------------------------
    def open_guide(self):
        body = self._open_tool("guide", "Day Guide")
        if body is not None:
            self.guide_win = GuidePanel(body, self.settings, save_settings, read_day=self.guide_read_day)

    def guide_read_day(self, window):
        if self.is_running():
            window.apply_day(None, "Stop the bot first, then press Read day from game.")
            return
        from adb import Device
        from gameread import GameReader
        from vision import Vision
        if not getattr(self, "game_reader", None):
            self.game_reader = GameReader(Device(), Vision(), self.log)

        def work():
            try:
                day, err = self.game_reader.read_day(), None
            except Exception as e:  # noqa: BLE001 - show any problem in the window
                day, err = None, e
            self.call_soon(window.apply_day, day, err)
        threading.Thread(target=work, daemon=True).start()

    def open_heroes(self):
        body = self._open_tool("heroes", "Heroes")
        if body is not None:
            self.heroes_panel = HeroesPanel(body, self.tool_w)

    def open_worldtree(self):
        body = self._open_tool("worldtree", "World Tree Planner")
        if body is not None:
            self.wt_win = WorldTreePanel(body, self.settings, save_settings, read_from_game=self.wt_read)

    def wt_read(self, window):
        if self.is_running():
            window.apply_read({}, "Stop the bot first, then press Read from game.")
            return
        from adb import Device
        from gameread import GameReader
        from vision import Vision

        if not getattr(self, "game_reader", None):
            self.game_reader = GameReader(Device(), Vision(), self.log)
        window.on_learn = self.game_reader.learn

        def work():
            try:
                values, err = self.game_reader.read_all(), None
            except Exception as e:  # noqa: BLE001 - show any problem in the window
                values, err = {}, e
            self.call_soon(window.apply_read, values, err)
        threading.Thread(target=work, daemon=True).start()

    # -- updates -----------------------------------------------------------
    def check_update(self, manual=False):
        if not updater.configured():
            self.update_btn.set_text("Updates: not set up")
            self.update_btn.style(PILL, MUTED, enabled=False)
            return
        self.update_btn.set_text("Checking…")
        self.update_btn.style(PILL, MUTED, enabled=False)

        def work():
            try:
                info, err = updater.check(), None
            except Exception as e:  # noqa: BLE001 - offline, GitHub down, bad file
                info, err = None, e
            self.call_soon(self._update_checked, info, err, manual)
        threading.Thread(target=work, daemon=True).start()

    def _update_checked(self, info, err, manual):
        self.update_info = info
        if info:
            self.update_btn.set_text(f"Update to v{info['version']}")
            self.update_btn.style(ACCENT, ACCENT_TEXT)
            notes = f" -- {info['notes']}" if info.get("notes") else ""
            self.log(f"Update available: v{info['version']}{notes}. Press the yellow button to install.")
            return
        self.update_btn.set_text("Check for update")
        self.update_btn.style(PILL, TEXT)
        if err and manual:
            self.log(f"Couldn't check for updates: {err}")
        elif manual:
            self.log(f"You're on the newest version (v{VERSION}).")

    def on_update_click(self):
        if not self.update_info:
            self.check_update(manual=True)
            return
        if self.is_running():
            self.log("Stop the bot first, then press Update.")
            return
        info = self.update_info
        self.update_btn.set_text("Updating…")
        self.update_btn.style(PILL, MUTED, enabled=False)
        self.log(f"Downloading v{info['version']}…")

        def work():
            try:
                updater.install(info)
                err = None
            except Exception as e:  # noqa: BLE001
                err = e
            self.call_soon(self._update_installed, info, err)
        threading.Thread(target=work, daemon=True).start()

    def _update_installed(self, info, err):
        if err:
            self.log(f"Update failed: {err}. Your current version is unchanged.")
            self.update_btn.set_text(f"Update to v{info['version']}")
            self.update_btn.style(ACCENT, ACCENT_TEXT)
            return
        self.log(f"Installed v{info['version']}. Restarting…")
        self.game.maybe_save(force=True)
        updater.restart()
        self.root.after(400, self.root.destroy)

    def on_close(self):
        self.game.maybe_save(force=True)
        self.stop_alarm()
        sound.stop()
        self.stop()
        self.root.after(300, self.root.destroy)


def main():
    from chrome import set_app_id
    set_app_id()          # before the window exists: own taskbar icon, not Python's
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
