"""Casting the hot-bar spells while pushing the campaign.

The player picks which slots (1-6) to use, whether a slot casts with one tap or
with a drag onto the battlefield, and (for drags) the area it lands in -- a
random spot inside that area each time.

A slot is cast only when it's ready. Spells aren't named here (any spell
works), so each slot is judged against itself:
  - no mana: the icon is tinted light blue (much more cyan than the same slot
    looks when it's ready)
  - cooldown: a dark sweep + countdown over the icon, so it's clearly darker
    than the same slot at its normal brightness
  - active: some spells stay switched on after casting (green markers on the
    slot's corners, draining mana); casting again would switch them off
"""
import random
import threading
import time
from collections import deque

import cv2

import humanize
from vision import DEFAULT_SLOTS

ICON_TOP, ICON_SIZE = 958, 100
DEFAULT_AREA = (900, 250, 1500, 750)     # middle of the battlefield
SLOT_GAP_S = 1.5                         # don't re-cast a slot sooner than this
TOGGLE_GAP_S = 6.0                       # after switching a Toggle spell on, give its dots time to show
CAST_GAP_S = 0.8                         # a second drag right after another one gets lost
NOMANA_SURE = 0.6                        # this much light-blue = tinted, whatever the spell
NOMANA_MIN = 0.35                        # this much light-blue at least = tinted
BLUE_BAND = 0.75                         # tinted icons: this share of coloured pixels is blue
NOMANA_OVER_READY = 0.25                 # ... and this much more than the slot's ready look
COOLDOWN_DARKER = 0.85                   # darker than this x its normal brightness = cooldown
BRIGHT_MEMORY_S = 60
ACTIVE_MIN_PX = 150                      # green marker pixels (on: ~800, off: 0)


def default_slots():
    return {str(i): {"on": False, "mode": "drag", "area": list(DEFAULT_AREA)} for i in range(1, 7)}


def slot_center(i):
    x0, y0, x1, y1 = DEFAULT_SLOTS[i]
    return int((x0 + x1) / 2), int((y0 + y1) / 2)


def _icon(img, i):
    x = int(DEFAULT_SLOTS[i][0]) + 10
    return img[ICON_TOP:ICON_TOP + ICON_SIZE, x:x + ICON_SIZE]


def _active(img, i):
    """Green markers around the slot's frame: the spell is switched on."""
    x0, y0, x1, y1 = (int(v) for v in DEFAULT_SLOTS[i])
    roi = img[y0 - 15:y1 + 12, x0 - 10:x1 + 15].copy()
    roi[25:-22, 20:-25] = 0                      # the icon itself doesn't count
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    return cv2.countNonZero(cv2.inRange(hsv, (40, 120, 150), (80, 255, 255))) > ACTIVE_MIN_PX


def _look(icon):
    """(light-blue share, mean brightness, blue share of the coloured pixels) of an icon."""
    hsv = cv2.cvtColor(icon, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    cyan = float(((h >= 86) & (h <= 104) & (s > 70) & (v > 130)).mean())
    col = (s > 60) & (v > 60)
    band = float(((h >= 78) & (h <= 125) & col).sum()) / max(1, int(col.sum()))
    return cyan, float(v.mean()), band


class CampaignCaster:
    def __init__(self, device, log):
        self.dev = device
        self.log = log
        self.min_cyan = [1.0] * 6
        self.min_band = [1.0] * 6
        self.bright = [deque() for _ in range(6)]
        self.last_slot = [0.0] * 6
        self.last_cast = 0.0

    def states(self, img, now=None):
        """Per slot: "ready", "nomana", "cooldown", "active" -- or None for every slot when
        the whole screen is dimmed (a popup, a day changing)."""
        now = now or time.monotonic()
        looks = [_look(_icon(img, i)) for i in range(6)]
        refs = []
        for i, (cyan, v, band) in enumerate(looks):
            self.min_cyan[i] = min(self.min_cyan[i], cyan)
            self.min_band[i] = min(self.min_band[i], band)
            refs.append(self._ref(i))
        dim = sum(1 for (c, v, _), r in zip(looks, refs) if r and v < 0.6 * r and c < 0.1)
        if dim >= 4:
            return [None] * 6
        out = []
        for i, (cyan, v, band) in enumerate(looks):
            q = self.bright[i]
            q.append((now, v, cyan, band))
            while q and now - q[0][0] > BRIGHT_MEMORY_S:
                q.popleft()
            if _active(img, i):
                out.append("active")
                continue
            if self._tinted(i, cyan, band):
                out.append("nomana")
                continue
            out.append("cooldown" if v < COOLDOWN_DARKER * self._ref(i) else "ready")
        return out

    def _tinted(self, i, cyan, band):
        """The no-mana tint: (nearly) every coloured pixel blue, and some of it light cyan.
        Blue-looking spells (ice, wind) are blue when ready too: for them it's how much
        more light cyan the slot shows than when it was seen ready."""
        if cyan >= NOMANA_SURE:
            return True
        if band >= BLUE_BAND and (cyan >= NOMANA_MIN or self.min_band[i] < 0.3):
            return True                          # a not-blue spell turned blue
        return cyan > max(NOMANA_MIN, self.min_cyan[i] + NOMANA_OVER_READY)

    def _ref(self, i):
        """The slot's normal brightness: brightest recent look that wasn't tinted
        (judged with what's known now, so early tinted frames drop out later)."""
        return max((v for _, v, c, b in self.bright[i] if not self._tinted(i, c, b)), default=None)

    def step(self, img, slots):
        """Cast at most one chosen, ready slot. slots = settings["cast_slots"]."""
        now = time.monotonic()
        st = self.states(img, now)
        if now - self.last_cast < CAST_GAP_S:
            return False
        for i in range(6):
            cfg = slots.get(str(i + 1)) or {}
            mode = cfg.get("mode", "drag")
            gap = TOGGLE_GAP_S if mode == "toggle" else SLOT_GAP_S
            if not cfg.get("on") or st[i] != "ready" or now - self.last_slot[i] < gap:
                continue
            sx, sy = slot_center(i)
            if mode in ("tap", "toggle"):        # toggle: one tap switches it on (never while it's on)
                # a short press, not an instant tap: slow BlueStacks misses some instant taps
                x, y = humanize.jitter(sx, sy)
                self.dev.swipe(x, y, x, y, random.randint(90, 140))
            else:
                x0, y0, x1, y1 = cfg.get("area") or DEFAULT_AREA
                self.dev.swipe(sx, sy, random.randint(min(x0, x1), max(x0, x1)),
                               random.randint(min(y0, y1), max(y0, y1)), humanize.drag_ms())
            self.last_slot[i] = self.last_cast = now
            return True
        return False


class SpellWatcher:
    """Casting while the bot is NOT running (you're playing yourself), like
    Auto-Revive: only on a normal battle screen (never a ghost fight or a menu).
    The bot stops this while it runs (it casts itself)."""

    def __init__(self, get_casting, log):
        self.get_casting = get_casting
        self.log = log
        self.stop_event = threading.Event()
        self.thread = None

    def running(self):
        return bool(self.thread and self.thread.is_alive())

    def start(self):
        if self.running():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()

    def _run(self):
        from adb import Device
        from vision import Vision
        vis, dev, caster = Vision(), None, None
        while not self.stop_event.is_set():
            on, slots = self.get_casting()
            if not on or not any(v.get("on") for v in slots.values()):
                self.stop_event.wait(2)
                continue
            try:
                if dev is None:
                    dev = Device()
                    dev.connect()
                    caster = CampaignCaster(dev, self.log)
                img = dev.screenshot()
                if vis.detect_state(img) == "campaign_battle":
                    caster.step(img, slots)
                    self.stop_event.wait(CAST_GAP_S)
                    continue
            except Exception:  # noqa: BLE001 - BlueStacks closed / not connected: try again later
                if dev is not None:
                    try:
                        dev.close()
                    except Exception:  # noqa: BLE001
                        pass
                dev = None
                self.stop_event.wait(10)
                continue
            self.stop_event.wait(2)
        if dev is not None:
            try:
                dev.close()
            except Exception:  # noqa: BLE001
                pass
