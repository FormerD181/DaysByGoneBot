"""Days Bygone bot: push campaign to max day, upgrade a stat, rewind, repeat.

Run:  python bot.py
"""
import json
import os
import threading
import time

import cv2

import humanize
from adb import Device, FastCapture
from ghost import GhostFighter
from version import VERSION
from vision import Vision

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_PATH = os.path.join(HERE, "settings.json")
DEBUG_DIR = os.path.join(HERE, "debug")

# Tap targets at 1920x1080.
BATTLE_BTN = (1790, 65)
CAMPAIGN_BTN = (830, 305)
GAMEMODE_CLOSE_BTN = (1327, 118)
X2_BTN = (1100, 708)
CHECKIN_CLAIM_BOX = (1200, 860, 1480, 965)     # daily reward CLAIM button area
CHECKIN_CLOSE_BTN = (1475, 122)                 # red X on the Check-In popup
# Inside both the campaign VICTORY red button and the ghost VICTORY one.
VICTORY_BACK_BTN = (860, 885)
STATS_TAB = (75, 225)
TREE_TAB = (75, 980)
REWIND_BTN = (595, 408)
ELIXIR_MASTERY_BTN = (1690, 312)
DEFEAT_RETRY_BTN = (1042, 658)
# Out of rewinds -> Hell Expedition (optional)
REWIND_POPUP_CLOSE = (1413, 95)
HEROES_TAB = (75, 800)
TEAM_BTNS = {1: (240, 1055), 2: (310, 1055), 3: (380, 1055), 4: (450, 1055)}
EXPEDITION_BTN = (900, 668)
HELL_BTN = (1480, 681)
EXP_OK_BOX = (860, 700, 1065, 760)      # "Begin Expedition on HELL?" OK
PAUSE_BTN = (68, 66)
CLOUD_BTN = (955, 726)                   # pause menu: blue cloud-save button under RESUME / FORFEIT
CLOUD_SEARCH = (700, 560, 1220, 880)     # where to look for it
STAT_BUTTONS = {
    "Damage": (890, 228),
    "Gold": (890, 944),
    "Critical Damage": (1748, 658),
}

# During ghost battles the full screen check runs only on every Nth frame.
FULL_CHECK_EVERY = 4

DEFAULT_SETTINGS = {"stat": "Critical Damage", "elixir_mastery": True, "alert_sound": "", "alert_volume": 100, "phone_alert": "",
                    "expedition_on_max": False, "expedition_team": 1,
                    "run_seconds_total": 0,
                    "rewinds_total": 0, "rewinds_counter": 0,
                    "ghost_losses_total": 0, "ghost_loss_streak": 0, "ghost_loss_streak_best": 0}
# How long to wait for an expected popup before trying again.
POPUP_TIMEOUT = 5.0


def load_settings():
    try:
        with open(SETTINGS_PATH) as f:
            return {**DEFAULT_SETTINGS, **json.load(f)}
    except (OSError, ValueError):
        return dict(DEFAULT_SETTINGS)


def save_settings(settings):
    try:
        with open(SETTINGS_PATH, "w") as f:
            json.dump(settings, f, indent=2)
    except OSError:
        pass


class Bot:
    """Screen-driven state machine. `phase` remembers what we're trying to do,
    the detected screen decides which button to press next."""

    def __init__(self, get_stat, get_elixir, log, status, on_check=None, on_rewind=None, on_ghost_result=None,
                 get_expedition=None, on_done=None):
        self.get_expedition = get_expedition or (lambda: (False, 1))
        self.on_done = on_done
        self.get_stat = get_stat
        self.get_elixir = get_elixir
        self.on_check = on_check
        self.on_rewind = on_rewind
        self.on_ghost_result = on_ghost_result
        self.log = log
        self.status = status
        self.dev = Device()
        self.vis = Vision()
        self.ghosts = GhostFighter(self.dev, self.vis, log)
        self.fast = FastCapture(self.dev)   # high frame rate, ghost battles only
        self.frame_t = 0.0
        self.fast_frames = 0
        self.last_menu_log = None
        self.stop_event = threading.Event()
        self.phase = "push"
        self.cycles = 0
        self.phase_at = 0.0
        self.unknown_since = None
        self.last_debug_save = 0.0
        self.last_state = None

    # -- helpers ----------------------------------------------------------
    def sleep(self, s):
        self.stop_event.wait(s)

    def tap(self, xy, why=None):
        """Human-like click: random short wait, then a slightly random spot."""
        self.sleep(humanize.pause())
        if self.stop_event.is_set():
            return
        if why:
            self.log(why)
        self.dev.tap(*humanize.jitter(*xy))

    def save_debug(self, img, label, force=False):
        now = time.time()
        if not force and now - self.last_debug_save < 10:
            return
        self.last_debug_save = now
        os.makedirs(DEBUG_DIR, exist_ok=True)
        files = sorted(os.listdir(DEBUG_DIR))
        for old in files[:-30]:
            try:
                os.remove(os.path.join(DEBUG_DIR, old))
            except OSError:
                pass
        path = os.path.join(DEBUG_DIR, f"{time.strftime('%Y%m%d_%H%M%S')}_{label}.png")
        cv2.imwrite(path, img)
        self.log(f"Saved screenshot: debug/{os.path.basename(path)}")

    # -- main loop --------------------------------------------------------
    def run(self, start_phase):
        self.phase = start_phase
        try:
            self.dev.connect()
        except Exception as e:  # noqa: BLE001 - show any connection problem in the GUI
            self.log(f"ADB connection failed: {e}")
            return
        self.log(f"Days Bygone Bot v{VERSION}. Connected. Starting in phase '{self.phase}'.")
        while not self.stop_event.is_set():
            if self.fast.running:
                got = self.fast.next(after=self.frame_t)
                if got is None:
                    self.log("Fast capture stalled -- back to normal screenshots")
                    self.fast.stop()
                    continue
                self.frame_t, img = got
                self.fast_frames += 1
            else:
                try:
                    self.frame_t = time.monotonic()
                    img = self.dev.screenshot()
                except Exception as e:  # noqa: BLE001
                    self.log(f"Screenshot failed: {e}")
                    self.sleep(2)
                    continue
            if (self.fast.running and self.fast_frames % FULL_CHECK_EVERY
                    and self.last_state == "ghost_battle" and self.vis.has(img, "pause")):
                state = "ghost_battle"   # cheap check; the full one (~47 ms) runs every few frames
            else:
                state = self.vis.detect_state(img)
            # look much more often while fighting ghosts, normal speed otherwise
            if state == "ghost_battle" and not self.fast.running:
                self.fast.start()
            elif state != "ghost_battle" and self.fast.running:
                self.fast.stop()
            if state != self.last_state and state != "ghost_battle":
                self.log(f"Screen: {state}")
            self.last_state = state
            self.status(state, self.phase, self.cycles)
            delay = self.handle(state, img)
            if delay:
                self.sleep(delay)
        self.fast.stop()
        self.save_battle("STOPPED")
        self.dev.close()
        self.log("Stopped.")

    # Phases, in loop order:
    #   push            -> campaign running / heading to battle
    #   upgrade         -> max day reached: buy the stat, then go to the tree
    #   rewind          -> on the tree: press the Rewind button
    #   ghost_ok        -> pressed the medallion, waiting for OK / ghost battle
    #   ghost           -> fighting ghosts
    #   rewind_confirm  -> pressed the elixir Rewind button, waiting for the green Rewind
    #   elixir          -> rewound: maybe upgrade Elixir Mastery
    #   elixir_ok       -> pressed Elixir Mastery, waiting for OK
    #   upgrade2        -> buy the stat again, then push
    def set_phase(self, phase):
        if phase != self.phase:
            self.phase = phase
            self.phase_at = time.monotonic()

    def waited(self, seconds):
        return time.monotonic() - self.phase_at > seconds

    def buy_stat(self):
        stat = self.get_stat()
        self.tap(STAT_BUTTONS[stat], f"Upgrading {stat}")
        self.tap(STAT_BUTTONS[stat])

    def handle(self, state, img):
        if state != "unknown":
            self.unknown_since = None

        if self.phase.startswith("exp_"):
            delay = self.on_expedition(state, img)
            if delay is not None:
                return delay

        if state == "human_check":
            # The game is asking whether a human is playing. The bot never
            # answers these: stop and hand control back to the player.
            self.log("HUMAN CHECK on screen -- bot stopped. Answer it yourself, then press START.")
            self.save_debug(img, "human_check", force=True)
            self.stop_event.set()
            if self.on_check:
                self.on_check(self.phase)
            return 0

        if state == "rewind_locked":
            on, team = self.get_expedition()
            if on:
                self.log("Out of rewinds (timer on the Rewind button) -> starting a Hell Expedition")
                self.tap(REWIND_POPUP_CLOSE, "Closing the rewind popup")
                self.set_phase("exp_heroes")
                return 1.5
            self.log("Out of rewinds (timer on the Rewind button) -- bot stopped.")
            self.save_debug(img, "rewinds_out", force=True)
            self.stop_event.set()
            if self.on_done:
                self.on_done("rewinds_out")
            return 0

        if state == "ghost_battle":
            if self.phase != "ghost":
                self.log("Ghost battle! Fighting...")
                self.ghosts.reset()
                self.set_phase("ghost")
            self.ghosts.step(img, self.frame_t)
            return 0

        if state in ("victory", "defeat", "result"):
            found = self.vis.result_buttons(img)
            red = found[1] if found else VICTORY_BACK_BTN
            green = found[2] if found and found[2] else DEFEAT_RETRY_BTN
            in_ghost = self.phase in ("ghost", "ghost_ok")
            if state == "result":
                # Banner didn't match: a red+green pair is a ghost DEFEAT during
                # ghost battles, otherwise a campaign VICTORY.
                state = "defeat" if (in_ghost and found[0] == "pair") else "victory"
            if state == "defeat":
                self.save_battle("LOSS")
                self.tap(green, "Defeat -> retrying")
                self.set_phase("ghost_ok")
            elif in_ghost:
                self.save_battle("WIN")
                self.tap(red, "Ghosts beaten -> going back")
                self.set_phase("rewind")
            else:
                self.tap(red, "Max day reached -> going back")
                self.set_phase("upgrade")
            return 2.0

        if state == "campaign_battle":
            return 2.0

        if state == "gamemode":
            at_max = self.vis.campaign_at_max(img)
            if at_max:
                self.log("Already at max day -> upgrade + rewind")
                self.set_phase("upgrade")
                self.tap(GAMEMODE_CLOSE_BTN, "Closing Battle menu")
                return 1.5
            if at_max is None:
                self.log("Couldn't read the campaign day -- starting campaign anyway")
            self.tap(CAMPAIGN_BTN, "Selecting Campaign")
            return 1.5

        if state == "campaign_confirm":
            self.tap(X2_BTN, "Starting Campaign (x2)")
            self.set_phase("push")
            return 2.0

        if state == "checkin":
            # Daily reward: press CLAIM (green), then the red X once it says CLAIMED.
            btn = self.vis.find_green_button(img)
            x0, y0, x1, y1 = CHECKIN_CLAIM_BOX
            if btn and x0 <= btn[0] <= x1 and y0 <= btn[1] <= y1:
                self.tap(btn, "Claiming daily reward")
                return 2.0
            self.tap(CHECKIN_CLOSE_BTN, "Closing daily reward")
            return 1.5

        if state in ("worldtree", "settings", "journal"):
            # A game menu is open (World Tree / Settings / Journal) -- leave it
            # alone and wait; it isn't a human check.
            if self.last_menu_log != state:
                self.log(f"{state.title()} menu is open -- waiting for it to close")
                self.last_menu_log = state
            return 2.0
        self.last_menu_log = None

        if state == "popup_ok":
            btn = self.vis.find_green_button(img)
            if btn and self.phase == "ghost_ok":
                self.tap(btn, "Pressing OK -> ghost battle")
                return 1.5
            if btn and self.phase == "rewind_confirm":
                self.tap(btn, "Pressing Rewind")
                self.set_phase("elixir")
                if self.on_rewind:
                    self.on_rewind()
                return 2.0
            if btn and self.phase == "elixir_ok":
                self.tap(btn, "Pressing OK (Elixir Mastery)")
                self.set_phase("upgrade2")
                return 1.5
            self.save_debug(img, "popup")
            self.log("Popup I don't know -- waiting (you can click it yourself)")
            return 2.0

        if state == "stats":
            return self.on_stats()
        if state == "skills":
            return self.on_skills(img)

        # unknown
        if self.unknown_since is None:
            self.unknown_since = time.monotonic()
        elif time.monotonic() - self.unknown_since > 8:
            self.save_debug(img, "unknown")
        return 1.0

    def on_stats(self):
        if self.phase == "upgrade":
            self.buy_stat()
            self.set_phase("rewind")
            self.tap(TREE_TAB, "Opening the World Tree")
            return 1.5
        if self.phase == "upgrade2":
            self.buy_stat()
            self.cycles += 1
            self.log(f"Cycle {self.cycles} complete.")
            return self.go_battle()
        if self.phase in ("rewind_confirm", "ghost_ok"):
            if not self.waited(POPUP_TIMEOUT):
                return 0.5
            self.set_phase("rewind")
        if self.phase in ("rewind", "elixir", "elixir_ok"):
            self.tap(TREE_TAB, "Opening the World Tree")
            return 1.5
        return self.go_battle()

    def on_skills(self, img):
        if self.phase == "upgrade":
            self.tap(STATS_TAB, "Opening Stats to upgrade")
            return 1.5
        if self.phase in ("rewind_confirm", "ghost_ok"):
            if not self.waited(POPUP_TIMEOUT):
                return 0.5
            self.log("Expected popup didn't show -- trying Rewind again")
            self.set_phase("rewind")
        if self.phase == "rewind":
            if self.vis.has(img, "medallion"):
                self.tap(REWIND_BTN, "Medallion is up -> ghost battle")
                self.set_phase("ghost_ok")
            else:
                self.tap(REWIND_BTN, "Pressing the elixir Rewind button")
                self.set_phase("rewind_confirm")
            return 1.5
        if self.phase == "elixir":
            if self.get_elixir():
                self.tap(ELIXIR_MASTERY_BTN, "Upgrading Elixir Mastery")
                self.set_phase("elixir_ok")
                return 1.5
            self.log("Saving elixir (Elixir Mastery upgrade is off)")
            self.set_phase("upgrade2")
        if self.phase == "elixir_ok":
            if not self.waited(3):
                return 0.5
            self.log("No Elixir Mastery popup (not enough elixir?) -- moving on")
            self.set_phase("upgrade2")
        if self.phase == "upgrade2":
            self.tap(STATS_TAB, "Opening Stats to upgrade")
            return 1.5
        return self.go_battle()

    # -- out of rewinds: Hell Expedition ------------------------------------
    #   exp_heroes  -> open the Heroes tab
    #   exp_team    -> pick team 1-4
    #   exp_battle  -> open the Battle menu
    #   exp_mode    -> pick Expedition
    #   exp_hell    -> pick Hell
    #   exp_confirm -> OK on "Begin Expedition on HELL?"
    #   exp_pause   -> expedition running: press pause
    #   exp_cloud   -> pause menu: press the cloud-save button
    #   exp_save    -> OK on "Cloud Save"
    #   exp_done    -> title screen: stop the bot
    EXP_TIMEOUT = 8.0

    def on_expedition(self, state, img):
        """One step of the expedition hand-off. Returns a delay, or None to let
        the normal screen handling run (e.g. a real human check)."""
        p = self.phase
        if state == "human_check" and not (self.vis.hell_row(img) or self.vis.find_green_button(img)
                                           or self.vis._frac(img, EXP_OK_BOX, self.vis.GREEN) > 0.3):
            return None          # a real human check: let the normal handling stop the bot
        late = self.waited(self.EXP_TIMEOUT)
        if p == "exp_heroes":
            if state == "heroes":
                self.set_phase("exp_team")
                return 0.2
            if state == "rewind_locked":
                self.tap(REWIND_POPUP_CLOSE, "Closing the rewind popup")
                return 1.5
            self.tap(HEROES_TAB, "Opening Heroes")
            return 2.0
        if p == "exp_team":
            if state != "heroes":
                if late:
                    self.set_phase("exp_heroes")
                return 1.0
            team = self.get_expedition()[1]
            self.tap(TEAM_BTNS.get(team, TEAM_BTNS[1]), f"Picking hero team {team}")
            self.sleep(1.0)
            self.set_phase("exp_battle")
            return 0.5
        if p == "exp_battle":
            self.tap(BATTLE_BTN, "Opening Battle menu")
            self.set_phase("exp_mode")
            return 2.0
        if p == "exp_mode":
            if self.vis.hell_row(img):
                self.set_phase("exp_hell")
                return 0.2
            if state == "gamemode":
                self.tap(EXPEDITION_BTN, "Selecting Expedition")
                return 2.0
            if late:
                self.set_phase("exp_battle")
            return 1.0
        if p == "exp_hell":
            if self.vis._frac(img, EXP_OK_BOX, self.vis.GREEN) > 0.3:
                self.set_phase("exp_confirm")
                return 0.2
            if self.vis.hell_row(img):
                self.tap(HELL_BTN, "Selecting Hell")
                return 2.0
            if late:
                self.set_phase("exp_battle")
            return 1.0
        if p == "exp_confirm":
            if state in ("campaign_battle", "ghost_battle"):
                self.log("Expedition started")
                self.set_phase("exp_pause")
                return 3.0
            if self.vis._frac(img, EXP_OK_BOX, self.vis.GREEN) > 0.3:
                x0, y0, x1, y1 = EXP_OK_BOX
                self.tap(((x0 + x1) // 2, (y0 + y1) // 2), "Starting the Hell Expedition")
                return 3.0
            if late:
                self.set_phase("exp_hell")
            return 1.0
        if p == "exp_pause":
            if state in ("campaign_battle", "ghost_battle"):
                self.tap(PAUSE_BTN, "Pausing the expedition")
                self.set_phase("exp_cloud")
                return 2.0
            return 1.0
        if p == "exp_cloud":
            btn = self.find_cloud(img)
            if btn is None:
                self.log("Couldn't find the cloud-save button -- stopping. The expedition keeps running; "
                         "save it from the pause menu yourself.")
                self.save_debug(img, "pause_menu", force=True)
                self.stop_event.set()
                if self.on_done:
                    self.on_done("expedition_unsaved")
                return 0
            self.tap(btn, "Pressing cloud save")
            self.set_phase("exp_save")
            return 2.0
        if p == "exp_save":
            if state == "title_screen":
                self.set_phase("exp_done")
                return 0.2
            btn = self.vis.find_green_button(img)
            if btn:
                self.tap(btn, "Saving and returning to the menu")
                self.set_phase("exp_done")
                return 4.0
            if late:
                self.set_phase("exp_cloud")
            return 1.0
        if p == "exp_done":
            if state == "title_screen" or self.waited(20):
                self.log("Expedition running and saved -- back at the title screen. Bot stopped.")
                self.stop_event.set()
                if self.on_done:
                    self.on_done("expedition")
                return 0
            return 1.0
        return None

    def find_cloud(self, img):
        """The blue cloud-save button on the pause menu: the biggest bright-blue
        blob in the middle of the screen. None if it isn't there."""
        x0, y0, x1, y1 = CLOUD_SEARCH
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (95, 120, 150), (110, 255, 255))
        # the white cloud splits the blue in two halves: join them
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (61, 9)))
        n, _, stats, cents = cv2.connectedComponentsWithStats(mask)
        best = None
        for i in range(1, n):
            w, h, area = stats[i, 2], stats[i, 3], stats[i, 4]
            cx, cy = x0 + int(cents[i][0]), y0 + int(cents[i][1])
            near = abs(cx - CLOUD_BTN[0]) < 110 and abs(cy - CLOUD_BTN[1]) < 90
            if near and 150 < w < 300 and 35 < h < 110 and area > 4000 and (best is None or area > best[0]):
                best = (area, (cx, cy))
        if best is None:
            return None
        # the red FORFEIT button sits right above it on the PAUSED panel
        fx, fy = best[1][0], best[1][1] - 118
        if self.vis._frac(img, (fx - 90, fy - 22, fx + 90, fy + 22), self.vis.RED) < 0.25:
            return None
        return best[1]

    def save_battle(self, result):
        if result in ("WIN", "LOSS") and self.on_ghost_result:
            self.on_ghost_result(result == "WIN")
        path = self.ghosts.finish_recording(result)
        if path:
            self.log(f"Battle video saved: debug/battles/{os.path.basename(path)}")

    def go_battle(self):
        self.set_phase("push")
        self.tap(BATTLE_BTN, "Opening Battle menu")
        return 1.5


if __name__ == "__main__":
    from ui import main
    main()
