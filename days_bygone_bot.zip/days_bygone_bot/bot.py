"""Days Bygone bot: push campaign to max day, upgrade a stat, rewind, repeat.

Run:  python bot.py
"""
import json
import os
import random
import threading
import time

import cv2
import numpy as np

import humanize
from adb import Device, FastCapture
from ghost import GhostFighter
from hunt import HuntReader
from version import VERSION
from vision import Vision

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_PATH = os.path.join(HERE, "settings.json")
DEBUG_DIR = os.path.join(HERE, "debug")

# Tap targets at 1920x1080.
BATTLE_BTN = (1790, 65)
CAMPAIGN_BTN = (830, 305)
GAMEMODE_CLOSE_BTN = (1327, 118)
X2_BTN = (1100, 708)
CHECKIN_CLAIM_BOX = (1200, 860, 1480, 965)     # daily reward CLAIM button area
CHECKIN_CLOSE_BTN = (1475, 122)                 # red X on the Check-In popup
# Inside both the campaign VICTORY red button and the ghost VICTORY one.
VICTORY_BACK_BTN = (860, 885)
STATS_TAB = (75, 225)
TREE_TAB = (75, 980)
REWIND_BTN = (595, 408)
ELIXIR_MASTERY_BTN = (1690, 312)
DEFEAT_RETRY_BTN = (1042, 658)
# Out of rewinds -> Hell Expedition (optional)
REWIND_POPUP_CLOSE = (1413, 95)
HEROES_TAB = (75, 800)
TEAM_BTNS = {1: (240, 1055), 2: (310, 1055), 3: (380, 1055), 4: (450, 1055)}
EXPEDITION_BTN = (900, 668)
DUNGEON_BTN = (900, 483)
HUNT_BTN = (900, 849)
DUNGEON_ENTER = (1597, 859)              # ENTER under the dungeon floor list
DUNGEON_X2_SEARCH = (930, 620, 1320, 800)  # "Enter Floor N of Dungeon?" blue X2 (OK is to its left)
HELL_BTN = (1480, 681)
EXP_OK_BOX = (860, 700, 1065, 760)      # "Begin Expedition on HELL?" OK
PAUSE_BTN = (68, 66)
CLOUD_BTN = (955, 726)                   # pause menu: blue cloud-save button under RESUME / FORFEIT
CLOUD_SEARCH = (600, 560, 1320, 880)     # where to look for it
# Rest mode: coming back from the title screen
TITLE_SIGN = (962, 712)                  # the wooden sign in the middle (tap: refresh, tap again: play)
X2_LOOT_SEARCH = (930, 700, 1370, 880)   # Idle Progress: blue "X2 LOOT" button (~1141, 789)
EVENTS_CLOSE = (1467, 176)               # red X on the Events popup
STAT_BUTTONS = {
    "Damage": (890, 228),
    "Gold": (890, 944),
    "Critical Damage": (1748, 658),
}

# During ghost battles the full screen check runs only on every Nth frame.
FULL_CHECK_EVERY = 4

DEFAULT_SETTINGS = {"stat": "Critical Damage", "elixir_mastery": True, "alert_sound": "", "alert_volume": 100, "phone_alert": "",
                    "expedition_on_max": False, "expedition_team": 1,
                    "rest_on": False, "rest_every": 10, "rest_style": "idle", "rest_min": 10, "rest_max": 20,
                    "rest_mode": "expedition", "hunt_boss": "Asmodeus", "hunt_level": 1,
                    "rewind_team": 1,
                    "run_seconds_total": 0, "auto_revive": False, "daily_summary": True,
                    "rewinds_total": 0, "rewinds_counter": 0,
                    "ghost_losses_total": 0, "ghost_loss_streak": 0, "ghost_loss_streak_best": 0}
# How long to wait for an expected popup before trying again.
POPUP_TIMEOUT = 5.0


def load_settings():
    try:
        with open(SETTINGS_PATH) as f:
            return {**DEFAULT_SETTINGS, **json.load(f)}
    except (OSError, ValueError):
        return dict(DEFAULT_SETTINGS)


def save_settings(settings):
    try:
        with open(SETTINGS_PATH, "w") as f:
            json.dump(settings, f, indent=2)
    except OSError:
        pass


class Bot:
    """Screen-driven state machine. `phase` remembers what we're trying to do,
    the detected screen decides which button to press next."""

    def __init__(self, get_stat, get_elixir, log, status, on_check=None, on_rewind=None, on_ghost_result=None,
                 get_expedition=None, on_done=None, get_rest=None, get_revive=None, on_event=None):
        self.on_event = on_event or (lambda key, value=None: None)
        self.get_revive = get_revive or (lambda: False)
        self.get_rest = get_rest or (lambda: {"on": False})
        self.resting = False
        self.rewinds_since_rest = 0
        self.rest_until = 0.0
        self.rest_len = 0.0
        self._left_quit = self._left_ok = False
        self.hunt = HuntReader()
        self._hunt_tries = 0
        self.get_expedition = get_expedition or (lambda: (False, 1))
        self.on_done = on_done
        self.get_stat = get_stat
        self.get_elixir = get_elixir
        self.on_check = on_check
        self.on_rewind = on_rewind
        self.on_ghost_result = on_ghost_result
        self.log = log
        self.status = status
        self.dev = Device()
        self.vis = Vision()
        self.ghosts = GhostFighter(self.dev, self.vis, log)
        self.fast = FastCapture(self.dev)   # high frame rate, ghost battles only
        self.frame_t = 0.0
        self.fast_frames = 0
        self.last_menu_log = None
        self.stop_event = threading.Event()
        self.phase = "push"
        self.cycles = 0
        self.phase_at = 0.0
        self.unknown_since = None
        self.last_debug_save = 0.0
        self.last_state = None

    # -- helpers ----------------------------------------------------------
    def sleep(self, s):
        self.stop_event.wait(s)

    def gm(self, xy):
        """A Select Gamemode popup button, moved with the popup (it shifts when
        the Hunt boss list is open)."""
        return xy[0] + getattr(self.vis, "last_gm_dx", 0), xy[1]

    def tap(self, xy, why=None):
        """Human-like click: random short wait, then a slightly random spot."""
        self.sleep(humanize.pause())
        if self.stop_event.is_set():
            return
        if why:
            self.log(why)
        self.dev.tap(*humanize.jitter(*xy))

    def save_debug(self, img, label, force=False):
        now = time.time()
        if not force and now - self.last_debug_save < 10:
            return
        self.last_debug_save = now
        os.makedirs(DEBUG_DIR, exist_ok=True)
        files = sorted(os.listdir(DEBUG_DIR))
        for old in files[:-30]:
            try:
                os.remove(os.path.join(DEBUG_DIR, old))
            except OSError:
                pass
        path = os.path.join(DEBUG_DIR, f"{time.strftime('%Y%m%d_%H%M%S')}_{label}.png")
        cv2.imwrite(path, img)
        self.log(f"Saved screenshot: debug/{os.path.basename(path)}")

    # -- main loop --------------------------------------------------------
    def run(self, start_phase):
        self.phase = start_phase
        try:
            self.dev.connect()
        except Exception as e:  # noqa: BLE001 - show any connection problem in the GUI
            self.log(f"ADB connection failed: {e}")
            return
        self.log(f"Days Bygone Bot v{VERSION}. Connected. Starting in phase '{self.phase}'.")
        while not self.stop_event.is_set():
            if self.fast.running:
                got = self.fast.next(after=self.frame_t)
                if got is None:
                    self.log("Fast capture stalled -- back to normal screenshots")
                    self.fast.stop()
                    continue
                self.frame_t, img = got
                self.fast_frames += 1
            else:
                try:
                    self.frame_t = time.monotonic()
                    img = self.dev.screenshot()
                except Exception as e:  # noqa: BLE001
                    self.log(f"Screenshot failed: {e}")
                    self.sleep(2)
                    continue
            if (self.fast.running and self.fast_frames % FULL_CHECK_EVERY
                    and self.last_state == "ghost_battle" and self.vis.has(img, "pause")):
                state = "ghost_battle"   # cheap check; the full one (~47 ms) runs every few frames
            else:
                state = self.vis.detect_state(img)
            # look much more often while fighting ghosts, normal speed otherwise
            if state == "ghost_battle" and not self.fast.running:
                self.fast.start()
            elif state != "ghost_battle" and self.fast.running:
                self.fast.stop()
            if state != self.last_state and state != "ghost_battle":
                self.log(f"Screen: {state}")
            self.last_state = state
            self.status(state, self.phase, self.cycles)
            delay = self.handle(state, img)
            if delay:
                self.sleep(delay)
        self.fast.stop()
        self.save_battle("STOPPED")
        self.dev.close()
        self.log("Stopped.")

    # Phases, in loop order:
    #   push            -> campaign running / heading to battle
    #   upgrade         -> max day reached: buy the stat, then go to the tree
    #   rewind          -> on the tree: press the Rewind button
    #   ghost_ok        -> pressed the medallion, waiting for OK / ghost battle
    #   ghost           -> fighting ghosts
    #   rewind_confirm  -> pressed the elixir Rewind button, waiting for the green Rewind
    #   elixir          -> rewound: maybe upgrade Elixir Mastery
    #   elixir_ok       -> pressed Elixir Mastery, waiting for OK
    #   upgrade2        -> buy the stat again, then push
    def set_phase(self, phase):
        if phase != self.phase:
            self.phase = phase
            self.phase_at = time.monotonic()

    def waited(self, seconds):
        return time.monotonic() - self.phase_at > seconds

    def buy_stat(self):
        stat = self.get_stat()
        self.tap(STAT_BUTTONS[stat], f"Upgrading {stat}")
        self.tap(STAT_BUTTONS[stat])

    def handle(self, state, img):
        if state != "unknown":
            self.unknown_since = None

        if self.phase.startswith(("exp_", "rest_", "hunt_")):
            delay = self.on_expedition(state, img)
            if delay is not None:
                return delay

        if state == "human_check":
            # The game is asking whether a human is playing. The bot never
            # answers these: stop and hand control back to the player.
            self.log("HUMAN CHECK on screen -- bot stopped. Answer it yourself, then press START.")
            self.save_debug(img, "human_check", force=True)
            self.stop_event.set()
            if self.on_check:
                self.on_check(self.phase)
            return 0

        if state == "rewind_locked":
            on, team = self.get_expedition()
            if on:
                self.log("Out of rewinds (timer on the Rewind button) -> starting a Hell Expedition")
                self.tap(REWIND_POPUP_CLOSE, "Closing the rewind popup")
                self.set_phase("exp_heroes")
                return 1.5
            self.log("Out of rewinds (timer on the Rewind button) -- bot stopped.")
            self.save_debug(img, "rewinds_out", force=True)
            self.stop_event.set()
            if self.on_done:
                self.on_done("rewinds_out")
            return 0

        if state == "ghost_battle":
            if self.phase != "ghost":
                self.log("Ghost battle! Fighting...")
                self.ghosts.reset()
                self.set_phase("ghost")
            self.ghosts.step(img, self.frame_t)
            return 0

        if state in ("victory", "defeat", "result"):
            found = self.vis.result_buttons(img)
            red = found[1] if found else VICTORY_BACK_BTN
            green = found[2] if found and found[2] else DEFEAT_RETRY_BTN
            in_ghost = self.phase in ("ghost", "ghost_ok")
            if state == "result":
                # Banner didn't match: a red+green pair is a ghost DEFEAT during
                # ghost battles, otherwise a campaign VICTORY.
                state = "defeat" if (in_ghost and found[0] == "pair") else "victory"
            if state == "defeat":
                self.save_battle("LOSS")
                self.tap(green, "Defeat -> retrying")
                self.set_phase("ghost_ok")
            elif in_ghost:
                self.save_battle("WIN")
                self.tap(red, "Ghosts beaten -> going back")
                self.set_phase("rewind")
            else:
                self.tap(red, "Max day reached -> going back")
                self.set_phase("upgrade")
            return 2.0

        if state == "campaign_battle":
            if self.phase == "push":
                found = self.campaign_defeat(img)
                if found:
                    revive, back = found
                    if revive and self.get_revive():
                        self.tap(revive, "Campaign defeat -> Revive")
                        self.on_event("revives")
                        return 3.0
                    if back:
                        self.tap(back, "Campaign defeat -> going back (no revive)")
                        self.set_phase("upgrade")
                        return 2.0
            return 2.0

        if state == "gamemode":
            self.on_event("day", self.vis.campaign_day(img))
            at_max = self.vis.campaign_at_max(img)
            if at_max:
                self.log("Already at max day -> upgrade + rewind")
                self.set_phase("upgrade")
                self.tap(self.gm(GAMEMODE_CLOSE_BTN), "Closing Battle menu")
                return 1.5
            if at_max is None:
                self.log("Couldn't read the campaign day -- starting campaign anyway")
            self.tap(self.gm(CAMPAIGN_BTN), "Selecting Campaign")
            return 1.5

        if state == "campaign_confirm":
            self.tap(X2_BTN, "Starting Campaign (x2)")
            self.set_phase("push")
            return 2.0

        if state == "checkin":
            # Daily reward: press CLAIM (green), then the red X once it says CLAIMED.
            btn = self.vis.find_green_button(img)
            x0, y0, x1, y1 = CHECKIN_CLAIM_BOX
            if btn and x0 <= btn[0] <= x1 and y0 <= btn[1] <= y1:
                self.tap(btn, "Claiming daily reward")
                return 2.0
            self.tap(CHECKIN_CLOSE_BTN, "Closing daily reward")
            return 1.5

        if state in ("worldtree", "settings", "journal"):
            # A game menu is open (World Tree / Settings / Journal) -- leave it
            # alone and wait; it isn't a human check.
            if self.last_menu_log != state:
                self.log(f"{state.title()} menu is open -- waiting for it to close")
                self.last_menu_log = state
            return 2.0
        self.last_menu_log = None

        if state == "popup_ok":
            btn = self.vis.find_green_button(img)
            if btn and self.phase == "ghost_ok":
                self.tap(btn, "Pressing OK -> ghost battle")
                return 1.5
            if btn and self.phase == "rewind_confirm":
                self.tap(btn, "Pressing Rewind")
                self.rewinds_since_rest += 1
                self.set_phase("elixir")
                if self.on_rewind:
                    self.on_rewind()
                return 2.0
            if btn and self.phase == "elixir_ok":
                self.tap(btn, "Pressing OK (Elixir Mastery)")
                self.set_phase("upgrade2")
                return 1.5
            self.save_debug(img, "popup")
            self.log("Popup I don't know -- waiting (you can click it yourself)")
            return 2.0

        if state == "stats":
            return self.on_stats()
        if state == "skills":
            return self.on_skills(img)

        # unknown
        if self.unknown_since is None:
            self.unknown_since = time.monotonic()
        elif time.monotonic() - self.unknown_since > 8:
            self.save_debug(img, "unknown")
        return 1.0

    def on_stats(self):
        if self.phase == "upgrade":
            self.buy_stat()
            self.set_phase("rewind")
            self.tap(TREE_TAB, "Opening the World Tree")
            return 1.5
        if self.phase == "upgrade2":
            self.buy_stat()
            self.cycles += 1
            self.log(f"Cycle {self.cycles} complete.")
            rest = self.get_rest()
            if rest.get("on") and self.rewinds_since_rest >= rest.get("every", 10):
                return self.start_rest(rest)
            return self.go_battle()
        if self.phase in ("rewind_confirm", "ghost_ok"):
            if not self.waited(POPUP_TIMEOUT):
                return 0.5
            self.set_phase("rewind")
        if self.phase in ("rewind", "elixir", "elixir_ok"):
            self.tap(TREE_TAB, "Opening the World Tree")
            return 1.5
        return self.go_battle()

    def on_skills(self, img):
        if self.phase == "upgrade":
            self.tap(STATS_TAB, "Opening Stats to upgrade")
            return 1.5
        if self.phase in ("rewind_confirm", "ghost_ok"):
            if not self.waited(POPUP_TIMEOUT):
                return 0.5
            self.log("Expected popup didn't show -- trying Rewind again")
            self.set_phase("rewind")
        if self.phase == "rewind":
            if self.vis.has(img, "medallion"):
                self.tap(REWIND_BTN, "Medallion is up -> ghost battle")
                self.set_phase("ghost_ok")
            else:
                self.tap(REWIND_BTN, "Pressing the elixir Rewind button")
                self.set_phase("rewind_confirm")
            return 1.5
        if self.phase == "elixir":
            if self.get_elixir():
                self.tap(ELIXIR_MASTERY_BTN, "Upgrading Elixir Mastery")
                self.set_phase("elixir_ok")
                return 1.5
            self.log("Saving elixir (Elixir Mastery upgrade is off)")
            self.set_phase("upgrade2")
        if self.phase == "elixir_ok":
            if not self.waited(3):
                return 0.5
            self.log("No Elixir Mastery popup (not enough elixir?) -- moving on")
            self.set_phase("upgrade2")
        if self.phase == "upgrade2":
            self.tap(STATS_TAB, "Opening Stats to upgrade")
            return 1.5
        return self.go_battle()

    # -- out of rewinds: Hell Expedition ------------------------------------
    #   exp_heroes  -> open the Heroes tab
    #   exp_team    -> pick team 1-4
    #   exp_battle  -> open the Battle menu
    #   exp_mode    -> pick Expedition
    #   exp_hell    -> pick Hell
    #   exp_confirm -> OK on "Begin Expedition on HELL?"
    #   exp_pause   -> expedition running: press pause
    #   exp_cloud   -> pause menu: press the cloud-save button
    #   exp_save    -> OK on "Cloud Save"
    #   exp_done    -> title screen: stop the bot
    EXP_TIMEOUT = 8.0

    def on_expedition(self, state, img):
        """One step of the expedition hand-off. Returns a delay, or None to let
        the normal screen handling run (e.g. a real human check)."""
        p = self.phase
        if state == "human_check" and not (self.vis.hell_row(img) or self.vis.find_green_button(img)
                                           or self.vis._frac(img, EXP_OK_BOX, self.vis.GREEN) > 0.3
                                           or self.find_blue_x2(img, DUNGEON_X2_SEARCH)
                                           or (p.startswith(("rest_", "hunt_")) and (self.find_x2_loot(img)
                                                                          or self.events_popup(img)
                                                                          or self.find_cloud(img)))):
            return None          # a real human check: let the normal handling stop the bot
        late = self.waited(self.EXP_TIMEOUT)
        if p == "exp_heroes":
            if state == "heroes":
                self.set_phase("exp_team")
                return 0.2
            if state == "rewind_locked":
                self.tap(REWIND_POPUP_CLOSE, "Closing the rewind popup")
                return 1.5
            self.tap(HEROES_TAB, "Opening Heroes")
            return 2.0
        if p == "exp_team":
            if state != "heroes":
                if late:
                    self.set_phase("exp_heroes")
                return 1.0
            team = self.get_expedition()[1]
            self.tap(TEAM_BTNS.get(team, TEAM_BTNS[1]), f"Picking hero team {team}")
            self.sleep(1.0)
            self.set_phase("exp_battle")
            return 0.5
        if p == "exp_battle":
            self._dungeon_tapped = False
            self.tap(BATTLE_BTN, "Opening Battle menu")
            self.set_phase("exp_mode")
            return 2.0
        if p == "exp_mode":
            mode = self.rest_mode()
            if mode == "hunt":
                if self.hunt.headers(img):
                    self._hunt_tries = 0
                    self.set_phase("hunt_pick")
                    return 0.2
                if state == "gamemode":
                    self.tap(self.gm(HUNT_BTN), "Selecting Hunt")
                    return 2.5
                if late:
                    self.set_phase("exp_battle")
                return 1.0
            if mode == "dungeon":
                if self.find_blue_x2(img, DUNGEON_X2_SEARCH):
                    self.set_phase("exp_dungeon")
                    return 0.2
                if not self._dungeon_tapped:
                    if state not in ("gamemode", "human_check", "popup_ok"):
                        if late:
                            self.set_phase("exp_battle")
                        return 1.0
                    self.tap(self.gm(DUNGEON_BTN), "Selecting Dungeon")
                    self._dungeon_tapped = True
                    return 2.5
                self.tap(DUNGEON_ENTER, "Pressing ENTER")
                self.set_phase("exp_dungeon")
                return 2.0
            if self.vis.hell_row(img):
                self.set_phase("exp_hell")
                return 0.2
            if state == "gamemode":
                self.tap(self.gm(EXPEDITION_BTN), "Selecting Expedition")
                return 2.0
            if late:
                self.set_phase("exp_battle")
            return 1.0
        if p == "hunt_pick":
            return self.hunt_pick(img)
        if p == "hunt_ok":
            if state in ("campaign_battle", "ghost_battle"):
                self.set_phase("exp_confirm")
                return 0.2
            btn = self.vis.find_green_button(img)
            if btn:
                r = self.get_rest()
                self.tap(btn, f"Starting Hunt: {r.get('boss')} {r.get('level')}")
                self.set_phase("exp_confirm")
                return 3.0
            if late:
                self.set_phase("hunt_pick")
            return 1.0
        if p == "exp_dungeon":
            if state in ("campaign_battle", "ghost_battle"):
                self.set_phase("exp_confirm")
                return 0.2
            btn = self.find_blue_x2(img, DUNGEON_X2_SEARCH)
            if btn:
                self.tap(btn, "Entering the dungeon with X2 loot")
                self.set_phase("exp_confirm")
                return 3.0
            if late:
                self.set_phase("exp_battle")
                return 1.0
            if self.waited(3):
                self.tap(DUNGEON_ENTER, "Pressing ENTER")
                return 2.0
            return 1.0
        if p == "exp_hell":
            if self.vis._frac(img, EXP_OK_BOX, self.vis.GREEN) > 0.3:
                self.set_phase("exp_confirm")
                return 0.2
            if self.vis.hell_row(img):
                self.tap(HELL_BTN, "Selecting Hell")
                return 2.0
            if late:
                self.set_phase("exp_battle")
            return 1.0
        if p == "exp_confirm":
            if state in ("campaign_battle", "ghost_battle"):
                self.log((self.rest_label() if self.resting else "Expedition") + " started")
                if self.resting and self.rest_style() == "active":
                    self.rest_until = time.monotonic() + self.rest_len
                    self.log(f"Active rest: letting it play on auto for {self.rest_len / 60:.0f} min")
                    self.set_phase("rest_active")
                    return 3.0
                self.set_phase("exp_pause")
                return 3.0
            if self.vis._frac(img, EXP_OK_BOX, self.vis.GREEN) > 0.3:
                x0, y0, x1, y1 = EXP_OK_BOX
                self.tap(((x0 + x1) // 2, (y0 + y1) // 2), "Starting the Hell Expedition")
                return 3.0
            if late:
                self.set_phase("exp_hell")
            return 1.0
        if p == "exp_pause":
            if state in ("campaign_battle", "ghost_battle"):
                self.tap(PAUSE_BTN, "Pausing the expedition")
                self.set_phase("exp_cloud")
                return 2.0
            return 1.0
        if p == "exp_cloud":
            btn = self.find_cloud(img)
            if btn is None and not late:
                # the pause menu may still be opening; if it never showed, pause again (once)
                if self.waited(4) and not getattr(self, "_repaused", False) and state == "campaign_battle":
                    self._repaused = True
                    self.tap(PAUSE_BTN, "Pausing again")
                return 1.0
            self._repaused = False
            if btn is None:
                self.log("Couldn't find the cloud-save button -- stopping. The expedition keeps running; "
                         "save it from the pause menu yourself.")
                self.save_debug(img, "pause_menu", force=True)
                self.stop_event.set()
                if self.on_done:
                    self.on_done("expedition_unsaved")
                return 0
            self.tap(btn, "Pressing cloud save")
            self.set_phase("exp_save")
            return 2.0
        if p == "exp_save":
            if state == "title_screen":
                self.set_phase("exp_done")
                return 0.2
            btn = self.vis.find_green_button(img)
            if btn:
                self.tap(btn, "Saving and returning to the menu")
                self.set_phase("exp_done")
                return 4.0
            if late:
                self.set_phase("exp_cloud")
            return 1.0
        if p == "exp_done" and self.resting:
            if state == "title_screen" or self.waited(20):
                if self.rest_until == 0:
                    # idle rest: the expedition keeps going while we sit on the title screen
                    self.rest_until = time.monotonic() + self.rest_len
                    self.log(f"Idle rest: waiting {self.rest_len / 60:.0f} min on the title screen")
                    self.set_phase("rest_idle")
                else:
                    self.set_phase("rest_wake")      # active rest already done
                return 1.0
            return 1.0
        if p == "exp_done":
            if state == "title_screen" or self.waited(20):
                self.log("Expedition running and saved -- back at the title screen. Bot stopped.")
                self.stop_event.set()
                if self.on_done:
                    self.on_done("expedition")
                return 0
            return 1.0
        if p in ("rest_active", "rest_idle"):
            left = self.rest_until - time.monotonic()
            if left > 0:
                self.status(state, f"resting, {left / 60:.0f} min left", self.cycles)
                return min(10.0, left)
            self.log("Rest over")
            self._left_quit = self._left_ok = False
            self.set_phase("rest_leave" if p == "rest_active" else "rest_wake")
            return 0.5
        if p == "rest_leave":
            # active rest done: pause -> LEAVE / FORFEIT -> OK -> back on the results
            found = self.vis.result_buttons(img)
            back = found[1] if found else (self.find_back(img) if self._left_ok else None)
            if back and self.double_loot(img):
                return 2.0
            if back:
                self._x2_tapped = False
                self.tap(back, "Back from the results")
                self._left_ok = False
                self.set_phase("rest_team")
                return 3.0
            if state in ("stats", "skills", "heroes"):
                self.set_phase("rest_team")
                return 0.5
            quit_btn = self.find_quit(img)
            if quit_btn:
                self.tap(quit_btn, "Leaving (Forfeit / Leave / Return)")
                self._left_quit = True
                return 2.0
            greens = self.vis._find_rects(img, self.vis.GREEN_BTN) if self._left_quit else []
            green = self.vis.find_green_button(img) or (greens[0][:2] if greens else None)
            if green and self._left_quit and not self._left_ok:
                self.tap(green, "OK")
                self._left_ok = True
                return 3.0
            if self._left_ok and not self.waited(30):
                return 1.5                 # results popup on its way
            if state in ("campaign_battle", "ghost_battle"):
                self.tap(PAUSE_BTN, "Pausing")
                return 2.0
            if self.waited(60):
                self.log("Couldn't leave the battle after resting -- bot stopped.")
                self.save_debug(img, "rest_leave", force=True)
                self.stop_event.set()
                if self.on_done:
                    self.on_done("rest_stuck")
                return 0
            return 1.5
        if p == "rest_wake":
            if state == "checkin":
                return None                   # daily reward: the normal handling claims it
            if state == "title_screen":
                self.tap(TITLE_SIGN, "Tapping the sign")
                return 4.0
            btn = self.find_x2_loot(img)
            if btn:
                self.tap(btn, "Collecting idle rewards (X2 LOOT)")
                return 3.0
            if self.events_popup(img):
                self.tap(EVENTS_CLOSE, "Closing Events")
                return 2.0
            if state in ("stats", "skills", "heroes"):
                self.set_phase("rest_team")
                return 0.5
            if self.waited(120):
                self.log("Couldn't get back into the game after resting -- bot stopped.")
                self.save_debug(img, "rest_wake", force=True)
                self.stop_event.set()
                if self.on_done:
                    self.on_done("rest_stuck")
                return 0
            return 2.0
        if p == "rest_team":
            team = self.get_rest().get("rewind_team", 1)
            if state == "heroes":
                self.tap(TEAM_BTNS.get(team, TEAM_BTNS[1]), f"Back to rewind team {team}")
                self.sleep(1.0)
                self.resting = False
                self.rest_until = 0.0
                self.log("Rest finished -- back to rewinding")
                self.on_event("rests")
                return self.go_battle()
            if state in ("checkin", "human_check"):
                return None
            if self.waited(self.EXP_TIMEOUT * 2):
                self.set_phase("rest_wake")
                return 1.0
            self.tap(HEROES_TAB, "Opening Heroes")
            return 2.0
        return None

    def rest_mode(self):
        """Where a rest goes: 'expedition' or 'dungeon' (Hunt isn't automated yet)."""
        if not self.resting:
            return "expedition"
        mode = self.get_rest().get("mode", "expedition")
        if mode == "hunt" and not self.hunt.ready():
            return "expedition"
        return mode if mode in ("expedition", "dungeon", "hunt") else "expedition"

    def rest_style(self):
        """Hunt has no cloud save (always active); Dungeon rests are always idle."""
        mode = self.rest_mode()
        if mode == "hunt":
            return "active"
        if mode == "dungeon":
            return "idle"
        return self.get_rest().get("style", "idle")

    def rest_label(self):
        mode = self.rest_mode()
        if mode == "hunt":
            r = self.get_rest()
            return f"Hunt {r.get('boss', 'Asmodeus')} {r.get('level', 1)}"
        return "Dungeon" if mode == "dungeon" else "Hell Expedition"

    def find_blue_x2(self, img, box):
        """A wide blue button (X2 / X2 LOOT) inside box, with a green button to its left."""
        x0, y0, x1, y1 = box
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (95, 120, 150), (110, 255, 255))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (61, 9)))
        n, _, stats, cents = cv2.connectedComponentsWithStats(mask)
        for i in range(1, n):
            w, h, area = stats[i, 2], stats[i, 3], stats[i, 4]
            if 180 < w < 400 and 35 < h < 110 and area > 6000:
                cx, cy = x0 + int(cents[i][0]), y0 + int(cents[i][1])
                if self.vis._frac(img, (cx - 460, cy - 25, cx - 200, cy + 25), self.vis.GREEN) > 0.2:
                    return cx, cy
        return None

    def find_loot_x2(self, img):
        """Yellow 'X2' next to LOOT on a results popup (doubles the loot)."""
        x0, y0, x1, y1 = 1040, 440, 1320, 720
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        m = cv2.dilate(cv2.inRange(hsv, (22, 150, 180), (34, 255, 255)), np.ones((9, 9), np.uint8))
        n, _, stats, cents = cv2.connectedComponentsWithStats(m)
        for i in range(1, n):
            w, h, area = stats[i, 2], stats[i, 3], stats[i, 4]
            if 35 < w < 110 and 20 < h < 70 and area > 600:
                return x0 + int(cents[i][0]), y0 + int(cents[i][1])
        return None

    def double_loot(self, img):
        """Tap the results X2 once per results popup. True if it tapped."""
        if getattr(self, "_x2_tapped", False):
            return False
        btn = self.find_loot_x2(img)
        if not btn:
            return False
        self._x2_tapped = True
        self.tap(btn, "Doubling the loot (X2)")
        return True

    REVIVE_SEARCH = (900, 640, 1300, 800)

    def campaign_defeat(self, img):
        """Campaign DEFEAT popup (lives ran out): small red back + green retry +
        blue REVIVE in one row. Returns (revive_xy or None, back_xy) or None."""
        x0, y0, x1, y1 = self.REVIVE_SEARCH
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        m = cv2.inRange(hsv, (95, 120, 150), (110, 255, 255))
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (61, 9)))
        n, _, stats, cents = cv2.connectedComponentsWithStats(m)
        revive = None
        for i in range(1, n):
            w, h, area = stats[i, 2], stats[i, 3], stats[i, 4]
            if 170 < w < 320 and 35 < h < 90 and area > 5000:
                cx, cy = x0 + int(cents[i][0]), y0 + int(cents[i][1])
                if self.vis._frac(img, (cx - 260, cy - 20, cx - 120, cy + 20), self.vis.GREEN) > 0.3:
                    revive = (cx, cy)
        if revive is None:
            return None
        # red back button: left of the green one, same row
        cx, cy = revive
        hsv = cv2.cvtColor(img[cy - 40:cy + 40, cx - 520:cx - 200], cv2.COLOR_BGR2HSV)
        r = cv2.inRange(hsv, (0, 140, 70), (8, 255, 255)) | cv2.inRange(hsv, (172, 140, 70), (180, 255, 255))
        ys, xs = np.where(r > 0)
        if len(xs) < 800:
            return None                      # no red back button: not the defeat popup
        return revive, (cx - 520 + int(xs.mean()), cy - 40 + int(ys.mean()))

    def find_back(self, img):
        """Red 'back' button at the bottom of a results popup (Expedition results
        have small red / green / blue Revive buttons): the leftmost red button."""
        x0, y0, x1, y1 = 600, 700, 1320, 920
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        m = cv2.inRange(hsv, (0, 140, 70), (8, 255, 255)) | cv2.inRange(hsv, (172, 140, 70), (180, 255, 255))
        n, _, stats, cents = cv2.connectedComponentsWithStats(m)
        cands = [(x0 + int(cents[i][0]), y0 + int(cents[i][1])) for i in range(1, n)
                 if 70 < stats[i, 2] < 420 and 35 < stats[i, 3] < 110 and stats[i, 4] > 3000]
        return min(cands) if cands else None

    def find_quit(self, img):
        """Pause menu's red LEAVE (dungeon) / FORFEIT (expedition) button: right above the
        cloud button. Hunt has no cloud: its RETURN is the lowest of two red buttons."""
        cloud = self.find_cloud(img)
        if cloud:
            return cloud[0], cloud[1] - 118
        if self.rest_mode() != "hunt":
            return None
        reds = [r for r in self.vis._find_rects(img, self.vis.RED_BTN)
                if 150 < r[2] < 300 and 500 < r[1] < 900 and abs(r[0] - 960) < 260]
        greens = [g for g in self.vis._find_rects(img, self.vis.GREEN_BTN) if g[1] < 600]
        if len(reds) >= 2 and greens:           # RESUME (green) above RESTART + RETURN (red)
            r = max(reds, key=lambda r: r[1])
            return r[0], r[1]
        return None

    HUNT_MAX_TRIES = 14

    def hunt_pick(self, img):
        """Open the chosen boss's level list, scroll to the level and tap it."""
        r = self.get_rest()
        boss, level = r.get("boss", "Asmodeus"), int(r.get("level", 1))
        heads = self.hunt.headers(img)
        self._hunt_tries += 1
        if self._hunt_tries > self.HUNT_MAX_TRIES or not heads:
            self.log(f"Couldn't find {boss} {level} in the Hunt list -- bot stopped.")
            self.save_debug(img, "hunt_pick", force=True)
            self.stop_event.set()
            if self.on_done:
                self.on_done("rest_stuck")
            return 0
        if boss not in heads:
            return 1.0
        top = heads[boss] + 50
        below = [y for y in heads.values() if y > heads[boss]]
        bottom = min(below) - 40 if below else 1075
        rows = [row for row in self.hunt.rows(img, top, bottom)] if bottom - top > 100 else []
        if not rows:
            self.tap((1530, heads[boss]), f"Opening {boss}")
            return 2.0
        want = [row for row in rows if row[0] == level]
        if want:
            lv, y, locked = want[0]
            if locked:
                unlocked = [row for row in rows if not row[2]]
                if not unlocked:
                    self.log(f"{boss} {level} is locked -- bot stopped.")
                    self.stop_event.set()
                    if self.on_done:
                        self.on_done("rest_stuck")
                    return 0
                lv, y, _ = max(unlocked)
                self.log(f"{boss} {level} is locked -- using {boss} {lv} instead")
            self.tap((1530, y), f"Picking {boss} {lv}")
            self.set_phase("hunt_ok")
            return 2.0
        levels = [row[0] for row in rows]
        mid = (top + bottom) // 2
        if level < min(levels):
            self.dev.swipe(1530, mid - 120, 1530, mid + 120, 450)    # finger down: earlier levels
        else:
            self.dev.swipe(1530, mid + 120, 1530, mid - 120, 450)    # finger up: later levels
        return 1.5

    def start_rest(self, rest):
        lo, hi = rest.get("min", 10), rest.get("max", 20)
        self.rest_len = random.uniform(min(lo, hi), max(lo, hi)) * 60
        self.rewinds_since_rest = 0
        self.resting = True
        self.rest_until = 0.0
        self.log(f"Rest time: {self.rest_style()} rest for {self.rest_len / 60:.0f} min "
                 f"({self.rest_label()})")
        if self.rest_style() != rest.get("style", "idle"):
            self.log(f"{self.rest_label()} rests are always {self.rest_style()}")

        self.set_phase("exp_heroes")
        self.tap(HEROES_TAB, "Opening Heroes")
        return 2.0

    def find_x2_loot(self, img):
        """Idle Progress popup: the blue X2 LOOT button (with the green CLAIM to its left)."""
        return self.find_blue_x2(img, X2_LOOT_SEARCH)

    def events_popup(self, img):
        """The Events popup (Elixir Rush / Ticket Rush) shown after coming back in."""
        x, y = EVENTS_CLOSE
        return (self.vis.menu_dimmed(img)
                and self.vis._frac(img, (x - 30, y - 30, x + 30, y + 30), self.vis.RED) > 0.25)

    def find_cloud(self, img):
        """The blue cloud-save button on the pause menu: the biggest bright-blue
        blob in the middle of the screen. None if it isn't there."""
        x0, y0, x1, y1 = CLOUD_SEARCH
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (95, 120, 150), (110, 255, 255))
        # the white cloud splits the blue in two halves: join them
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (61, 9)))
        n, _, stats, cents = cv2.connectedComponentsWithStats(mask)
        best = None
        for i in range(1, n):
            w, h, area = stats[i, 2], stats[i, 3], stats[i, 4]
            cx, cy = x0 + int(cents[i][0]), y0 + int(cents[i][1])
            near = abs(cx - CLOUD_BTN[0]) < 230 and abs(cy - CLOUD_BTN[1]) < 90
            if near and 150 < w < 300 and 35 < h < 110 and area > 4000 and (best is None or area > best[0]):
                best = (area, (cx, cy))
        if best is None:
            return None
        # the red FORFEIT button sits right above it on the PAUSED panel
        fx, fy = best[1][0], best[1][1] - 118
        if self.vis._frac(img, (fx - 90, fy - 22, fx + 90, fy + 22), self.vis.RED) < 0.25:
            return None
        return best[1]

    def save_battle(self, result):
        if result in ("WIN", "LOSS") and self.on_ghost_result:
            self.on_ghost_result(result == "WIN")
        path = self.ghosts.finish_recording(result)
        if path:
            self.log(f"Battle video saved: debug/battles/{os.path.basename(path)}")

    def go_battle(self):
        self.set_phase("push")
        self.tap(BATTLE_BTN, "Opening Battle menu")
        return 1.5


if __name__ == "__main__":
    from ui import main
    main()
