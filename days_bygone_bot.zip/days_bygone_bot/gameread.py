"""Reads World Tree planner stats from the game (bot must be stopped).

Skills screen  -> Elixir Mastery level
World Tree     -> total apples (the number after "/" in the top-right counter)
  Traveller tab -> Raison D'etre info: Starforce ("490/450" -> 490)
                -> Ascende Superius info: 15-star heroes ("1/10" -> 1)
Settings > Journal > Overview -> Health and Mana
"""
import re
import time

import humanize
import ocr

# Tap targets (1920x1080)
STATS_TAB = (75, 225)
TREE_TAB = (75, 980)
WORLD_TREE_BTN = (470, 215)
WORLD_TREE_CLOSE = (1578, 72)
TRAVELLER_TAB = (805, 162)
RD_NODE = (797, 683)          # Raison D'etre  -> "490/450 Starforce"
AS_NODE = (1000, 683)         # Ascende Superius -> "1/10 Maxforce" (15-star heroes)
INFO_ICON = (450, 897)        # tapping the selected skill's icon shows its description
INFO_LINES = [(918, 966), (878, 926), (838, 886)]   # description lines, bottom first
INFO_X = (560, 1240)
SETTINGS_BTN = (1605, 65)
SETTINGS_CLOSE = (1477, 80)
JOURNAL_BTN = (1045, 210)
JOURNAL_CLOSE = (1797, 103)

# Where each number is (x0, y0, x1, y1), its colour, font, and whether to join dotted strokes
FIELDS = {
    "elixir_mastery": ((785, 335, 945, 380), "orange", "level", False),
    "apples": ((1370, 52, 1480, 98), "white", "counter", True),
    "max_hp": ((1500, 540, 1640, 582), "white", "journal", False),
    "mana": ((1500, 590, 1640, 632), "white", "journal", False),
}
WAIT = 1.6


class GameReader:
    def __init__(self, device, vision, log):
        self.dev = device
        self.vis = vision
        self.log = log
        self.reader = ocr.GlyphReader()
        self.crops = {}      # field -> crop, kept so typed-in values can teach the reader

    def _tap(self, xy):
        time.sleep(humanize.pause())
        self.dev.tap(*humanize.jitter(*xy))
        time.sleep(WAIT)
        return self.dev.screenshot()

    def _read(self, img, field):
        (x0, y0, x1, y1), color, font, join = FIELDS[field]
        crop = img[y0:y1, x0:x1].copy()
        self.crops[field] = crop
        return self.reader.read(crop, color, font, join)

    def _read_info(self, img):
        """The 'N/M' in a skill's description (yellow text), or None."""
        x0, x1 = INFO_X
        for y0, y1 in INFO_LINES:
            got = self.reader.read_fraction(img[y0:y1, x0:x1], "yellow", "info")
            if got:
                return got
        return None

    def _expect(self, img, state, what):
        if self.vis.detect_state(img) != state:
            raise RuntimeError(f"Expected the {what} screen but didn't find it -- stopped reading.")

    def read_all(self):
        """Returns {field: text or None}. None = couldn't read it (type it in)."""
        self.dev.connect()
        out = {}
        img = self.dev.screenshot()
        state = self.vis.detect_state(img)
        if state == "stats":
            img = self._tap(TREE_TAB)
            state = self.vis.detect_state(img)
        if state != "skills":
            raise RuntimeError("Go to the Skills screen (World Tree tab) in the game first.")

        # Elixir Mastery (top of the skills list)
        if self.vis.has(img, "elixir_title"):
            text = self._read(img, "elixir_mastery")
            m = re.fullmatch(r"Lv\.([1-9]\d*(?:\.\d+)?[a-zA-Z]{0,2})", text or "")
            out["elixir_mastery"] = m.group(1) if m else None
        else:
            self.log("Elixir Mastery isn't at the top of the skills list -- scroll it up to read it.")
            out["elixir_mastery"] = None

        # Apples
        img = self._tap(WORLD_TREE_BTN)
        self._expect(img, "worldtree", "World Tree")
        text = self._read(img, "apples")
        m = re.fullmatch(r"(\d+)/([1-9]\d*)", text or "")
        out["apples"] = m.group(2) if m and int(m.group(1)) <= int(m.group(2)) else None

        # Starforce and 15-star heroes: Traveller tab -> skill -> its icon
        self._tap(TRAVELLER_TAB)
        for field, node in (("starforce", RD_NODE), ("fifteen", AS_NODE)):
            self._tap(node)
            img = self._tap(INFO_ICON)
            got = self._read_info(img)
            out[field] = str(got[0]) if got else None
        img = self._tap(WORLD_TREE_CLOSE)

        # Health and Mana
        img = self._tap(SETTINGS_BTN)
        self._expect(img, "settings", "Settings")
        img = self._tap(JOURNAL_BTN)
        self._expect(img, "journal", "Journal")
        for field in ("max_hp", "mana"):
            text = self._read(img, field)
            out[field] = text if text and re.fullmatch(r"[1-9]\d*", text) else None
        img = self._tap(JOURNAL_CLOSE)
        if self.vis.detect_state(img) == "settings":
            self._tap(SETTINGS_CLOSE)
        return out

    def learn(self, field, value):
        """The player typed the real value for a field we couldn't read:
        learn its characters so next time it reads on its own."""
        crop = self.crops.get(field)
        if crop is None or not value:
            return False
        _, color, font, join = FIELDS[field]
        text = {"elixir_mastery": "Lv." + value}.get(field, value)
        if field == "apples":
            chars, _ = ocr.segment(crop, color, join)
            # counter is "used/total": we only know the total, learn just its digits
            n = len(value)
            if len(chars) < n + 2:
                return False
            return ocr.learn_chars(chars[-n:], value, font)
        ok = ocr.learn(crop, color, font, text, join)
        if ok:
            self.reader = ocr.GlyphReader()
        return ok
