"""Window chrome: custom title bar for the main window, app icon, and dark
title bars for the other windows (Windows only)."""
import ctypes
import os
import tkinter as tk
import tkinter.font

from PIL import Image, ImageTk

from widgets import ACCENT, ACCENT_TEXT, MUTED, PILL, RED, TEXT, font, rounded_rect, s

HERE = os.path.dirname(os.path.abspath(__file__))
ICON_PNG = os.path.join(HERE, "assets", "icon.png")
ICON_ICO = os.path.join(HERE, "assets", "icon.ico")

BAR_H = s(40)
BAR_BG = "#101014"
BORDER = "#2a2a32"

_user32 = getattr(ctypes, "windll", None) and ctypes.windll.user32
GWL_EXSTYLE = -20
WS_EX_APPWINDOW = 0x00040000
WS_EX_TOOLWINDOW = 0x00000080
SW_MINIMIZE, SW_RESTORE = 6, 9


def hwnd_of(win):
    """The real Windows handle of a Tk window (its outer frame)."""
    try:
        return int(win.frame(), 16)
    except (tk.TclError, ValueError):
        return 0


APP_ID = "DaysBygoneBot.App"


def set_app_id():
    """Call BEFORE creating the window: makes Windows treat the bot as its own
    app (own taskbar button + icon) instead of grouping it under Python."""
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except (AttributeError, OSError):
        pass


def send_icon(win):
    """Give Windows the icon for this window directly (taskbar + Alt+Tab).
    Needed for the main window, which has no normal title bar."""
    if not _user32:
        return
    try:
        LR_LOADFROMFILE, IMAGE_ICON, WM_SETICON = 0x10, 1, 0x0080
        _user32.LoadImageW.restype = ctypes.c_void_p
        _user32.SendMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p]
        h = hwnd_of(win)
        for which, size in ((1, 48), (0, 16)):          # ICON_BIG, ICON_SMALL
            icon = _user32.LoadImageW(None, ICON_ICO, IMAGE_ICON, size, size, LR_LOADFROMFILE)
            if icon:
                _user32.SendMessageW(h, WM_SETICON, which, icon)
    except (AttributeError, OSError):
        pass


def set_window_identity(win):
    """Give this window its own taskbar identity + icon. Needed because the
    Microsoft Store Python is a 'packaged' app: Windows would otherwise group
    the bot under Python and show Python's icon, ignoring the window icon."""
    try:
        import sys
        import pythoncom
        from win32com.propsys import propsys, pscon
        store = propsys.SHGetPropertyStoreForWindow(hwnd_of(win), propsys.IID_IPropertyStore)
        pythonw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        for key, value in ((pscon.PKEY_AppUserModel_ID, APP_ID),
                           (pscon.PKEY_AppUserModel_RelaunchIconResource, ICON_ICO + ",0"),
                           (pscon.PKEY_AppUserModel_RelaunchDisplayNameResource, "Days Bygone Bot"),
                           (pscon.PKEY_AppUserModel_RelaunchCommand,
                            f'"{pythonw}" "{os.path.join(HERE, "ui.py")}"')):
            store.SetValue(key, propsys.PROPVARIANTType(value, pythoncom.VT_LPWSTR))
        store.Commit()
    except Exception:  # noqa: BLE001 - cosmetic only, never block the window
        pass


def set_app_icon(root):
    """App icon (the purple dino) for every window (taskbar, Alt+Tab, pop-up windows)."""
    try:
        root.iconbitmap(default=ICON_ICO)
    except tk.TclError:
        pass


def dark_titlebar(win):
    """Use Windows' dark title bar for a normal window (Windows 10 2004+)."""
    try:
        value = ctypes.c_int(1)
        for attr in (20, 19):   # DWMWA_USE_IMMERSIVE_DARK_MODE (new / old build number)
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd_of(win), attr, ctypes.byref(value), 4) == 0:
                break
    except (AttributeError, OSError):
        pass


class TitleBar:
    """Replaces the Windows title bar on the main window: icon, name, version,
    an optional button (used for updates), minimise and close. Drag it to move
    the window. The window keeps its taskbar button."""

    def __init__(self, root, title, version, on_close):
        self.root = root
        self.on_close = on_close
        root.overrideredirect(True)
        self.c = tk.Canvas(root, height=BAR_H, bg=BAR_BG, highlightthickness=0, bd=0)
        self.c.pack(fill="x")
        mid = BAR_H / 2
        try:
            self._icon = ImageTk.PhotoImage(Image.open(ICON_PNG).resize((s(30), s(30)), Image.LANCZOS))
            self.c.create_image(s(14), mid, anchor="w", image=self._icon)
        except OSError:
            pass
        self.c.create_text(s(46), mid, anchor="w", text=title, fill=TEXT, font=font(12, True))
        tw = font(12, True)
        self._ver_x = s(46) + tk.font.Font(font=tw).measure(title) + s(10)
        rounded_rect(self.c, self._ver_x, mid - s(10), self._ver_x + s(44), mid + s(10), s(10), fill=PILL, outline="")
        self.c.create_text(self._ver_x + s(22), mid, text=f"v{version}", fill=MUTED, font=font(9, True))

        # drag to move
        for seq, fn in (("<ButtonPress-1>", self._press), ("<B1-Motion>", self._drag)):
            self.c.bind(seq, fn)
        root.after(250, self._show_in_taskbar)   # after the window has appeared
        root.bind("<Map>", self._on_map, add="+")

    def place_controls(self, width):
        """Draw the window buttons at the right edge (needs the final width)."""
        mid = BAR_H / 2
        bw = s(46)
        self._btn(width - bw, 0, width, BAR_H, "✕", self.on_close, hover="#c42b1c")
        self._btn(width - 2 * bw, 0, width - bw, BAR_H, "—", self.minimize, hover="#2a2a32")
        self.extra_right = width - 2 * bw - s(10)
        return mid

    def _btn(self, x0, y0, x1, y1, text, cmd, hover):
        tag = f"tb{id(cmd)}{x0}"
        bg = self.c.create_rectangle(x0, y0, x1, y1, fill=BAR_BG, outline="", tags=tag)
        self.c.create_text((x0 + x1) / 2, (y0 + y1) / 2, text=text, fill=TEXT, font=font(11), tags=tag)
        self.c.tag_bind(tag, "<Enter>", lambda e: self.c.itemconfigure(bg, fill=hover))
        self.c.tag_bind(tag, "<Leave>", lambda e: self.c.itemconfigure(bg, fill=BAR_BG))
        self.c.tag_bind(tag, "<ButtonRelease-1>", lambda e: cmd())

    def add_button(self, text, cmd, width_px):
        """A small pill button just left of the window buttons (returns a CanvasButton)."""
        from widgets import CanvasButton
        x1 = self.extra_right
        mid = BAR_H / 2
        return CanvasButton(self.c, (x1 - width_px, mid - s(12), x1, mid + s(12)), text, cmd, size=8)

    # -- moving / minimising -----------------------------------------------------
    def _press(self, e):
        if self.c.find_withtag("current") and any(t.startswith(("tb", "btn")) for t in
                                                   self.c.gettags("current")):
            self._drag_from = None
            return
        self._drag_from = (e.x_root - self.root.winfo_x(), e.y_root - self.root.winfo_y())

    def _drag(self, e):
        if getattr(self, "_drag_from", None):
            dx, dy = self._drag_from
            self.root.geometry(f"+{e.x_root - dx}+{e.y_root - dy}")

    def minimize(self):
        if _user32:
            _user32.ShowWindow(hwnd_of(self.root), SW_MINIMIZE)

    def restore(self):
        if _user32:
            _user32.ShowWindow(hwnd_of(self.root), SW_RESTORE)
        self.root.lift()

    def _show_in_taskbar(self):
        # A window without the normal title bar gets no taskbar button by
        # default; mark it as an app window so it does.
        if not _user32:
            return
        h = hwnd_of(self.root)
        style = _user32.GetWindowLongW(h, GWL_EXSTYLE)
        style = (style & ~WS_EX_TOOLWINDOW) | WS_EX_APPWINDOW
        _user32.SetWindowLongW(h, GWL_EXSTYLE, style)
        send_icon(self.root)
        set_window_identity(self.root)
        self.root.withdraw()
        self.root.after(30, self.root.deiconify)

    def _on_map(self, _e):
        # restored from the taskbar: make sure it's drawn at full size
        self.root.after(30, self.root.update_idletasks)


def style_window(win):
    """Dark title bar for a normal (non-main) window. Applied while the window
    is hidden, so Windows draws it dark from the start."""
    win.configure(bg="#18181d")
    win.withdraw()
    win.update_idletasks()
    dark_titlebar(win)
    win.after(0, win.deiconify)


__all__ = ["TitleBar", "BAR_H", "BORDER", "set_app_icon", "style_window", "ACCENT", "ACCENT_TEXT", "RED"]
