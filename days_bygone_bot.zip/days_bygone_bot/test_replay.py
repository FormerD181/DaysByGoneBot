"""Replay recorded ghost battles through the CURRENT bot code -- no game needed.

    python test_replay.py              # every recorded battle
    python test_replay.py 20261004_    # only battles whose folder starts with this

For each battle it shows what the bot would do now (casts, spells, timing) and
how good the aim is: where each spell would land vs. where that colour's ghost
really was when the spell landed (from the footage). Note: the footage doesn't
react to the new casts, so this tests seeing/choosing/aiming, not kills.
"""
import os
import sys
import types

import cv2
import numpy as np

import battle_recorder
import cast_log
import ghost
import humanize
from vision import Vision

HERE = os.path.dirname(os.path.abspath(__file__))
LAND_S = 0.35            # spell travel/landing time assumed when scoring aim


class Clock:
    t = 0.0

    def monotonic(self):
        return self.t


def load(folder):
    times = [float(x) for x in open(os.path.join(folder, "times.txt")).read().split()]
    x0, y0, x1, y1 = battle_recorder.BAR_BOX
    frames = []
    for i in range(len(times)):
        base = os.path.join(folder, f"{i:04d}")
        f = cv2.imread(base + "_f.jpg")
        b = cv2.imread(base + "_b.jpg")
        if b is None:
            b = cv2.imread(base + "_b.png")
        if f is None or b is None:
            break
        full = cv2.resize(f, (1920, 1080), interpolation=cv2.INTER_LINEAR)
        full[y0:y1, x0:x1] = b
        frames.append(full)
    return times[:len(frames)], frames


def replay(folder, vis):
    times, frames = load(folder)
    clock = Clock()
    ghost.time = types.SimpleNamespace(monotonic=clock.monotonic, sleep=lambda s: None,
                                       strftime=__import__("time").strftime, time=__import__("time").time)
    humanize.ghost_pause = lambda: 0
    casts = []

    class Dev:
        def swipe(self, sx, sy, dx, dy, ms):
            casts.append({"t": clock.t, "drop": (dx, dy)})

    f = ghost.GhostFighter(Dev(), vis, lambda m: None)
    f.rec = types.SimpleNamespace(recording=True, start=lambda: None, frame=lambda *a, **k: None,
                                  note_cast=lambda *a: None, finish=lambda r: None)
    f.casts = types.SimpleNamespace(reset=lambda: None, frame=lambda *a: None,
                                    cast=lambda *a, **k: None, finish=lambda r: None)
    f._save_shot = lambda *a: None
    f._save_bar = lambda *a: None
    names = []
    f.log = lambda m: names.append((clock.t, m))

    ghosts_per_frame = []
    for t, img in zip(times, frames):
        clock.t = t
        f.step(img, t)
        ghosts_per_frame.append(vis.find_ghosts(img))

    # aim: for each cast, the frame closest to t + LAND_S; nearest ghost to the drop
    errs = []
    for c, (t, msg) in zip(casts, [n for n in names if "->" in n[1]]):
        el = msg.split()[1]
        target_t = c["t"] + LAND_S
        k = min(range(len(times)), key=lambda i: abs(times[i] - target_t))
        if abs(times[k] - target_t) > 0.25:
            continue
        dx, dy = c["drop"]
        gs = [g for g in ghosts_per_frame[k] if g["element"] == el and abs(g["y"] - dy) < 120]
        if gs:
            g = min(gs, key=lambda g: abs(g["x"] - dx))
            errs.append(dx - g["x"])          # + = landed behind the ghost (it walks left)
    return times, casts, names, errs, ghosts_per_frame


def main():
    root = os.path.join(HERE, "debug", "replays")
    prefix = sys.argv[1] if len(sys.argv) > 1 else ""
    folders = sorted(d for d in os.listdir(root) if d.startswith(prefix) and not d.endswith("_recording")) \
        if os.path.isdir(root) else []
    if not folders:
        print("No recorded battles yet -- they're saved to debug/replays/ during ghost battles.")
        return
    vis = Vision()
    all_errs = []
    for d in folders:
        times, casts, names, errs, gpf = replay(os.path.join(root, d), vis)
        all_errs += errs
        first = next((t for t, m in names if "->" in m), None)
        print(f"\n{d}: {len(times)} frames over {times[-1]:.1f}s, most ghosts at once {max(map(len, gpf))}, "
              f"{len(casts)} casts, first cast at {first if first is None else round(first, 2)}s")
        for t, m in names:
            print(f"   {t:6.2f}s  {m}")
        if errs:
            print(f"   aim: median {np.median(errs):+.0f}px  (+ = behind the ghost), "
                  f"within 60px: {np.mean(np.abs(errs) <= 60):.0%}")
    if all_errs:
        e = np.array(all_errs)
        print(f"\nALL: {len(e)} scored casts, median {np.median(e):+.0f}px, "
              f"mean |error| {np.mean(np.abs(e)):.0f}px, within 60px {np.mean(np.abs(e) <= 60):.0%}")


if __name__ == "__main__":
    main()
