"""Daily summary: counts what the bot did each game day (Days Bygone resets at
8:00 AM) and builds the message sent to your phone at 8:00.

Counts live in settings["daily"], so they survive restarts.
"""
import datetime as dt
import threading

RESET_HOUR = 8          # the game's daily reset


def day_start(now=None):
    """Start of the current game day (the latest 8:00 AM)."""
    now = now or dt.datetime.now()
    start = now.replace(hour=RESET_HOUR, minute=0, second=0, microsecond=0)
    return start if now >= start else start - dt.timedelta(days=1)


def _fmt_time(sec):
    sec = int(sec)
    return f"{sec // 3600}h {sec // 60 % 60:02d}m"


class Daily:
    KEYS = ("rewinds", "ghost_wins", "ghost_losses", "human_checks", "revives", "rests", "run_seconds")

    def __init__(self, settings, save):
        self.settings = settings
        self.save = save
        self.lock = threading.Lock()
        d = settings.get("daily")
        if not isinstance(d, dict) or "since" not in d:
            settings["daily"] = self._fresh(day_start())

    def _fresh(self, since):
        d = {k: 0 for k in self.KEYS}
        d.update(since=since.isoformat(timespec="minutes"), first_day=None, last_day=None)
        return d

    @property
    def d(self):
        return self.settings["daily"]

    def add(self, key, n=1):
        with self.lock:
            self.d[key] = self.d.get(key, 0) + n

    def saw_day(self, day):
        """The campaign day read from the Battle menu."""
        if not day:
            return
        with self.lock:
            if self.d.get("first_day") is None:
                self.d["first_day"] = day
            self.d["last_day"] = max(day, self.d.get("last_day") or 0)

    def due(self, now=None):
        """True once a new game day has started since the counts began."""
        since = dt.datetime.fromisoformat(self.d["since"])
        return day_start(now) > since

    def message(self):
        d = self.d
        since = dt.datetime.fromisoformat(d["since"])
        wins, losses = d.get("ghost_wins", 0), d.get("ghost_losses", 0)
        fights = wins + losses
        lines = [f"Since {since:%a %b %d, %I:%M %p}".replace(" 0", " "),
                 f"Rewinds: {d.get('rewinds', 0)}",
                 f"Ghost fights: {wins} won, {losses} lost"
                 + (f" ({round(100 * wins / fights)}% wins)" if fights else ""),
                 f"Bot running: {_fmt_time(d.get('run_seconds', 0))}"]
        a, b = d.get("first_day"), d.get("last_day")
        if b:
            lines.append(f"Campaign: day {a:,} -> {b:,}" + (f" (+{b - a:,})" if b > a else ""))
        if d.get("rests"):
            lines.append(f"Rests: {d['rests']}")
        if d.get("revives"):
            lines.append(f"Revives: {d['revives']}")
        lines.append(f"Human checks: {d.get('human_checks', 0)}")
        return "\n".join(lines)

    def roll(self, now=None):
        """Start counting a new day (keeps the last campaign day as the new start)."""
        with self.lock:
            last = self.d.get("last_day")
            self.settings["daily"] = self._fresh(day_start(now))
            self.settings["daily"]["first_day"] = last
            self.settings["daily"]["last_day"] = last
        self.save(self.settings)
