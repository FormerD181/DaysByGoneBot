"""Screen recognition for Days Bygone at 1920x1080."""
import glob
import os

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(HERE, "templates")

# Screen templates: name -> (search box x0, y0, x1, y1). Box is a bit larger
# than the template so small shifts still match.
SCREEN_REGIONS = {
    "stats_title":    (0, 0, 330, 140),
    "skills_title":   (0, 0, 350, 140),
    "gamemode_title": (600, 60, 1060, 180),
    "campaign_title": (610, 270, 880, 380),
    "victory":        (690, 60, 1240, 420),   # popup height varies
    "pause":          (20, 10, 130, 120),
    "medallion":      (470, 340, 720, 470),
    "defeat":         (700, 150, 1220, 560),
    "victory_ghost":  (690, 60, 1240, 420),
    "battle_btn":     (1665, 0, 1920, 140),
    "worldtree_title": (370, 25, 690, 125),
    "settings_title":  (650, 35, 880, 130),
    "journal_title":   (1145, 108, 1415, 202),
    "elixir_title":    (925, 252, 1278, 340),
    "checkin_title":   (380, 50, 740, 195),    # daily reward (Check-In) popup
}
MATCH_THRESHOLD = 0.80

# name: (element, shape, mana cost). Shape decides where a spell hits:
#   field = whole battlefield, vline = a vertical line, ray = a beam fired
#   from the hero through the drop point,
#   area = around the drop point, cross = an X centred on the drop point.
SPELLS = {
    "gust":           ("wind", "vline", 32),   # measured: full-height column at the drop x
    "gale":           ("wind", "field", 50),   # three gusts at once = whole screen
    "tornado":        ("wind", "field", 74),
    "ice_shard":      ("ice", "vline", 34),    # measured: full-height column at the drop x
    "glacial_prison": ("ice", "vline", 50),
    "blizzard":       ("ice", "field", 74),
    "genesis":        ("light", "vline", 32),  # thin top-to-bottom beam
    "deuteronomy":    ("light", "cross", 50),  # X: two diagonal lines crossing at the drop
    "revelation":     ("light", "field", 74),
    "zap":            ("lightning", "area", 32),
    "thunderbolt":    ("lightning", "area", 64),
    "thunderstorm":   ("lightning", "field", 84),
    "fireball":       ("fire", "area", 42),
    "flamelance":     ("fire", "ray", 64),
    "armageddon":     ("fire", "field", 84),
}
SPELL_ELEMENT = {name: info[0] for name, info in SPELLS.items()}

# Playfield: right of the wall, below the HUD, above the spell bar.
FIELD = (380, 130, 1920, 925)
FACE_SCALE = 0.5         # face search runs at half resolution (faster, same result)
FACE_MATCH = 0.55        # ghost faces score 0.62-0.79, nothing else gets near 0.55


def _face_template():
    """Half-res ghost face as seen in brightness: bright body, dark face,
    two white square eyes."""
    t = np.full((44, 52), 190, np.uint8)
    cv2.rectangle(t, (7, 6), (44, 38), 55, -1)
    cv2.rectangle(t, (10, 15), (17, 22), 245, -1)
    cv2.rectangle(t, (28, 15), (35, 22), 245, -1)
    return t


FACE_TEMPLATE = _face_template()
ENTERING_X = 1820        # ghosts right of this are still walking on screen

# Exact hot-bar icon templates (templates/bar/<spell>__<ready|nomana>_N.png),
# cut from real ghost-battle screenshots.
BAR_ICON_SIZE = 100
BAR_ICON_TOP = 955
READY_MAX_DIST = 10   # ready icons match within ~8; no-mana/cooldown are 13-50+
NAME_MAX_DIST = 15

# Spell bar slots (frame boxes) measured from the campaign battle screen.
DEFAULT_SLOTS = [(540 + i * 143.7, 945, 660 + i * 143.7, 1065) for i in range(6)]


def _load(path):
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    return img


class Vision:
    def __init__(self):
        self.screens = {
            name: _load(os.path.join(TEMPLATE_DIR, "screens", name + ".png"))
            for name in SCREEN_REGIONS
        }
        self.bar_templates = []
        self.bar_icons = []          # full icons, for naming spells on cooldown
        for path in glob.glob(os.path.join(TEMPLATE_DIR, "bar", "*.png")):
            base = os.path.splitext(os.path.basename(path))[0]
            name, state = base.split("__")
            icon = _load(path)
            self.bar_templates.append((name, state.split("_")[0], self._bar_feat(icon)))
            self.bar_icons.append((name, self._cost_crop(icon), self._chroma(icon), icon.max(2) > 25))

    # -- screens ----------------------------------------------------------
    def match(self, img, name):
        x0, y0, x1, y1 = SCREEN_REGIONS[name]
        roi = img[y0:y1, x0:x1]
        tpl = self.screens[name]
        if roi.shape[0] < tpl.shape[0] or roi.shape[1] < tpl.shape[1]:
            return 0.0
        return float(cv2.matchTemplate(roi, tpl, cv2.TM_CCOEFF_NORMED).max())

    def has(self, img, name):
        return self.match(img, name) >= MATCH_THRESHOLD

    @staticmethod
    def _count_hsv(img, box, lo, hi):
        x0, y0, x1, y1 = box
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        return int(cv2.countNonZero(cv2.inRange(hsv, lo, hi)))

    def detect_state(self, img):
        """Return one of: stats, skills, gamemode, campaign_confirm, victory,
        campaign_battle, ghost_battle, popup_ok, checkin, unknown."""
        # Popups first (they sit on top of other screens).
        if self.has(img, "victory") or self.has(img, "victory_ghost"):
            return "victory"
        if self.has(img, "defeat"):
            return "defeat"
        if self.result_buttons(img):
            # A VICTORY/DEFEAT popup whose banner didn't match (popups grow
            # when they show stats). The bot decides what it is from context.
            return "result"
        if self.has(img, "campaign_title"):
            return "campaign_confirm"
        if self.has(img, "gamemode_title"):
            return "gamemode"
        if self.has(img, "pause"):
            # Campaign shows a gold coin next to the pause button, the ghost
            # battle shows a green gem.
            box = (140, 25, 200, 95)
            green = self._count_hsv(img, box, (45, 120, 120), (80, 255, 255))
            yellow = self._count_hsv(img, box, (18, 120, 150), (32, 255, 255))
            return "ghost_battle" if green > yellow else "campaign_battle"
        if self.has(img, "checkin_title"):
            return "checkin"
        # Game menus the player opened (not a human check)
        for menu in ("worldtree", "settings", "journal"):
            if self.has(img, menu + "_title"):
                return menu
        if self.menu_dimmed(img):
            # Something sits on top of the menu. Known popups have a green
            # OK/Rewind button; anything else is most likely a human check.
            return "popup_ok" if self.find_green_button(img) else "human_check"
        if self.has(img, "stats_title"):
            return "stats"
        if self.has(img, "skills_title"):
            return "skills"
        if self.find_green_button(img):
            return "popup_ok"
        return "unknown"

    # Result-popup buttons have exact colours on every screen.
    RED_BTN = [((0, 190, 150), (4, 255, 230)), ((176, 190, 150), (180, 255, 230))]
    GREEN_BTN = [((50, 190, 120), (60, 255, 190))]

    @staticmethod
    def _find_rects(img, ranges, box=(300, 150, 1620, 1050)):
        """Wide solid buttons of the given colour: list of (cx, cy, w, h)."""
        x0, y0, x1, y1 = box
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        mask = np.zeros(hsv.shape[:2], np.uint8)
        for lo, hi in ranges:
            mask |= cv2.inRange(hsv, lo, hi)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        # Bridge the white icon in the middle of the button.
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((15, 61), np.uint8))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        out = []
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            hull = cv2.contourArea(cv2.convexHull(cnt))
            if w > 100 and 30 < h < 120 and w > 2.5 * h and hull > 0.85 * w * h:
                out.append((x + x0 + w // 2, y + y0 + h // 2, w, h))
        return out

    def result_buttons(self, img):
        """Look for the buttons of a VICTORY / DEFEAT popup.
        Returns ("pair", red_xy, green_xy), ("single", red_xy, None) or None.
        pair   = red + green side by side (campaign VICTORY or ghost DEFEAT)
        single = one wide red button (ghost VICTORY)"""
        reds = self._find_rects(img, self.RED_BTN)
        greens = self._find_rects(img, self.GREEN_BTN)
        for r in reds:
            for g in greens:
                if abs(r[1] - g[1]) < 20 and abs(r[2] - g[2]) < 50 and g[0] > r[0]:
                    return ("pair", r[:2], g[:2])
        for r in reds:
            if r[2] > 400:
                return ("single", r[:2], None)
        return None

    def menu_dimmed(self, img):
        """True when the Stats/Skills menu is visible but darkened by an overlay."""
        x0, y0, x1, y1 = SCREEN_REGIONS["battle_btn"]
        roi = img[y0:y1, x0:x1]
        tpl = self.screens["battle_btn"]
        res = cv2.matchTemplate(roi, tpl, cv2.TM_CCOEFF_NORMED)
        _, score, _, (lx, ly) = cv2.minMaxLoc(res)
        if score < 0.75:
            return False
        patch = roi[ly:ly + tpl.shape[0], lx:lx + tpl.shape[1]]
        ratio = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY).mean() / cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY).mean()
        return ratio < 0.7

    @staticmethod
    def find_green_button(img):
        """Find a large bright-green button (OK / Rewind / confirm) in the centre
        area. Returns (x, y) or None."""
        x0, y0, x1, y1 = 450, 250, 1470, 1000
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (45, 150, 140), (75, 255, 255))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        best = None
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            if not (w > 120 and 40 < h < 200 and w > h):
                continue
            # Judge the shape, not the pixels: button text punches holes and
            # notches in the green, but a rubber band around it (convex hull)
            # is still the button's rectangle. Green gems/crates are diamonds
            # and fill only about half of their box.
            outline = cv2.contourArea(cv2.convexHull(cnt))
            if outline < 6000 or outline < 0.85 * w * h:
                continue
            if best is None or outline > best[2]:
                best = (x + w // 2 + x0, y + h // 2 + y0, outline)
        return best[:2] if best else None

    # -- campaign day ----------------------------------------------------
    def campaign_at_max(self, img):
        """Check the Campaign tile on the Select Gamemode popup.
        Not at max it reads 'DAY 17100 of 18482' (4 words); at max it's just
        'DAY 18482' (2 words). Returns True/False, or None if unsure."""
        x0, y0, x1, y1 = 975, 310, 1300, 360
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        # White/grey text only (skips the green CAMPAIGN title).
        mask = cv2.inRange(hsv, (0, 0, 150), (180, 80, 255))
        cols = np.where(mask.sum(0) > 0)[0]
        words = []
        for x in cols:
            if words and x - words[-1][1] <= 8:
                words[-1][1] = x
            else:
                words.append([x, x])
        if len(words) == 2:
            return True
        if len(words) == 4:
            return False
        return None

    # -- spell bar -------------------------------------------------------
    @staticmethod
    def _bar_feat(icon):
        return cv2.resize(icon, (20, 20), interpolation=cv2.INTER_AREA).astype(np.float32)

    def bar_slots(self):
        """Fixed slot boxes (x0, y0, x1, y1) of the 6 hot-bar spells."""
        return [tuple(int(v) for v in s) for s in DEFAULT_SLOTS]

    def read_bar(self, img):
        """Identify each hot-bar slot with the exact templates.
        Returns per slot: name (or None if unsure), state ("ready", "nomana" or
        "busy" for cooldown/unclear), dist, center."""
        out = []
        for (x0, y0, x1, y1) in self.bar_slots():
            ix = x0 + 10
            icon = img[BAR_ICON_TOP:BAR_ICON_TOP + BAR_ICON_SIZE, ix:ix + BAR_ICON_SIZE]
            f = self._bar_feat(icon)
            scored = sorted((float(np.abs(f - t).mean()), n, s) for n, s, t in self.bar_templates)
            dist, name, state = scored[0]
            ready = [d for d, n, s in scored if s == "ready"]
            if ready and ready[0] <= READY_MAX_DIST:
                dist, name, state = next((d, n, s) for d, n, s in scored if s == "ready")
            elif dist <= NAME_MAX_DIST:
                state = "nomana" if state == "nomana" else "busy"
            else:
                name, state = self._name_on_cooldown(icon), "busy"
            out.append({"name": name, "state": state, "dist": round(dist, 1),
                        "center": ((x0 + x1) // 2, (y0 + y1) // 2)})
        return out

    # Spells on cooldown are hidden under a dark sweep and a countdown number.
    # The mana cost (top-right) stays readable and narrows it to 1-3 spells;
    # those always differ in colour, and darkening doesn't change colour
    # proportions, so comparing them picks the right one (468/468 in testing).
    COST_BOX = (52, 0, 100, 26)          # inside the 100x100 icon
    COOLDOWN_MASK = np.ones((100, 100), bool)
    COOLDOWN_MASK[28:72, 12:88] = False  # countdown number
    COOLDOWN_MASK[:26, 52:] = False      # cost digits

    @classmethod
    def _cost_crop(cls, icon):
        x0, y0, x1, y1 = cls.COST_BOX
        return cv2.cvtColor(icon[y0:y1, x0:x1], cv2.COLOR_BGR2GRAY)

    @staticmethod
    def _chroma(icon):
        f = icon.astype(np.float32) + 1
        return f / f.sum(2, keepdims=True)

    def _name_on_cooldown(self, icon):
        if icon.shape[:2] != (100, 100):
            return None
        pad = cv2.copyMakeBorder(self._cost_crop(icon), 3, 3, 3, 3, cv2.BORDER_REPLICATE)
        cost_score = {}
        for name, cost_img, _, _ in self.bar_icons:
            s = float(cv2.matchTemplate(pad, cost_img, cv2.TM_CCOEFF_NORMED).max())
            cost = SPELLS[name][2]
            cost_score[cost] = max(cost_score.get(cost, -1), s)
        cost, score = max(cost_score.items(), key=lambda kv: kv[1])
        if score < 0.6:
            return None
        chroma = self._chroma(icon)
        lit = icon.max(2) > 25
        best = None
        for name, _, t_chroma, t_lit in self.bar_icons:
            if SPELLS[name][2] != cost:
                continue
            m = self.COOLDOWN_MASK & lit & t_lit
            if m.sum() < 300:
                continue
            d = float(np.abs(chroma - t_chroma)[m].mean())
            if best is None or d < best[0]:
                best = (d, name)
        return best[1] if best else None

    # -- ghosts -----------------------------------------------------------
    def find_ghosts(self, img):
        """Return a list of ghosts: dicts with element, x, y (centre), x0..y1 box.
        Ghosts are found by their dark face (survives glows/tints, counts each
        ghost separately, ignores spell effects)."""
        # Only faces count. The old colour-blob backup mistook spell explosions,
        # hit flashes and "+2" pickup popups for ghosts, so it is no longer used.
        # Ghosts still entering at the right edge are skipped: the red screen-edge
        # vignette tints them, so their colour isn't reliable yet.
        return [f for f in self._find_faces(img) if f["x"] < ENTERING_X]

    def _find_faces(self, img):
        """Find ghost faces by their pattern: a dark patch with two white square
        eyes, the same on every ghost. Works through glows, tints and pickups
        lying on top of a ghost, and ignores tickets, gems, rocks and spells."""
        x0, y0, x1, y1 = FIELD
        k = FACE_SCALE
        roi = cv2.resize(img[y0:y1, x0:x1], None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        res = cv2.matchTemplate(hsv[:, :, 2], FACE_TEMPLATE, cv2.TM_CCOEFF_NORMED)
        th, tw = FACE_TEMPLATE.shape
        found = []
        while True:
            _, score, _, (x, y) = cv2.minMaxLoc(res)
            if score < FACE_MATCH:
                break
            # blank this spot so the next-best match is a different ghost
            cv2.rectangle(res, (x - tw // 2, y - th // 2), (x + tw // 2, y + th // 2), -1, -1)
            # body = bright pixels around the face (inside a ring around it)
            pad = int(14 * k * 2)
            bx0, by0 = max(0, x - pad), max(0, y - pad)
            bx1, by1 = min(hsv.shape[1], x + tw + pad), min(hsv.shape[0], y + th + pad)
            ring = np.ones((by1 - by0, bx1 - bx0), bool)
            ring[(y + 6 - by0):(y + 38 - by0), (x + 7 - bx0):(x + 44 - bx0)] = False
            body = hsv[by0:by1, bx0:bx1][ring]
            element = self._body_element(body[body[:, 2] > 170])
            if not element:
                continue
            cx, cy = (x + tw / 2) / k + x0, (y + th / 2) / k + y0
            found.append({"element": element, "x": int(cx), "y": int(cy),
                          "x0": int(x / k + x0), "y0": int(y / k + y0),
                          "x1": int((x + tw) / k + x0), "y1": int((y + th) / k + y0),
                          "pixels": int(tw * th / k / k), "score": round(float(score), 2)})
        return found

    @staticmethod
    def _body_element(bright):
        """Ghost colour from the bright body pixels around its face."""
        S = bright[:, 1]
        if np.median(S) < 75:
            return "wind"          # white ghosts (also white ghosts tinted by a glow)
        hue = bright[S >= 75][:, 0]
        votes = {
            "fire": int(((hue >= 4) & (hue <= 19)).sum()),
            "light": int(((hue >= 20) & (hue <= 35)).sum()),
            "ice": int(((hue >= 80) & (hue <= 112)).sum()),
            "lightning": int(((hue >= 125) & (hue <= 170)).sum()),
        }
        best = max(votes, key=votes.get)
        return best if votes[best] > 0 else None
