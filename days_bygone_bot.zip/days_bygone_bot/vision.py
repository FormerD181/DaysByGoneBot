"""Screen recognition for Days Bygone at 1920x1080."""
import glob
import os

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(HERE, "templates")

# Screen templates: name -> (search box x0, y0, x1, y1). Box is a bit larger
# than the template so small shifts still match.
SCREEN_REGIONS = {
    "stats_title":    (0, 0, 330, 140),
    "skills_title":   (0, 0, 350, 140),
    "gamemode_title": (600, 60, 1060, 180),
    "campaign_title": (610, 270, 880, 380),
    "victory":        (690, 60, 1240, 420),   # popup height varies
    "pause":          (20, 10, 130, 120),
    "medallion":      (470, 340, 720, 470),
    "defeat":         (700, 150, 1220, 560),
    "victory_ghost":  (690, 60, 1240, 420),
    "battle_btn":     (1665, 0, 1920, 140),
    "worldtree_title": (370, 25, 690, 125),
    "settings_title":  (650, 35, 880, 130),
    "journal_title":   (1145, 108, 1415, 202),
    "elixir_title":    (925, 252, 1278, 340),
    "checkin_title":   (380, 50, 740, 195),    # daily reward (Check-In) popup
    "rewind_keep":     (470, 480, 820, 700),   # "You Keep:" on the rewind popup
    "heroes_title":    (0, 0, 350, 140),
}
# Rewind popup: where the green REWIND button is -- or, when rewinds have run
# out, a dark red box with a countdown ("8h", "44min").
REWIND_BTN_BOX = (1115, 872, 1360, 945)
# Expedition difficulty list (shown after picking Expedition): the red "Hell" row.
HELL_ROW_BOX = (1335, 655, 1690, 705)
MATCH_THRESHOLD = 0.80
# Only these menu titles may be matched in parts (the Flashback pill can sit on them).
# Popups/banners must match in full, or one popup gets mistaken for another.
PARTIAL_OK = {"stats_title", "skills_title", "heroes_title"}

# name: (element, shape, mana cost). Shape decides where a spell hits:
#   field = whole battlefield, vline = a vertical line, hline = a horizontal
#   band, ray = a beam fired
#   from the hero through the drop point,
#   area = around the drop point, cross = an X centred on the drop point.
SPELLS = {
    "gust":           ("wind", "hline", 32),   # wide horizontal band across the screen at the drop y
    "gale":           ("wind", "field", 50),   # three gusts at once = whole screen
    "tornado":        ("wind", "field", 74),
    "ice_shard":      ("ice", "area", 34),     # measured: a patch ~300 px across (not full height)
    "glacial_prison": ("ice", "vline", 50),
    "blizzard":       ("ice", "field", 74),
    "genesis":        ("light", "vline", 32),  # thin top-to-bottom beam
    "deuteronomy":    ("light", "cross", 50),  # X: two diagonal lines crossing at the drop
    "revelation":     ("light", "field", 74),
    "zap":            ("lightning", "area", 32),
    "thunderbolt":    ("lightning", "area", 64),
    "thunderstorm":   ("lightning", "field", 84),
    "fireball":       ("fire", "area", 42),
    "flamelance":     ("fire", "ray", 64),
    "armageddon":     ("fire", "field", 84),
}
SPELL_ELEMENT = {name: info[0] for name, info in SPELLS.items()}

# Playfield: right of the wall, below the HUD, above the spell bar.
FIELD = (380, 130, 1920, 925)
FACE_SCALE = 0.5         # face search runs at half resolution (faster, same result)
FACE_MATCH = 0.55        # ghost faces score 0.62-0.79, nothing else gets near 0.55


def _face_template():
    """Half-res ghost face as seen in brightness: bright body, dark face,
    two white square eyes."""
    t = np.full((44, 52), 190, np.uint8)
    cv2.rectangle(t, (7, 6), (44, 38), 55, -1)
    cv2.rectangle(t, (10, 15), (17, 22), 245, -1)
    cv2.rectangle(t, (28, 15), (35, 22), 245, -1)
    return t


FACE_TEMPLATE = _face_template()
ENTERING_X = 1820        # ghosts right of this are still walking on screen

# Exact hot-bar icon templates (templates/bar/<spell>__<ready|nomana>_N.png),
# cut from real ghost-battle screenshots.
BAR_ICON_SIZE = 100
BAR_ICON_TOP = 955
READY_MAX_DIST = 10   # ready icons match within ~8; no-mana/cooldown are 13-50+
NAME_MAX_DIST = 15

# Spell bar slots (frame boxes) measured from the campaign battle screen.
DEFAULT_SLOTS = [(540 + i * 143.7, 945, 660 + i * 143.7, 1065) for i in range(6)]


def _load(path):
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    return img


# Mana bar (bottom-left): light-blue fill, ~197 px long when full (100 mana).
MANA_ROWS = (1012, 1032)
MANA_FULL_PX = 197


class Vision:
    def __init__(self):
        self.screens = {
            name: _load(os.path.join(TEMPLATE_DIR, "screens", name + ".png"))
            for name in SCREEN_REGIONS
        }
        self.bar_templates = []
        self.bar_icons = []          # full icons, for naming spells on cooldown
        for path in glob.glob(os.path.join(TEMPLATE_DIR, "bar", "*.png")):
            base = os.path.splitext(os.path.basename(path))[0]
            name, state = base.split("__")
            icon = _load(path)
            self.bar_templates.append((name, state.split("_")[0], self._bar_feat(icon)))
            self.bar_icons.append((name, self._cost_crop(icon), self._chroma(icon), icon.max(2) > 25))

    @staticmethod
    def _frac(img, box, ranges):
        x0, y0, x1, y1 = box
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        m = None
        for lo, hi in ranges:
            r = cv2.inRange(hsv, lo, hi)
            m = r if m is None else m | r
        return float(m.mean()) / 255

    RED = [((0, 140, 70), (8, 255, 255)), ((172, 140, 70), (180, 255, 255))]
    GREEN = [((45, 120, 100), (75, 255, 255))]

    def rewind_locked(self, img):
        """Rewind popup with the red countdown instead of the green button
        (the daily rewinds are used up)."""
        return self._frac(img, REWIND_BTN_BOX, self.RED) > 0.5 and self._frac(img, REWIND_BTN_BOX, self.GREEN) < 0.05

    def hell_row(self, img):
        """The Expedition difficulty list is showing (red Hell row)."""
        return self._frac(img, HELL_ROW_BOX, self.RED) > 0.35

    def title_screen(self, img):
        """The game's title screen (after saving to the menu): bright sky on top."""
        return self._frac(img, (0, 0, 1920, 260), [((95, 60, 190), (112, 200, 255))]) > 0.45

    def menu_tab(self, img):
        """Backup for a hidden title: the highlighted (orange) tab on the left side --
        top tab = Stats, bottom tree tab = Skills. Only when the Battle button is visible."""
        if not self.has(img, "battle_btn"):
            return None
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        lit = {name: float(cv2.inRange(hsv[y - 60:y + 60, 10:150], (10, 120, 170), (25, 255, 255)).mean()) / 255
               for name, y in (("stats", 225), ("skills", 980))}
        best = max(lit, key=lit.get)
        return best if lit[best] > 0.5 else None

    def flashback(self, img):
        """The Flashback popup ("Visit 291 B.C.?") opened by tapping the floating pill."""
        if not hasattr(self, "_fb_tpl"):
            self._fb_tpl = _load(os.path.join(TEMPLATE_DIR, "screens", "flashback_small.png"))
        small = cv2.resize(img, (1013, 570), interpolation=cv2.INTER_AREA)
        roi = small[120:230, 280:520]
        return float(cv2.matchTemplate(roi, self._fb_tpl, cv2.TM_CCOEFF_NORMED).max()) > 0.75

    @staticmethod
    def read_mana(img):
        """Current mana (0-100) from the length of the blue mana bar."""
        hsv = cv2.cvtColor(img[MANA_ROWS[0]:MANA_ROWS[1], 0:260], cv2.COLOR_BGR2HSV)
        m = cv2.inRange(hsv, (85, 120, 150), (105, 255, 255))
        cols = np.where(m.sum(0) > 255 * 8)[0]
        return 0 if not len(cols) else min(100, int(round((cols.max() + 1) * 100 / MANA_FULL_PX)))

    # -- screens ----------------------------------------------------------
    def match(self, img, name):
        x0, y0, x1, y1 = SCREEN_REGIONS[name]
        roi = img[y0:y1, x0:x1]
        tpl = self.screens[name]
        if roi.shape[0] < tpl.shape[0] or roi.shape[1] < tpl.shape[1]:
            return 0.0
        score = float(cv2.matchTemplate(roi, tpl, cv2.TM_CCOEFF_NORMED).max())
        if score >= MATCH_THRESHOLD or name not in PARTIAL_OK:
            return score
        # Something floating over part of the title (the Flashback pill wanders around
        # the screen): accept a clear match of the left or the right half instead.
        w = tpl.shape[1]
        h, t = w // 2, w // 3
        for part in (tpl[:, :h], tpl[:, h:], tpl[:, :t], tpl[:, t:2 * t], tpl[:, 2 * t:]):
            score = max(score, float(cv2.matchTemplate(roi, part, cv2.TM_CCOEFF_NORMED).max()) - 0.03)
        return score

    def has(self, img, name):
        return self.match(img, name) >= MATCH_THRESHOLD

    @staticmethod
    def _count_hsv(img, box, lo, hi):
        x0, y0, x1, y1 = box
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        return int(cv2.countNonZero(cv2.inRange(hsv, lo, hi)))

    def detect_state(self, img):
        """Return one of: stats, skills, gamemode, campaign_confirm, victory,
        campaign_battle, ghost_battle, popup_ok, checkin, rewind_locked, heroes,
        title_screen, unknown."""
        # Popups first (they sit on top of other screens).
        if self.has(img, "victory") or self.has(img, "victory_ghost"):
            return "victory"
        if self.has(img, "defeat"):
            return "defeat"
        if self.result_buttons(img):
            # A VICTORY/DEFEAT popup whose banner didn't match (popups grow
            # when they show stats). The bot decides what it is from context.
            return "result"
        if self.has(img, "campaign_title"):
            return "campaign_confirm"
        if self.gamemode_dx(img) is not None:
            return "gamemode"
        if self.has(img, "pause"):
            # Campaign shows a gold coin next to the pause button, the ghost
            # battle shows a green gem.
            box = (140, 25, 200, 95)
            green = self._count_hsv(img, box, (45, 120, 120), (80, 255, 255))
            yellow = self._count_hsv(img, box, (18, 120, 150), (32, 255, 255))
            return "ghost_battle" if green > yellow else "campaign_battle"
        if self.has(img, "checkin_title"):
            return "checkin"
        if self.flashback(img):
            return "flashback"
        if self.has(img, "rewind_keep") and self.rewind_locked(img):
            return "rewind_locked"
        # Game menus the player opened (not a human check)
        for menu in ("worldtree", "settings", "journal"):
            if self.has(img, menu + "_title"):
                return menu
        if self.menu_dimmed(img):
            # Something sits on top of the menu. Known popups have a green
            # OK/Rewind button; anything else is most likely a human check.
            return "popup_ok" if self.find_green_button(img) else "human_check"
        # STATS / HEROES / SKILLS share letters, and the title can be half hidden
        # by the Flashback pill: take the best of the three, not the first.
        scores = {k: self.match(img, k + "_title") for k in ("stats", "heroes", "skills")}
        best = max(scores, key=scores.get)
        if scores[best] >= MATCH_THRESHOLD:
            return best
        tab = self.menu_tab(img)
        if tab:
            return tab
        if self.find_green_button(img):
            return "popup_ok"
        if self.title_screen(img):
            return "title_screen"
        return "unknown"

    # Result-popup buttons have exact colours on every screen.
    RED_BTN = [((0, 190, 150), (4, 255, 230)), ((176, 190, 150), (180, 255, 230))]
    GREEN_BTN = [((50, 190, 120), (60, 255, 190))]

    @staticmethod
    def _find_rects(img, ranges, box=(300, 150, 1620, 1050)):
        """Wide solid buttons of the given colour: list of (cx, cy, w, h)."""
        x0, y0, x1, y1 = box
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        mask = np.zeros(hsv.shape[:2], np.uint8)
        for lo, hi in ranges:
            mask |= cv2.inRange(hsv, lo, hi)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        # Bridge the white icon in the middle of the button.
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((15, 61), np.uint8))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        out = []
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            hull = cv2.contourArea(cv2.convexHull(cnt))
            if w > 100 and 30 < h < 120 and w > 2.5 * h and hull > 0.85 * w * h:
                out.append((x + x0 + w // 2, y + y0 + h // 2, w, h))
        return out

    def result_buttons(self, img):
        """Look for the buttons of a VICTORY / DEFEAT popup.
        Returns ("pair", red_xy, green_xy), ("single", red_xy, None) or None.
        pair   = red + green side by side (campaign VICTORY or ghost DEFEAT)
        single = one wide red button (ghost VICTORY)"""
        reds = self._find_rects(img, self.RED_BTN)
        greens = self._find_rects(img, self.GREEN_BTN)
        for r in reds:
            for g in greens:
                if abs(r[1] - g[1]) < 20 and abs(r[2] - g[2]) < 50 and g[0] > r[0]:
                    return ("pair", r[:2], g[:2])
        for r in reds:
            if r[2] > 400:
                return ("single", r[:2], None)
        return None

    def menu_dimmed(self, img):
        """True when the Stats/Skills menu is visible but darkened by an overlay."""
        x0, y0, x1, y1 = SCREEN_REGIONS["battle_btn"]
        roi = img[y0:y1, x0:x1]
        tpl = self.screens["battle_btn"]
        res = cv2.matchTemplate(roi, tpl, cv2.TM_CCOEFF_NORMED)
        _, score, _, (lx, ly) = cv2.minMaxLoc(res)
        if score < 0.75:
            return False
        patch = roi[ly:ly + tpl.shape[0], lx:lx + tpl.shape[1]]
        ratio = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY).mean() / cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY).mean()
        return ratio < 0.7

    @staticmethod
    def find_green_button(img):
        """Find a large bright-green button (OK / Rewind / confirm) in the centre
        area. Returns (x, y) or None."""
        x0, y0, x1, y1 = 450, 250, 1470, 1000
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (45, 150, 140), (75, 255, 255))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        best = None
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            if not (w > 120 and 40 < h < 200 and w > h):
                continue
            # Judge the shape, not the pixels: button text punches holes and
            # notches in the green, but a rubber band around it (convex hull)
            # is still the button's rectangle. Green gems/crates are diamonds
            # and fill only about half of their box.
            outline = cv2.contourArea(cv2.convexHull(cnt))
            if outline < 6000 or outline < 0.85 * w * h:
                continue
            if best is None or outline > best[2]:
                best = (x + w // 2 + x0, y + h // 2 + y0, outline)
        return best[:2] if best else None

    # -- wasteland (ticket usher + elixir generator) ---------------------
    WL_REGIONS = {                       # where each template is looked for
        "map_logo": (0, 0, 450, 260),
        "map_ticket": (600, 700, 1050, 950),
        "map_elixir": (600, 700, 1050, 950),
        "visit_word": (600, 440, 1320, 600),
        "leave_word": (600, 440, 1320, 600),
        "back_arrow": (0, 0, 200, 120),
        "robot_bubble": (0, 120, 1920, 1080),
        "scientist": (0, 60, 1920, 1080),
        "ticket_title": (420, 230, 900, 340),
        "elixir_title": (420, 230, 900, 340),
    }

    def wl_find(self, img, name, threshold=0.8):
        """Centre (x, y) of a Wasteland template on screen, or None."""
        if not hasattr(self, "_wl"):
            self._wl = {n: _load(os.path.join(TEMPLATE_DIR, "wasteland", n + ".png")) for n in self.WL_REGIONS}
        x0, y0, x1, y1 = self.WL_REGIONS[name]
        tpl = self._wl[name]
        res = cv2.matchTemplate(img[y0:y1, x0:x1], tpl, cv2.TM_CCOEFF_NORMED)
        _, score, _, (lx, ly) = cv2.minMaxLoc(res)
        if score < threshold:
            return None
        return x0 + lx + tpl.shape[1] // 2, y0 + ly + tpl.shape[0] // 2

    def wl_screen(self, img):
        """Which Wasteland-trip screen is showing: map, visit, leave, ticket_menu,
        elixir_menu, area -- or None (something else)."""
        if self.wl_find(img, "visit_word"):
            return "visit"
        if self.wl_find(img, "leave_word"):
            return "leave"
        if self.wl_find(img, "map_logo"):
            return "map"
        if self.wl_find(img, "ticket_title"):
            return "ticket_menu"
        if self.wl_find(img, "elixir_title"):
            return "elixir_menu"
        if self.wl_find(img, "back_arrow"):
            return "area"
        return None

    def map_dot(self, img):
        """Red dot on the World Map arrow under the Select Gamemode popup
        (something on the map is ready to collect)."""
        return self._frac(img, (990, 1020, 1045, 1065), [((0, 180, 180), (8, 255, 255)),
                                                         ((172, 180, 180), (180, 255, 255))]) > 0.04

    def wl_claim_ready(self, img):
        """The CLAIM button in a Ticket Usher / Elixir Generator menu is green
        (red with a timer = nothing to claim yet)."""
        return self._frac(img, (1265, 500, 1455, 555), self.GREEN) > 0.3

    # -- campaign day ----------------------------------------------------
    GM_TITLE_X = 640          # where the Select Gamemode title normally is

    def gamemode_dx(self, img):
        """Select Gamemode popup: how far it is shifted left/right from normal
        (it moves left when the Hunt boss list is open next to it). None if not shown."""
        t = self.screens["gamemode_title"]
        res = cv2.matchTemplate(img[40:220, 0:1300], t, cv2.TM_CCOEFF_NORMED)
        _, score, _, (lx, _) = cv2.minMaxLoc(res)
        if score < MATCH_THRESHOLD:
            return None
        self.last_gm_dx = lx - self.GM_TITLE_X
        return self.last_gm_dx

    def campaign_day(self, img):
        """The current campaign day from the Campaign tile ('DAY 18215 of 19223'
        or just 'DAY 19223' at max). Returns int or None."""
        dx = self.gamemode_dx(img)
        if dx is None:
            return None
        if not hasattr(self, "_digits"):
            from hunt import HuntReader
            self._digits = HuntReader()
        x0, y0, x1, y1 = 975 + dx, 315, 1300 + dx, 360
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        m = cv2.inRange(hsv, (0, 0, 200), (180, 30, 255))
        cols = (m > 0).sum(0) > 0
        runs, st = [], None
        for x, v in enumerate(list(cols) + [False]):
            if v and st is None:
                st = x
            elif not v and st is not None:
                runs.append((st, x))
                st = None
        words = []
        for a, b in runs:
            if words and a - words[-1][-1][1] <= 8:
                words[-1].append((a, b))
            else:
                words.append([(a, b)])
        if len(words) < 2:
            return None
        num = ""
        for a, b in words[1]:                  # word 0 is "DAY"
            col = m[:, a:b] > 0
            ys = np.where(col.sum(1) > 0)[0]
            d = self._digits._digit(col[ys.min():ys.max() + 1], limit=0.3)
            if d is None:
                return None
            num += d
        return int(num) if num else None

    def campaign_at_max(self, img):
        """Check the Campaign tile on the Select Gamemode popup.
        Not at max it reads 'DAY 17100 of 18482' (4 words); at max it's just
        'DAY 18482' (2 words). Returns True/False, or None if unsure."""
        dx = self.gamemode_dx(img) or 0
        x0, y0, x1, y1 = 975 + dx, 310, 1300 + dx, 360
        hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        # White/grey text only (skips the green CAMPAIGN title).
        mask = cv2.inRange(hsv, (0, 0, 150), (180, 80, 255))
        cols = np.where(mask.sum(0) > 0)[0]
        words = []
        for x in cols:
            if words and x - words[-1][1] <= 8:
                words[-1][1] = x
            else:
                words.append([x, x])
        if len(words) == 2:
            return True
        if len(words) == 4:
            return False
        return None

    # -- spell bar -------------------------------------------------------
    @staticmethod
    def _bar_feat(icon):
        return cv2.resize(icon, (20, 20), interpolation=cv2.INTER_AREA).astype(np.float32)

    def bar_slots(self):
        """Fixed slot boxes (x0, y0, x1, y1) of the 6 hot-bar spells."""
        return [tuple(int(v) for v in s) for s in DEFAULT_SLOTS]

    def read_bar(self, img):
        """Identify each hot-bar slot with the exact templates.
        Returns per slot: name (or None if unsure), state ("ready", "nomana" or
        "busy" for cooldown/unclear), dist, center."""
        out = []
        for (x0, y0, x1, y1) in self.bar_slots():
            ix = x0 + 10
            icon = img[BAR_ICON_TOP:BAR_ICON_TOP + BAR_ICON_SIZE, ix:ix + BAR_ICON_SIZE]
            f = self._bar_feat(icon)
            scored = sorted((float(np.abs(f - t).mean()), n, s) for n, s, t in self.bar_templates)
            dist, name, state = scored[0]
            ready = [d for d, n, s in scored if s == "ready"]
            if ready and ready[0] <= READY_MAX_DIST:
                dist, name, state = next((d, n, s) for d, n, s in scored if s == "ready")
            elif dist <= NAME_MAX_DIST:
                state = "nomana" if state == "nomana" else "busy"
            else:
                name, state = self._name_on_cooldown(icon), "busy"
            out.append({"name": name, "state": state, "dist": round(dist, 1),
                        "center": ((x0 + x1) // 2, (y0 + y1) // 2)})
        return out

    # Spells on cooldown are hidden under a dark sweep and a countdown number.
    # The mana cost (top-right) stays readable and narrows it to 1-3 spells;
    # those always differ in colour, and darkening doesn't change colour
    # proportions, so comparing them picks the right one (468/468 in testing).
    COST_BOX = (52, 0, 100, 26)          # inside the 100x100 icon
    COOLDOWN_MASK = np.ones((100, 100), bool)
    COOLDOWN_MASK[28:72, 12:88] = False  # countdown number
    COOLDOWN_MASK[:26, 52:] = False      # cost digits

    @classmethod
    def _cost_crop(cls, icon):
        x0, y0, x1, y1 = cls.COST_BOX
        return cv2.cvtColor(icon[y0:y1, x0:x1], cv2.COLOR_BGR2GRAY)

    @staticmethod
    def _chroma(icon):
        f = icon.astype(np.float32) + 1
        return f / f.sum(2, keepdims=True)

    def _name_on_cooldown(self, icon):
        if icon.shape[:2] != (100, 100):
            return None
        pad = cv2.copyMakeBorder(self._cost_crop(icon), 3, 3, 3, 3, cv2.BORDER_REPLICATE)
        cost_score = {}
        for name, cost_img, _, _ in self.bar_icons:
            s = float(cv2.matchTemplate(pad, cost_img, cv2.TM_CCOEFF_NORMED).max())
            cost = SPELLS[name][2]
            cost_score[cost] = max(cost_score.get(cost, -1), s)
        cost, score = max(cost_score.items(), key=lambda kv: kv[1])
        if score < 0.6:
            return None
        chroma = self._chroma(icon)
        lit = icon.max(2) > 25
        best = None
        for name, _, t_chroma, t_lit in self.bar_icons:
            if SPELLS[name][2] != cost:
                continue
            m = self.COOLDOWN_MASK & lit & t_lit
            if m.sum() < 300:
                continue
            d = float(np.abs(chroma - t_chroma)[m].mean())
            if best is None or d < best[0]:
                best = (d, name)
        return best[1] if best else None

    # -- ghosts -----------------------------------------------------------
    def find_ghosts(self, img):
        """Return a list of ghosts: dicts with element, x, y (centre), x0..y1 box.
        Ghosts are found by their dark face (survives glows/tints, counts each
        ghost separately, ignores spell effects)."""
        # Only faces count. The old colour-blob backup mistook spell explosions,
        # hit flashes and "+2" pickup popups for ghosts, so it is no longer used.
        # Ghosts still entering at the right edge are skipped: the red screen-edge
        # vignette tints them, so their colour isn't reliable yet.
        return [f for f in self._find_faces(img) if f["x"] < ENTERING_X]

    def _find_faces(self, img):
        """Find ghost faces by their pattern: a dark patch with two white square
        eyes, the same on every ghost. Works through glows, tints and pickups
        lying on top of a ghost, and ignores tickets, gems, rocks and spells."""
        x0, y0, x1, y1 = FIELD
        k = FACE_SCALE
        roi = cv2.resize(img[y0:y1, x0:x1], None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        res = cv2.matchTemplate(hsv[:, :, 2], FACE_TEMPLATE, cv2.TM_CCOEFF_NORMED)
        th, tw = FACE_TEMPLATE.shape
        found = []
        while True:
            _, score, _, (x, y) = cv2.minMaxLoc(res)
            if score < FACE_MATCH:
                break
            # blank this spot so the next-best match is a different ghost
            cv2.rectangle(res, (x - tw // 2, y - th // 2), (x + tw // 2, y + th // 2), -1, -1)
            # body = bright pixels around the face (inside a ring around it)
            pad = int(14 * k * 2)
            bx0, by0 = max(0, x - pad), max(0, y - pad)
            bx1, by1 = min(hsv.shape[1], x + tw + pad), min(hsv.shape[0], y + th + pad)
            ring = np.ones((by1 - by0, bx1 - bx0), bool)
            ring[(y + 6 - by0):(y + 38 - by0), (x + 7 - bx0):(x + 44 - bx0)] = False
            body = hsv[by0:by1, bx0:bx1][ring]
            element = self._body_element(body[body[:, 2] > 170])
            if not element:
                continue
            cx, cy = (x + tw / 2) / k + x0, (y + th / 2) / k + y0
            found.append({"element": element, "x": int(cx), "y": int(cy),
                          "x0": int(x / k + x0), "y0": int(y / k + y0),
                          "x1": int((x + tw) / k + x0), "y1": int((y + th) / k + y0),
                          "pixels": int(tw * th / k / k), "score": round(float(score), 2)})
        return found

    @staticmethod
    def _body_element(bright):
        """Ghost colour from the bright body pixels around its face."""
        S = bright[:, 1]
        if np.median(S) < 75:
            return "wind"          # white ghosts (also white ghosts tinted by a glow)
        hue = bright[S >= 75][:, 0]
        votes = {
            "fire": int(((hue >= 4) & (hue <= 19)).sum()),
            "light": int(((hue >= 20) & (hue <= 35)).sum()),
            "ice": int(((hue >= 80) & (hue <= 112)).sum()),
            "lightning": int(((hue >= 125) & (hue <= 170)).sum()),
        }
        best = max(votes, key=votes.get)
        return best if votes[best] > 0 else None
