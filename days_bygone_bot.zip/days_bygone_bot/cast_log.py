"""Measures what every ghost-battle spell actually does.

For each cast it remembers how many ghosts of that colour were on the field,
then ~1.2 s later counts again. Ghosts still walking in at the right edge are
ignored on both sides so new spawns don't hide kills. Results go to
debug/casts.csv (one row per cast) and debug/battle_log.csv (one row per battle).
Run  python analyze_casts.py  to see a summary.
"""
import csv
import os
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CAST_CSV = os.path.join(HERE, "debug", "casts.csv")
BATTLE_CSV = os.path.join(HERE, "debug", "battle_log.csv")
CHECK_AFTER = 1.2        # seconds after a cast to count again
SPAWN_X = 1600           # ghosts right of this may be new spawns: not counted


def _count(ghosts, element):
    return sum(1 for g in ghosts if g["element"] == element and g["x"] < SPAWN_X)


def _append(path, header, row):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        new = not os.path.exists(path)
        with open(path, "a", newline="") as f:
            w = csv.writer(f)
            if new:
                w.writerow(header)
            w.writerow(row)
    except OSError:
        pass


class CastLog:
    def __init__(self):
        self.reset()

    def reset(self):
        self.pending = []
        self.t0 = time.monotonic()
        self.casts = 0
        self.kills = 0
        self.zero_kill = 0
        self.max_ghosts = 0
        self.no_spell_s = 0.0
        self.last_t = None
        self.battle_id = time.strftime("%Y%m%d_%H%M%S")

    def cast(self, now, ghosts, element, spell, shape, drop, lead, mana_hint=""):
        self.casts += 1
        self.pending.append({"t": now, "element": element, "spell": spell, "shape": shape,
                             "drop": drop, "lead": lead, "before": _count(ghosts, element),
                             "nearest": min((g["x"] for g in ghosts if g["element"] == element), default=0)})

    def frame(self, now, ghosts, any_no_spell):
        """Call once per frame: settles casts that are old enough."""
        self.max_ghosts = max(self.max_ghosts, len(ghosts))
        if self.last_t is not None and any_no_spell:
            self.no_spell_s += now - self.last_t
        self.last_t = now
        keep = []
        for p in self.pending:
            if now - p["t"] < CHECK_AFTER:
                keep.append(p)
                continue
            after = _count(ghosts, p["element"])
            killed = max(0, p["before"] - after)
            self.kills += killed
            self.zero_kill += killed == 0 and p["before"] > 0
            _append(CAST_CSV,
                    ["battle", "t", "spell", "element", "shape", "ghosts_before", "ghosts_after", "killed",
                     "nearest_x", "drop_x", "drop_y", "lead"],
                    [self.battle_id, round(p["t"] - self.t0, 2), p["spell"], p["element"], p["shape"],
                     p["before"], after, killed, p["nearest"], int(p["drop"][0]), int(p["drop"][1]), p["lead"]])
        self.pending = keep

    def finish(self, result):
        _append(BATTLE_CSV,
                ["battle", "result", "seconds", "casts", "kills", "casts_that_killed_nothing",
                 "max_ghosts_on_screen", "seconds_with_no_spell_ready"],
                [self.battle_id, result, round(time.monotonic() - self.t0, 1), self.casts, self.kills,
                 self.zero_kill, self.max_ghosts, round(self.no_spell_s, 1)])
        self.reset()
