"""Reads the Hunt boss list (Battle -> Hunt): where each boss header is and
which level rows ("Mammon 7") are on screen.

Tapping a boss header opens its level list (1-11) right under it, which
pushes the other bosses down -- so nothing has a fixed position and the bot
finds the headers and reads the row numbers every time.
Templates: templates/hunt/boss_<Name>.png, templates/hunt/digit_<0-9>.png
"""
import glob
import os

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TPL_DIR = os.path.join(HERE, "templates", "hunt")
BOSSES = ["Asmodeus", "Leviathan", "Belphegor", "Mammon"]
LIST_X = (1195, 1875)          # the boss list column
ROW_TEXT_X = (1235, 1480)      # where a level row's label is (the row art starts right after)
ROW_TAP_X = 1530
HEADER_MATCH = 0.80
DW, DH = 12, 16                # normalised digit size

WHITE = ((0, 0, 200), (180, 12, 255))     # label text is pure white (Mammon pink / Asmodeus cream aren't)
PURPLE = ((135, 120, 150), (160, 255, 255))   # locked rows ("Mammon 11  VOID 360")


def _norm(bm):
    return cv2.resize(bm.astype(np.uint8) * 255, (DW, DH), interpolation=cv2.INTER_AREA) > 100


def _runs(mask):
    cols = (mask > 0).sum(0) > 0
    out, st = [], None
    for x, v in enumerate(list(cols) + [False]):
        if v and st is None:
            st = x
        elif not v and st is not None:
            out.append((st, x))
            st = None
    return out


class HuntReader:
    def __init__(self):
        self.bosses = {}
        for b in BOSSES:
            t = cv2.imread(os.path.join(TPL_DIR, f"boss_{b}.png"))
            if t is not None:
                self.bosses[b] = t
        self.digits = []
        for p in glob.glob(os.path.join(TPL_DIR, "digit_*.png")):
            d = os.path.splitext(os.path.basename(p))[0][-1]
            bm = cv2.imread(p, cv2.IMREAD_GRAYSCALE) > 100
            self.digits.append((d, _norm(bm), bm.shape[1] / bm.shape[0]))

    def ready(self):
        return len(self.bosses) == 4 and len(self.digits) == 10

    def header(self, img, boss):
        """Centre of the boss's header bar, or None."""
        t = self.bosses.get(boss)
        if t is None:
            return None
        x0, x1 = LIST_X
        roi = img[:, x0:x1]
        res = cv2.matchTemplate(roi, t, cv2.TM_CCOEFF_NORMED)
        _, score, _, (lx, ly) = cv2.minMaxLoc(res)
        if score < HEADER_MATCH:
            return None
        return x0 + lx + t.shape[1] // 2 + 200, ly + t.shape[0] // 2

    def headers(self, img):
        """{boss: y} for the headers on screen."""
        out = {}
        for b in self.bosses:
            h = self.header(img, b)
            if h:
                out[b] = h[1]
        return out

    def _digit(self, bm):
        f = _norm(bm)
        a = bm.shape[1] / bm.shape[0]
        best = min((np.mean(f != g) + 0.5 * abs(a - ga), d) for d, g, ga in self.digits)
        return best[1] if best[0] < 0.2 else None

    def _read_band(self, crop, color):
        hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
        m = cv2.inRange(hsv, *color)
        r = _runs(m)
        if len(r) < 3 or r[0][0] < 10:          # header text starts at the very left: not a row
            return None
        gaps = [(r[i + 1][0] - r[i][1], i) for i in range(len(r) - 1)]
        g, i = max(gaps)
        if g < 12:
            return None
        num = ""
        for a, b in r[i + 1:]:
            col = m[:, a:b] > 0
            ys = np.where(col.sum(1) > 0)[0]
            if len(ys) < 10:
                return None
            d = self._digit(col[ys.min():ys.max() + 1])
            if d is None:
                return None
            num += d
        return int(num) if num and len(num) <= 2 else None

    def rows(self, img, top=0, bottom=1080):
        """Level rows on screen between top and bottom: [(level, y, locked)].
        Rows are found as horizontal bands of label text in the list column."""
        x0, x1 = ROW_TEXT_X
        out = []
        for color, locked in ((WHITE, False), (PURPLE, True)):
            hsv = cv2.cvtColor(img[top:bottom, x0:x1], cv2.COLOR_BGR2HSV)
            m = cv2.inRange(hsv, *color)
            prof = (m > 0).sum(1) > 3
            y, n = 0, len(prof)
            while y < n:
                if not prof[y]:
                    y += 1
                    continue
                y2 = y
                while y2 < n and prof[y2]:
                    y2 += 1
                if 20 <= y2 - y <= 40:
                    cy = top + (y + y2) // 2
                    lv = self._read_band(img[top + y - 1:top + y2 + 1, x0:x1], color)
                    if lv is not None and 1 <= lv <= 20:
                        out.append((lv, cy, locked))
                y = y2
        return sorted(out, key=lambda r: r[1])
