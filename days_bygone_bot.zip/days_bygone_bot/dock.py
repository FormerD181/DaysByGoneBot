"""Attach the BlueStacks window to the bot window.

BlueStacks stays its own window (ADB doesn't care about its size). While
attached it is moved onto the bot's right panel, its top toolbar is clipped off
with a window region, it is kept directly above the bot window, and it follows
the bot when dragged / minimised. Detach puts it back exactly where it was.

(The bot window is deliberately NOT made BlueStacks' owner: if the bot ever
closed or crashed, Windows could take an owned BlueStacks down with it.)
"""
import ctypes
import ctypes.wintypes as W

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
SWP_NOSIZE, SWP_NOMOVE, SWP_NOZORDER, SWP_NOACTIVATE = 0x0001, 0x0002, 0x0004, 0x0010
SW_MINIMIZE, SW_RESTORE, SW_SHOWNOACTIVATE = 6, 9, 4
HWND_TOP, GW_HWNDPREV = 0, 3
user32.GetWindow.restype = W.HWND


def find_bluestacks():
    """Handle of the visible BlueStacks player window, or None."""
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, W.HWND, W.LPARAM)
    def cb(h, _):
        if user32.IsWindowVisible(h) or user32.IsIconic(h):
            n = user32.GetWindowTextLengthW(h)
            b = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(h, b, n + 1)
            t = b.value.lower()
            if t.startswith("bluestacks") and "multi" not in t and "x" != t:
                found.append(h)
        return True
    user32.EnumWindows(cb, 0)
    return found[0] if found else None


def _rect(h):
    r = W.RECT()
    user32.GetWindowRect(h, ctypes.byref(r))
    return r.left, r.top, r.right, r.bottom


def place(h, x, y, w, ht):
    """Resize, then move: BlueStacks ignores the position when both come in one call."""
    user32.SetWindowPos(h, 0, 0, 0, w, ht, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE)
    user32.SetWindowPos(h, 0, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)


def unclip():
    """Remove a toolbar clip left over from an earlier run (e.g. after a crash)."""
    h = find_bluestacks()
    if h:
        user32.SetWindowRgn(h, None, True)


class BlueStacksDock:
    def __init__(self, root, target, log):
        """target() -> (x, y, width, height) in screen pixels for the GAME picture."""
        self.root = root
        self.target = target
        self.log = log
        self.hwnd = None
        self.saved = None
        self.bar_h = 33
        self._job = None
        self._last = None
        self._minimised = False

    @property
    def attached(self):
        return self.hwnd is not None

    def _me(self):
        return int(self.root.frame(), 16)

    def attach(self):
        h = find_bluestacks()
        if not h:
            self.log("Attach: BlueStacks window not found -- is it open?")
            return False
        self.hwnd = h
        if user32.IsIconic(h):
            user32.ShowWindow(h, SW_RESTORE)
        self.saved = _rect(h)
        self._last = None
        self.follow()
        self.log("BlueStacks attached -- drag the bot and it follows")
        return True

    def detach(self, quiet=False):
        h, self.hwnd = self.hwnd, None
        if self._job:
            try:
                self.root.after_cancel(self._job)
            except Exception:  # noqa: BLE001
                pass
            self._job = None
        if not h or not user32.IsWindow(h):
            return
        user32.SetWindowRgn(h, None, True)
        if user32.IsIconic(h):
            user32.ShowWindow(h, SW_RESTORE)
        l, t, r, b = self.saved
        place(h, l, t, r - l, b - t)
        if not quiet:
            self.log("BlueStacks detached")

    @staticmethod
    def _visible_above(hwnd):
        """The first VISIBLE window above hwnd (Windows keeps invisible IME windows in between)."""
        w = hwnd
        for _ in range(200):
            w = user32.GetWindow(w, GW_HWNDPREV)
            if not w or user32.IsWindowVisible(w):
                return w
        return None

    def stack(self, _event=None):
        """Put BlueStacks right on top of the bot (only if it isn't already), so
        bringing either window forward brings both, with no flash."""
        h = self.hwnd
        if not h or self._minimised:
            return
        me = self._me()
        if self._visible_above(me) == h:
            return
        user32.SetWindowPos(h, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
        user32.SetWindowPos(me, h, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)

    def move_now(self, _event=None):
        """Move (never resize) BlueStacks to the panel -- called on every step of a
        drag so it moves together with the bot instead of catching up later."""
        h = self.hwnd
        if not h or self._minimised:
            return
        x, y, _, _ = self.target()
        y -= self.bar_h
        l, t, _, _ = _rect(h)
        if (l, t) != (x, y):
            user32.SetWindowPos(h, 0, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)

    def follow(self):
        """Keep BlueStacks on the panel (runs ~10x a second while attached)."""
        h = self.hwnd
        if not h:
            return
        if not user32.IsWindow(h):
            self.log("BlueStacks window closed -- detached")
            self.hwnd = None
            return
        me = self._me()
        if user32.IsIconic(me):                 # bot minimised -> minimise BlueStacks too
            if not self._minimised:
                user32.ShowWindow(h, SW_MINIMIZE)
                self._minimised = True
            self._job = self.root.after(200, self.follow)
            return
        if self._minimised:
            user32.ShowWindow(h, SW_SHOWNOACTIVATE)
            self._minimised = False
            self._last = None
        x, y, w, gh = self.target()
        size = (w, gh + self.bar_h)
        if size != self._last:
            # size changed (first attach / toolbar measured): resize + clip once
            place(h, x, y - self.bar_h, *size)
            l, t, r, b = _rect(h)
            cw, ch = r - l, b - t
            bar = ch - round(cw * 9 / 16)
            if 10 <= bar <= 80 and bar != self.bar_h:
                self.bar_h = bar                # re-place with the measured toolbar next tick
                self._last = None
            else:
                user32.SetWindowRgn(h, gdi32.CreateRectRgn(0, self.bar_h, cw, ch), True)
                self._last = size
        else:
            self.move_now()
            # something removed the toolbar clip (another program, BlueStacks redraw): put it back
            probe = gdi32.CreateRectRgn(0, 0, 0, 0)
            clipped = user32.GetWindowRgn(h, probe)
            gdi32.DeleteObject(probe)
            if clipped == 0:
                self._last = None
        # keep BlueStacks directly above the bot while either of them is in front
        if user32.GetForegroundWindow() in (me, h):
            self.stack()
        self._job = self.root.after(30, self.follow)
