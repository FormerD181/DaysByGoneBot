"""Summary of what the bot's ghost-battle spells actually do.

    python analyze_casts.py
"""
import csv
import os
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))


def read(name):
    path = os.path.join(HERE, "debug", name)
    if not os.path.exists(path):
        return []
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def main():
    battles = read("battle_log.csv")
    casts = read("casts.csv")
    if battles:
        wins = sum(b["result"] == "WIN" for b in battles)
        losses = sum(b["result"] == "LOSS" for b in battles)
        print(f"Battles: {len(battles)}   wins {wins}   losses {losses}")
        if losses:
            lost = [b for b in battles if b["result"] == "LOSS"]
            avg = lambda k: sum(float(b[k]) for b in lost) / len(lost)  # noqa: E731
            print(f"  in losses: avg {avg('casts_that_killed_nothing'):.1f} casts that killed nothing, "
                  f"{avg('seconds_with_no_spell_ready'):.1f}s with no spell ready")
        print()
    if not casts:
        print("No casts logged yet -- let the bot fight some ghost battles first.")
        return
    by = defaultdict(list)
    for c in casts:
        by[c["spell"]].append(int(c["killed"]))
    print(f"{'Spell':16}{'casts':>6}{'avg kills':>11}{'killed 0':>10}")
    for spell, k in sorted(by.items(), key=lambda kv: -len(kv[1])):
        print(f"{spell:16}{len(k):>6}{sum(k) / len(k):>11.2f}{sum(x == 0 for x in k) / len(k):>9.0%}")


if __name__ == "__main__":
    main()
