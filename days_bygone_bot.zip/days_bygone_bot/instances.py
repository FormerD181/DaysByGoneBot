"""BlueStacks multi-instance support.

Every BlueStacks instance has its own ADB port and window title (from
C:\\ProgramData\\BlueStacks_nxt\\bluestacks.conf). Each bot window runs ONE
instance, chosen with  --instance <name>  (default: the first instance).
The default instance keeps settings.json; others use settings_<name>.json.
"""
import ctypes
import os
import re
import subprocess
import sys

CONF = r"C:\ProgramData\BlueStacks_nxt\bluestacks.conf"
HERE = os.path.dirname(os.path.abspath(__file__))


def list_instances():
    """[{name, display, port}] in BlueStacks' order. Falls back to the default instance."""
    try:
        with open(CONF, encoding="utf-8", errors="ignore") as f:
            text = f.read()
    except OSError:
        return [{"name": "default", "display": "BlueStacks", "port": 5555}]
    names = []
    m = re.search(r'^bst\.installed_images="([^"]*)"', text, re.M)
    for name in re.findall(r'^bst\.instance\.([A-Za-z0-9_]+)\.adb_port=', text, re.M):
        if name not in names:
            names.append(name)
    out = []
    for name in names:
        port = re.search(rf'^bst\.instance\.{re.escape(name)}\.status\.adb_port="(\d+)"', text, re.M) or \
            re.search(rf'^bst\.instance\.{re.escape(name)}\.adb_port="(\d+)"', text, re.M)
        disp = re.search(rf'^bst\.instance\.{re.escape(name)}\.display_name="([^"]*)"', text, re.M)
        if port:
            out.append({"name": name, "display": disp.group(1) if disp else name, "port": int(port.group(1))})
    # the installed image (first instance) first
    if m and out:
        first = m.group(1).split(",")[0]
        out.sort(key=lambda i: i["name"] != first)
    return out or [{"name": "default", "display": "BlueStacks", "port": 5555}]


def chosen_name(argv=None):
    argv = sys.argv if argv is None else argv
    if "--instance" in argv:
        i = argv.index("--instance")
        if i + 1 < len(argv):
            return argv[i + 1]
    return None


def current():
    """The instance this process runs (from --instance, else the first one)."""
    all_ = list_instances()
    want = chosen_name()
    for inst in all_:
        if inst["name"] == want:
            return inst
    return all_[0]


def is_default(inst):
    return inst["name"] == list_instances()[0]["name"]


def settings_path(inst):
    return os.path.join(HERE, "settings.json" if is_default(inst) else f"settings_{inst['name']}.json")


def serial(inst):
    return f"127.0.0.1:{inst['port']}"


_mutex = None


def claim(inst):
    """Only one bot window per instance. Returns False if one is already open."""
    global _mutex
    try:
        k = ctypes.windll.kernel32
        h = k.CreateMutexW(None, False, f"DaysBygoneBot_{inst['name']}")
        if k.GetLastError() == 183:              # ERROR_ALREADY_EXISTS: another window has it
            k.CloseHandle(h)                     # don't keep it alive ourselves
            return False
        _mutex = h
        return True
    except (AttributeError, OSError):
        return True


def open_window(inst):
    """Start another bot window for an instance."""
    exe = sys.executable
    pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
    subprocess.Popen([pyw if os.path.exists(pyw) else exe, os.path.join(HERE, "ui.py"), "--instance", inst["name"]],
                     cwd=HERE, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))
