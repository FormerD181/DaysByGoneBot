"""BlueStacks multi-instance support.

Every BlueStacks instance has its own ADB port and window title (from
C:\\ProgramData\\BlueStacks_nxt\\bluestacks.conf). Each bot window runs ONE
instance, chosen with  --instance <name>  (default: the first instance).
The default instance keeps settings.json; others use settings_<name>.json.
"""
import ctypes
import os
import re
import subprocess
import sys

CONF = r"C:\ProgramData\BlueStacks_nxt\bluestacks.conf"
HERE = os.path.dirname(os.path.abspath(__file__))


def list_instances():
    """[{name, display, port}] in BlueStacks' order. Falls back to the default instance."""
    try:
        with open(CONF, encoding="utf-8", errors="ignore") as f:
            text = f.read()
    except OSError:
        return [{"name": "default", "display": "BlueStacks", "port": 5555}]
    names = []
    m = re.search(r'^bst\.installed_images="([^"]*)"', text, re.M)
    for name in re.findall(r'^bst\.instance\.([A-Za-z0-9_]+)\.adb_port=', text, re.M):
        if name not in names:
            names.append(name)
    out = []
    for name in names:
        port = re.search(rf'^bst\.instance\.{re.escape(name)}\.status\.adb_port="(\d+)"', text, re.M) or \
            re.search(rf'^bst\.instance\.{re.escape(name)}\.adb_port="(\d+)"', text, re.M)
        disp = re.search(rf'^bst\.instance\.{re.escape(name)}\.display_name="([^"]*)"', text, re.M)
        if port:
            out.append({"name": name, "display": disp.group(1) if disp else name, "port": int(port.group(1))})
    # the installed image (first instance) first
    if m and out:
        first = m.group(1).split(",")[0]
        out.sort(key=lambda i: i["name"] != first)
    return out or [{"name": "default", "display": "BlueStacks", "port": 5555}]


def chosen_name(argv=None):
    argv = sys.argv if argv is None else argv
    if "--instance" in argv:
        i = argv.index("--instance")
        if i + 1 < len(argv):
            return argv[i + 1]
    return None


def current():
    """The instance this process runs (from --instance, else the first one)."""
    all_ = list_instances()
    want = chosen_name()
    for inst in all_:
        if inst["name"] == want:
            return inst
    return all_[0]


def is_default(inst):
    return inst["name"] == list_instances()[0]["name"]


def settings_path(inst):
    return os.path.join(HERE, "settings.json" if is_default(inst) else f"settings_{inst['name']}.json")


def serial(inst):
    return f"127.0.0.1:{inst['port']}"


_mutex = None


def claim(inst):
    """Only one bot window per instance. Returns False if one is already open."""
    global _mutex
    try:
        k = ctypes.windll.kernel32
        h = k.CreateMutexW(None, False, f"DaysBygoneBot_{inst['name']}")
        if k.GetLastError() == 183:              # ERROR_ALREADY_EXISTS: another window has it
            k.CloseHandle(h)                     # don't keep it alive ourselves
            return False
        _mutex = h
        return True
    except (AttributeError, OSError):
        return True


def open_window(inst):
    """Start another bot window for an instance."""
    exe = sys.executable
    pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
    subprocess.Popen([pyw if os.path.exists(pyw) else exe, os.path.join(HERE, "ui.py"), "--instance", inst["name"]],
                     cwd=HERE, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))


def _window_title(inst):
    return f"Days Bygone Bot – {inst['display']}" if len(list_instances()) > 1 else None


def find_window(inst):
    """The open bot window for this instance (its hwnd), or None."""
    import ctypes.wintypes as W
    u = ctypes.windll.user32
    want = _window_title(inst)
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, W.HWND, W.LPARAM)
    def cb(h, _):
        n = u.GetWindowTextLengthW(h)
        b = ctypes.create_unicode_buffer(n + 1)
        u.GetWindowTextW(h, b, n + 1)
        t = b.value
        if (t == want) if want else t.startswith("Days Bygone Bot"):
            pid = W.DWORD()
            u.GetWindowThreadProcessId(h, ctypes.byref(pid))
            if pid.value != os.getpid():
                found.append(h)
        return True
    u.EnumWindows(cb, 0)
    return found[0] if found else None


def bring_forward(hwnd):
    """Restore, move onto the main screen if it's off every monitor, and focus it."""
    import ctypes.wintypes as W
    u = ctypes.windll.user32
    if u.IsIconic(hwnd) or not u.IsWindowVisible(hwnd):
        u.ShowWindow(hwnd, 9)                                      # SW_RESTORE
    r = W.RECT()
    u.GetWindowRect(hwnd, ctypes.byref(r))
    MONITOR_DEFAULTTONULL = 0
    pt = W.POINT((r.left + r.right) // 2, r.top + 20)
    if not u.MonitorFromPoint(pt, MONITOR_DEFAULTTONULL):          # off-screen (monitor unplugged / off)
        u.SetWindowPos(hwnd, 0, 60, 60, 0, 0, 0x0001 | 0x0004)     # SWP_NOSIZE | SWP_NOZORDER
    u.keybd_event(0x12, 0, 0, 0)                                   # Alt lets SetForegroundWindow work
    u.SetForegroundWindow(hwnd)
    u.keybd_event(0x12, 0, 2, 0)


def stuck_pids(inst):
    """Other bot processes for this instance (python running ui.py)."""
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command",
                              "Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | "
                              "ForEach-Object { \"$($_.ProcessId)|$($_.CommandLine)\" }"],
                             capture_output=True, text=True, timeout=20,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    pids = []
    default = list_instances()[0]["name"] == inst["name"]
    for line in out.splitlines():
        pid, _, cmd = line.partition("|")
        if "ui.py" not in cmd or not pid.strip().isdigit() or int(pid) == os.getpid():
            continue
        named = re.search(r"--instance\s+(\S+)", cmd)
        if (named and named.group(1).strip('"') == inst["name"]) or (not named and default):
            pids.append(int(pid))
    return pids


def kill(pids):
    for pid in pids:
        subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
