"""Records every ghost battle as a video with the bot's "thinking" drawn on top.

Saved to debug/battles/<time>_WIN.mp4 / _LOSS.mp4 / _STOPPED.mp4 (last 15 kept).
"""
import os
import time

import cv2

HERE = os.path.dirname(os.path.abspath(__file__))
BATTLE_DIR = os.path.join(HERE, "debug", "battles")
KEEP_VIDEOS = 15
FPS = 10                      # frames are duplicated as needed so playback is real-time
SIZE = (960, 540)             # half of the 1920x1080 game screen
K = 0.5                       # game coords -> video coords
CAST_SHOW_S = 0.7             # how long a cast arrow stays on screen

COLORS = {"fire": (0, 80, 255), "light": (0, 230, 255), "lightning": (255, 0, 200),
          "ice": (255, 150, 0), "wind": (255, 255, 255)}
GREEN, RED, YELLOW, WHITE = (60, 220, 60), (60, 60, 230), (0, 230, 255), (255, 255, 255)


def _p(x, y):
    return int(x * K), int(y * K)


class BattleRecorder:
    def __init__(self):
        self.writer = None
        self.path = None

    @property
    def recording(self):
        return self.writer is not None

    def start(self):
        os.makedirs(BATTLE_DIR, exist_ok=True)
        self.stamp = time.strftime("%Y%m%d_%H%M%S")
        self.path = os.path.join(BATTLE_DIR, f"{self.stamp}_recording.mp4")
        self.writer = cv2.VideoWriter(self.path, cv2.VideoWriter_fourcc(*"mp4v"), FPS, SIZE)
        if not self.writer.isOpened():
            self.writer = None
            return
        self.t0 = time.monotonic()
        self.written = 0
        self.casts = []           # (time, slot_center, drop, label)
        self.last_frame = None

    def note_cast(self, slot_xy, drop_xy, label):
        if self.recording:
            self.casts.append((time.monotonic(), slot_xy, drop_xy, label))

    def frame(self, img, ghosts, bar, usable, slots, statuses):
        """Draw one annotated frame and write it (duplicated to keep real time)."""
        if not self.recording:
            return
        now = time.monotonic()
        v = cv2.resize(img, SIZE, interpolation=cv2.INTER_AREA)

        # ghosts
        for g in ghosts:
            c = COLORS.get(g["element"], GREEN)
            x0, y0, x1, y1 = g["x0"], g["y0"], g["x1"], g["y1"]
            if x1 - x0 < 140:               # face boxes: grow to roughly the ghost's body
                x0, y0, x1, y1 = x0 - 40, y0 - 50, x1 + 40, y1 + 40
            cv2.rectangle(v, _p(x0, y0), _p(x1, y1), c, 2)
            cv2.putText(v, g["element"], _p(x0, y0 - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.45, c, 1, cv2.LINE_AA)

        # spell bar: green = usable now, red = cooldown / no mana / unknown
        for i, (sx0, sy0, sx1, sy1) in enumerate(slots or []):
            ok = i in usable
            cv2.rectangle(v, _p(sx0, sy0), _p(sx1, sy1), GREEN if ok else RED, 2)
            name = (bar[i]["name"] if bar and bar[i]["name"] else "?")
            state = bar[i]["state"] if bar else ""
            label = name.replace("_", " ")[:11] + ("" if ok else f" ({state})")
            cv2.putText(v, label, _p(sx0, sy0 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.32, GREEN if ok else RED,
                        1, cv2.LINE_AA)

        # recent casts: arrow from the slot to where the spell was dropped
        self.casts = [c for c in self.casts if now - c[0] < CAST_SHOW_S]
        for _, s, d, label in self.casts:
            cv2.arrowedLine(v, _p(*s), _p(*d), YELLOW, 2, cv2.LINE_AA, tipLength=0.06)
            cv2.circle(v, _p(*d), 14, YELLOW, 2, cv2.LINE_AA)
            cv2.putText(v, label, (_p(*d)[0] + 18, _p(*d)[1] - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, YELLOW,
                        2, cv2.LINE_AA)

        # reasoning panel (top-left)
        lines = [(f"battle {now - self.t0:5.1f}s   ghosts seen: {len(ghosts)}", WHITE)]
        lines += [(f"{el}: {why}", COLORS.get(el, WHITE)) for el, why in statuses.items()]
        h = 18 * len(lines) + 10
        panel = v[44:44 + h, 6:470].copy()
        cv2.rectangle(v, (6, 44), (470, 44 + h), (0, 0, 0), -1)
        cv2.addWeighted(panel, 0.35, v[44:44 + h, 6:470], 0.65, 0, v[44:44 + h, 6:470])
        for i, (text, c) in enumerate(lines):
            cv2.putText(v, text, (12, 60 + 18 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.45, c, 1, cv2.LINE_AA)

        self._write(v, now)

    def _write(self, v, now):
        target = int((now - self.t0) * FPS) + 1
        if self.written >= target:      # more frames than the video needs: keep real time
            self.last_frame = v
            return
        # fill any gap with the previous frame so the video plays at real speed
        while self.written < target - 1 and self.last_frame is not None:
            self.writer.write(self.last_frame)
            self.written += 1
        self.writer.write(v)
        self.written += 1
        self.last_frame = v

    def finish(self, result):
        """Close the video and name it by result. Returns the file path (or None)."""
        if not self.recording:
            return None
        self.writer.release()
        self.writer = None
        final = os.path.join(BATTLE_DIR, f"{self.stamp}_{result}.mp4")
        try:
            os.replace(self.path, final)
            videos = sorted(f for f in os.listdir(BATTLE_DIR) if f.endswith(".mp4"))
            for old in videos[:-KEEP_VIDEOS]:
                os.remove(os.path.join(BATTLE_DIR, old))
        except OSError:
            final = self.path
        return final
