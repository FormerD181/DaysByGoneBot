"""Phone remote: a small web page served by the bot, so you can watch the game
and answer a human check from your phone (from anywhere, through Tailscale).

  http://<pc>:8765   -> PIN login, then a live picture of the game.
  Tap the picture to tap the game. START / STOP the bot. Status + recent log.

Only devices on your home network or your Tailscale account can reach it (the
page is never put on the open internet), and it always asks for your PIN.
The bot never answers human checks itself -- you do, from the phone.
"""
import hmac
import http.server
import json
import secrets
import socket
import socketserver
import subprocess
import threading
import time
import urllib.parse

import cv2

PORT_BASE = 8765
TAILSCALE = r"C:\Program Files\Tailscale\tailscale.exe"

PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>Days Bygone Bot</title>
<style>
 :root{color-scheme:dark}
 body{margin:0;background:#121216;color:#e8e8ee;font-family:system-ui,Segoe UI,sans-serif}
 header{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#1b1b21}
 header b{flex:1;font-size:16px}
 #dot{width:10px;height:10px;border-radius:5px;background:#777}
 #shotbox{position:relative}
 #shot{width:100%;display:block;touch-action:none;background:#000;user-select:none;-webkit-user-select:none;
       -webkit-touch-callout:none}
 #mark{position:absolute;width:26px;height:26px;margin:-13px 0 0 -13px;border:3px solid #ffcd00;
       border-radius:50%;pointer-events:none;display:none}
 .row{display:flex;gap:8px;padding:10px 12px}
 button{flex:1;font-size:17px;font-weight:700;padding:14px;border:0;border-radius:12px;color:#fff}
 #start{background:#2ea85a}#stop{background:#c0392b}button:disabled{opacity:.35}
 #status{padding:0 12px;color:#ffcd00;font-weight:600}
 #check{display:none;margin:10px 12px;padding:10px;border-radius:10px;background:#5a1d1d;color:#ffb3b3;font-weight:700}
 #log{margin:8px 12px 20px;padding:8px;background:#1b1b21;border-radius:10px;font:12px Consolas,monospace;
      white-space:pre-wrap;max-height:40vh;overflow:auto;color:#cfcfd6}
 small{color:#888;padding:0 12px;display:block}
</style></head><body>
<header><span id="dot"></span><b id="title">Days Bygone Bot</b><span id="timer">--</span></header>
<div id="check">HUMAN CHECK -- answer it on the picture, then press START.</div>
<div id="shotbox"><img id="shot" alt="game"><div id="mark"></div></div>
<small>Tap or swipe the picture to tap / swipe the game.</small>
<div class="row"><button id="start">START</button><button id="stop">STOP</button></div>
<div id="status"></div>
<div id="log"></div>
<script>
const shot=document.getElementById('shot'), mark=document.getElementById('mark');
// live video while the page is open (falls back to single pictures if the stream drops)
function stream(){ shot.src='stream?'+Date.now(); }
shot.onerror=()=>setTimeout(stream,1500);
document.addEventListener('visibilitychange',()=>{ if(document.hidden) shot.src=''; else stream(); });
stream();
// gestures: a short touch = tap, a drag = swipe (same direction and length as your finger)
let g=null;
function pos(e){ const r=shot.getBoundingClientRect(), p=e.touches?e.touches[0]||e.changedTouches[0]:e;
  return {x:(p.clientX-r.left)/r.width, y:(p.clientY-r.top)/r.height, px:p.clientX-r.left, py:p.clientY-r.top}; }
function down(e){ e.preventDefault(); const p=pos(e); g={x:p.x,y:p.y,t:Date.now()}; ring(p); }
function up(e){ if(!g) return; e.preventDefault(); const p=pos(e), dx=p.x-g.x, dy=p.y-g.y;
  const ms=Math.max(150,Math.min(1500,Date.now()-g.t));
  const body = Math.hypot(dx*16,dy*9) < 0.35 ? 'kind=tap&x='+g.x+'&y='+g.y
             : 'kind=swipe&x='+g.x+'&y='+g.y+'&x2='+p.x+'&y2='+p.y+'&ms='+ms;
  fetch('touch',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body}); g=null; }
function ring(p){ mark.style.left=p.px+'px'; mark.style.top=p.py+'px'; mark.style.display='block';
  setTimeout(()=>mark.style.display='none',500); }
shot.addEventListener('touchstart',down,{passive:false}); shot.addEventListener('touchend',up,{passive:false});
shot.addEventListener('mousedown',down); shot.addEventListener('mouseup',up);
document.getElementById('start').onclick=()=>fetch('start',{method:'POST'}).then(status);
document.getElementById('stop').onclick=()=>fetch('stop',{method:'POST'}).then(status);
function status(){ fetch('status').then(r=>r.json()).then(s=>{
  document.getElementById('title').textContent=s.title;
  document.getElementById('timer').textContent=s.timer;
  document.getElementById('dot').style.background=s.check?'#e74c3c':(s.running?'#2ecc71':'#777');
  document.getElementById('start').disabled=s.running; document.getElementById('stop').disabled=!s.running;
  document.getElementById('status').textContent=s.status;
  document.getElementById('check').style.display=s.check?'block':'none';
  const L=document.getElementById('log'); L.textContent=s.log.join('\\n'); }).catch(()=>{}); }
setInterval(status,2000); status();
</script></body></html>"""

LOGIN = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Days Bygone Bot</title>
<style>:root{color-scheme:dark}body{background:#121216;color:#e8e8ee;font-family:system-ui,sans-serif;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
form{display:flex;flex-direction:column;gap:12px;width:240px}input,button{font-size:20px;padding:12px;
border-radius:10px;border:0}button{background:#ffcd00;font-weight:700}p{color:#e74c3c;margin:0}</style>
</head><body><form method="post" action="login"><b>Days Bygone Bot</b>
<input name="pin" type="password" inputmode="numeric" placeholder="PIN" autofocus>%s
<button>Open</button></form></body></html>"""


def tailscale_name():
    """'my-pc' (Tailscale machine name) or None if Tailscale isn't signed in."""
    try:
        out = subprocess.run([TAILSCALE, "status", "--json"], capture_output=True, text=True, timeout=8,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
        me = json.loads(out).get("Self") or {}
        ips = [ip for ip in (me.get("TailscaleIPs") or []) if "." in ip]     # the 100.x address
        if ips:
            return ips[0]
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    return None


def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


def _allowed_client(ip):
    """Home network, this PC, or Tailscale (100.64.0.0/10) only."""
    try:
        a, b = (int(p) for p in ip.split(".")[:2])
    except ValueError:
        return ip in ("::1",)
    return (a == 127 or a == 10 or (a == 192 and b == 168) or (a == 172 and 16 <= b <= 31)
            or (a == 100 and 64 <= b <= 127))


class RemoteServer:
    def __init__(self, app, port):
        """app: the bot window (App). Uses app.remote_* hooks, all thread-safe."""
        self.app = app
        self.port = port
        self.httpd = None
        self.token = secrets.token_hex(16)
        self.fails = {}
        self._dev = None
        self._dev_lock = threading.Lock()
        self._frame = (0, None)              # (number, jpeg) -- the newest picture
        self._frame_cond = threading.Condition()
        self._viewers_seen = 0.0             # last time a phone was watching
        self._grabber = None

    # -- device (own ADB connection, only used for the picture and taps) ------
    def _device(self):
        if self._dev is None:
            from adb import Device
            self._dev = Device()
            self._dev.connect()
        return self._dev

    def screenshot_jpg(self):
        with self._dev_lock:
            try:
                img = self._device().screenshot()
            except Exception:  # noqa: BLE001 - BlueStacks closed / reconnecting
                self._dev = None
                return None
        small = cv2.resize(img, (960, 540), interpolation=cv2.INTER_AREA)
        ok, buf = cv2.imencode(".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 70])
        return buf.tobytes() if ok else None

    # -- live picture: one grabber shared by every viewer, only while someone watches --
    STREAM_FPS = 8          # while the bot is stopped (e.g. answering a human check)
    STREAM_FPS_BUSY = 3     # while the bot is playing: keep ADB free for the bot

    VIDEO_FPS = 15          # frames sent to the phone per second (real video from BlueStacks)

    def _publish(self, img, n):
        small = cv2.resize(img, (768, 432), interpolation=cv2.INTER_AREA)
        ok, buf = cv2.imencode(".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 55])
        if ok:
            with self._frame_cond:
                self._frame = (n, buf.tobytes())
                self._frame_cond.notify_all()

    def _video_loop(self):
        """Real video: BlueStacks records its screen as H.264 (adb screenrecord),
        decoded here with PyAV. ~20 fps. Returns False if it isn't available."""
        try:
            import av
        except ImportError:
            return False
        from adb import Device
        dev = Device()
        n, sent = 0, 0.0
        while time.time() - self._viewers_seen < 5:
            busy = self.app.remote_status().get("running")
            proc = subprocess.Popen(
                [dev.adb, "-s", dev.serial, "exec-out", "screenrecord", "--output-format=h264",
                 "--size", "960x540", "--bit-rate", "1500000" if busy else "3000000", "-"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            codec = av.CodecContext.create("h264", "r")
            got = False
            try:
                while time.time() - self._viewers_seen < 5:
                    data = proc.stdout.read1(65536)
                    if not data:
                        break                       # recording ended (Android stops it after 3 min)
                    for pkt in codec.parse(data):
                        for frame in codec.decode(pkt):
                            got = True
                            now = time.time()
                            if now - sent >= 1.0 / self.VIDEO_FPS:
                                sent = now
                                n += 1
                                self._publish(frame.to_ndarray(format="bgr24"), n)
            except Exception:  # noqa: BLE001 - decoder hiccup: restart the recording
                pass
            finally:
                proc.kill()
            if not got:
                return n > 0                        # screenrecord doesn't work here
        return True

    def _grab_loop(self):
        if not self._video_loop():
            # fallback: screenshots (choppier)
            n = 0
            while time.time() - self._viewers_seen < 5:
                t0 = time.time()
                with self._dev_lock:
                    try:
                        img = self._device().screenshot_fast()
                    except Exception:  # noqa: BLE001
                        self._dev = None
                        img = None
                if img is not None:
                    n += 1
                    self._publish(img, n)
                fps = self.STREAM_FPS_BUSY if self.app.remote_status().get("running") else self.STREAM_FPS
                time.sleep(max(0.0, 1.0 / fps - (time.time() - t0)))
        self._grabber = None

    def watching(self):
        self._viewers_seen = time.time()
        if self._grabber is None:
            self._grabber = threading.Thread(target=self._grab_loop, daemon=True)
            self._grabber.start()

    def next_frame(self, after, timeout=3.0):
        self.watching()
        with self._frame_cond:
            self._frame_cond.wait_for(lambda: self._frame[0] > after, timeout)
            return self._frame

    def swipe(self, fx, fy, fx2, fy2, ms):
        pts = [int(max(0, min(1, v)) * m) for v, m in ((fx, 1920), (fy, 1080), (fx2, 1920), (fy2, 1080))]
        with self._dev_lock:
            try:
                self._device().swipe(*pts, int(max(100, min(2000, ms))))
            except Exception:  # noqa: BLE001
                self._dev = None
                return False
        return True

    def tap(self, fx, fy):
        x, y = int(max(0, min(1, fx)) * 1920), int(max(0, min(1, fy)) * 1080)
        with self._dev_lock:
            try:
                self._device().tap(x, y)
            except Exception:  # noqa: BLE001
                self._dev = None
                return False
        self.app.remote_log(f"Phone tap at ({x}, {y})")
        return True

    # -- server ----------------------------------------------------------------------
    def start(self):
        srv = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, body, ctype="text/html; charset=utf-8", extra=None):
                if isinstance(body, str):
                    body = body.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Cache-Control", "no-store")
                for k, v in (extra or {}).items():
                    self.send_header(k, v)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def _authed(self):
                ck = self.headers.get("Cookie", "")
                for part in ck.split(";"):
                    k, _, v = part.strip().partition("=")
                    if k == "dbb" and hmac.compare_digest(v, srv.token):
                        return True
                return False

            def _gate(self):
                if not _allowed_client(self.client_address[0]):
                    self._send(403, "Not allowed from this network")
                    return False
                return True

            def do_GET(self):
                if not self._gate():
                    return
                path = urllib.parse.urlparse(self.path).path
                if not self._authed():
                    return self._send(200, LOGIN % "")
                if path in ("/", "/index.html"):
                    return self._send(200, PAGE)
                if path == "/stream":
                    # MJPEG: the phone's <img> shows it as live video
                    self.send_response(200)
                    self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    last = 0
                    try:
                        while srv.httpd is not None:
                            n, jpg = srv.next_frame(last)
                            if jpg is None or n == last:
                                continue
                            last = n
                            self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "
                                             + str(len(jpg)).encode() + b"\r\n\r\n" + jpg + b"\r\n")
                            self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                        pass
                    return
                if path == "/shot.jpg":
                    jpg = srv.screenshot_jpg()
                    return self._send(200, jpg, "image/jpeg") if jpg else self._send(503, "no picture")
                if path == "/status":
                    return self._send(200, json.dumps(srv.app.remote_status()), "application/json")
                self._send(404, "not found")

            def do_POST(self):
                if not self._gate():
                    return
                path = urllib.parse.urlparse(self.path).path
                n = int(self.headers.get("Content-Length") or 0)
                form = urllib.parse.parse_qs(self.rfile.read(min(n, 4096)).decode("utf-8", "ignore"))
                if path == "/login":
                    ip = self.client_address[0]
                    fails, until = srv.fails.get(ip, (0, 0))
                    if time.time() < until:
                        return self._send(429, LOGIN % "<p>Too many tries -- wait a minute.</p>")
                    pin = srv.app.remote_pin()
                    if pin and hmac.compare_digest((form.get("pin") or [""])[0].strip(), pin):
                        srv.fails.pop(ip, None)
                        return self._send(303, "", extra={
                            "Location": "/", "Set-Cookie": f"dbb={srv.token}; HttpOnly; SameSite=Strict; Path=/"})
                    fails += 1
                    srv.fails[ip] = (fails, time.time() + 60 if fails >= 5 else 0)
                    srv.app.remote_log("Phone remote: wrong PIN")
                    return self._send(200, LOGIN % "<p>Wrong PIN.</p>")
                if not self._authed():
                    return self._send(401, "log in first")
                if path == "/touch":
                    try:
                        f = {k: float(v[0]) for k, v in form.items() if k != "kind"}
                        if (form.get("kind") or ["tap"])[0] == "swipe":
                            ok = srv.swipe(f["x"], f["y"], f["x2"], f["y2"], f.get("ms", 300))
                        else:
                            ok = srv.tap(f["x"], f["y"])
                    except (KeyError, ValueError):
                        ok = False
                    return self._send(200 if ok else 503, "ok" if ok else "no device")
                if path == "/tap":
                    try:
                        ok = srv.tap(float(form["x"][0]), float(form["y"][0]))
                    except (KeyError, ValueError):
                        ok = False
                    return self._send(200 if ok else 503, "ok" if ok else "no device")
                if path in ("/start", "/stop"):
                    srv.app.remote_command(path[1:])
                    return self._send(200, "ok")
                self._send(404, "not found")

        class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
            allow_reuse_address = True

        self.httpd = Server(("0.0.0.0", self.port), Handler)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def stop(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
        with self._dev_lock:
            if self._dev:
                try:
                    self._dev.close()
                except Exception:  # noqa: BLE001
                    pass
                self._dev = None

    def urls(self):
        out = []
        ts = tailscale_name()
        if ts:
            out.append(("Anywhere (Tailscale)", f"http://{ts}:{self.port}"))
        ip = local_ip()
        if ip:
            out.append(("Home Wi-Fi", f"http://{ip}:{self.port}"))
        return out
