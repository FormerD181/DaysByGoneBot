"""Ghost battle: drag the spell matching each ghost's colour onto it."""
import os
import time

import cv2

import humanize
from battle_recorder import BattleRecorder
from cast_log import CastLog
from vision import SPELLS

HERE = os.path.dirname(os.path.abspath(__file__))
SHOT_DIR = os.path.join(HERE, "debug", "ghost")

# After a colour first shows up, wait this long so the rest of the wave can
# spawn (one spell then hits more ghosts). Also filters out one-frame flashes
# from spell effects.
SPAWN_WAIT = 0.5
# ...unless a ghost of that colour is already this close to the wall (x px;
# the wall is around x=300) -- then cast right away.
URGENT_X = 1250
# A colour that vanishes for longer than this counts as a new wave next time.
NEW_WAVE_GAP = 0.6
# Wait this long before casting at the same colour again so the first spell
# can land (and so we don't dump all our mana at once).
ELEMENT_RECAST_DELAY = 0.6
# The top spell of each colour (74/84 mana) clears the whole screen. If one is
# in the bar but not ready yet and a big group (SAVE_FIELD_FOR+) is coming, hold
# for it instead of spending mana on small spells -- until HOLD_S from the wall.
# Save a full-res picture of the hot bar this often during ghost battles so
# exact icon templates can be built from them.
BAR_DIR = os.path.join(HERE, "debug", "bar")
SHOT_COLORS = {"fire": (0, 80, 255), "light": (0, 230, 255), "lightning": (255, 0, 200),
               "ice": (255, 150, 0), "wind": (255, 255, 255)}
BAR_SAVE_EVERY = 1.0
# Ghosts walk toward the wall, so aim just ahead of where they'll be when the
# spell lands. Their speed is measured from frame to frame.
AIM_AHEAD_S = 0.30          # drag + spell landing delay (seconds); frame age is added on top
DEFAULT_SPEED = 200         # px/s used until a colour's speed has been measured
# measured medians from recorded battles (light ghosts are much faster)
DEFAULT_SPEEDS = {"light": 380, "fire": 310, "wind": 255, "ice": 255, "lightning": 230}
MIN_LEAD, MAX_LEAD = 15, 260
# The ghost closest to the wall always comes first: once it is past this x,
# its colour skips the wave-wait and hold-for-big rules and gets cast at now.
FRONT_DANGER_X = 1100
# Column spells (Gust, Ice Shard) are instant: measured from 53 recorded casts,
# a ghost dies if it's within ~-180..+50 px of the column when it lands, and
# every miss was the column landing too far AHEAD. So lead them only a little.
VLINE_AHEAD_S = 0.15
TRACK_MATCH_PX = 120        # a ghost this close to one last frame is the same ghost
TRACK_FORGET_S = 0.6        # tracks unseen this long are dropped
SPEED_WINDOW = 0.6          # each ghost's speed = its own movement over this long
# Real ghosts always walk toward the wall (150+ px/s). Something that stays put
# this long is a spell's leftover glow (e.g. Genesis' beam read as a light ghost).
STILL_S, STILL_PX = 0.6, 45
MIN_TRACK_FRAMES = 2        # a ghost must be seen this many frames before it counts
# How close another ghost must be to also get hit, per spell shape.
# How far from the drop point each spell hits (game pixels, 1920x1080 screen).
# Shapes and sizes from the player's screenshots + 53 recorded casts:
#   circle spells -> radius;  vline -> half-width of the column;  ray -> half-width of the beam
SPELL_REACH = {
    "zap": 110,             # small circle
    "fireball": 240,        # explosion ~200 px + a ghost's half-body (one between two rows hits both)
    "flamelance": 80,       # beam from the hero through the drop point, to the screen edge
    "glacial_prison": 150,  # three big circles stacked in a column
    "gust": 150,            # horizontal band (~300 px tall) across the screen
    "ice_shard": 130,       # full-height column
    "genesis": 60,          # thin full-height beam
    "thunderbolt": 240,     # Fireball-sized circle
    "deuteronomy": 70,      # X: distance from either diagonal line
}
CROSS_SLOPE = 0.62          # Deuteronomy's diagonals (rise/run, from the screenshot)
DEFAULT_REACH = {"area": 200, "vline": 130, "hline": 150, "ray": 80, "cross": 70}
# Gust (hline): a full-width band that starts just ABOVE the drop point and
# reaches ~300 px BELOW it (measured on 30 ghosts in recorded battles: ghosts
# more than ~60 px above the drop always survived). Planned a little smaller.
GUST_BAND = (-40, 280)
# Android's swipe command takes longer to start than the drag itself: a second
# drag within this time overlaps the first and one of them is lost.
MIN_CAST_GAP = 0.45
HERO_POS = (150, 520)       # where Flame Lance's beam starts (the hero, left of the wall)
FIELD_CENTER = (1150, 520)
# Light beams stay on the ground for a moment and light ghosts are fast, so
# Genesis goes further in front of the front ghost: they walk into it.
# Genesis stays on the ground ~2 s, so it's a wall: put it in front of the
# FRONT ghost and the whole group walks into it (aiming at a back column lets
# the front ghosts slip past).
EXTRA_LEAD = {"genesis": 120}
WALL_SPELLS = {"genesis"}
# Screen clears have long cooldowns (>10 s): don't spend one on a small group
# unless a ghost is close to the wall or it's the only spell for that colour.
SAVE_FIELD_FOR = 4
# Waves walk in a column at a time (~0.3-0.6 s apart). Wait until no new ghost
# of that colour has walked in for WAVE_SETTLE s so one spell gets the whole
# wave -- but never once a ghost is less than DANGER_S from the wall.
WALL_X = 440                # a ghost reaching this x = loss
SPAWN_ZONE_X = 1450         # a ghost first seen right of this is a new arrival
WAVE_SETTLE = 0.6
MAX_WAVE_WAIT = 2.0
DANGER_S = 2.2              # seconds-to-wall below which we cast at once
# Only 1-2 ghosts and lots of time: the rest of the wave is usually still coming.
SMALL_GROUP = 2
SMALL_GROUP_WAIT_S = 3.5    # ...so wait until they're this close (s to wall)
# Mana refills ~14/s. If a spell that hits more ghosts is only short on mana
# and will be affordable well before the ghosts arrive, wait for it.
MANA_REGEN = 14.0
AFFORD_MARGIN_S = 1.2       # must be affordable this long before the ghost reaches the wall
MIN_DANGER_SPEED = 200      # speed readings are noisy while a wave walks in: never assume slower
HOLD_S = 1.5                # big group: save mana for the screen clear until this close (s to wall)


class GhostFighter:
    def __init__(self, device, vision, log):
        self.dev = device
        self.vis = vision
        self.log = log
        self.rec = BattleRecorder()
        self.casts = CastLog()
        self.reset()

    def reset(self):
        self.slots = None
        self.slot_names = None
        self.frame_t = time.monotonic()
        self.last_bar_save = 0.0
        self.first_seen = {}
        self.last_cast_any = -99.0
        self.mana = 100
        self.last_new = {}          # element -> when a new ghost of it last walked in
        self.prev_ghosts, self.prev_t = [], None
        self.speed = {}             # element -> (vx, vy) in px/s, smoothed
        self.tracks = []            # ghosts followed across frames (keeps their colour stable)
        self.last_seen = {}
        self.last_cast_element = {}
        self.slot_busy_until = {}
        self.missing_logged = set()
        self.shots = 0
        self.last_bar = None

    # -- spell bar -----------------------------------------------------------
    def _read_bar(self, img, now):
        """Which spell is in each slot, and which slots can be cast right now.
        Uses the exact hot-bar templates: a slot is usable only when its icon
        matches a READY template (not cooldown, not the blue no-mana tint).
        Names are remembered per slot, since cooldown frames can't be named."""
        if self.slots is None:
            self.slots = self.vis.bar_slots()
            self.slot_names = [None] * len(self.slots)
        bar = self.vis.read_bar(img)
        self.last_bar = bar
        changed = False
        for i, s in enumerate(bar):
            if s["name"] and s["name"] != self.slot_names[i]:
                self.slot_names[i] = s["name"]
                changed = True
        if changed:
            self.log("Spell bar: " + ", ".join(n or "?" for n in self.slot_names))
        return [i for i, s in enumerate(bar)
                if s["state"] == "ready" and s["name"] and now >= self.slot_busy_until.get(i, 0)]

    def _save_bar(self, img, now):
        if now - self.last_bar_save < BAR_SAVE_EVERY:
            return
        self.last_bar_save = now
        try:
            os.makedirs(BAR_DIR, exist_ok=True)
            name = time.strftime("%H%M%S") + f"_{int(now * 10) % 10}.png"
            cv2.imwrite(os.path.join(BAR_DIR, name), img[920:1080, 500:1420])
            files = sorted(os.listdir(BAR_DIR))
            for old in files[:-400]:
                os.remove(os.path.join(BAR_DIR, old))
        except OSError:
            pass

    # -- targeting ---------------------------------------------------------
    @staticmethod
    def _hits(shape, target, ghosts, reach=None):
        tx, ty = target["x"], target["y"]
        if shape == "field":
            return len(ghosts)
        r = reach or DEFAULT_REACH.get(shape, 200)
        if shape == "vline":
            return sum(1 for g in ghosts if abs(g["x"] - tx) <= r)
        if shape == "hline":
            lo, hi = GUST_BAND
            return sum(1 for g in ghosts if lo <= g["y"] - ty <= hi)
        if shape == "ray":
            hx, hy = HERO_POS
            dx, dy = tx - hx, ty - hy
            norm = (dx * dx + dy * dy) ** 0.5 or 1.0
            return sum(1 for g in ghosts if g["x"] > hx and abs((g["x"] - hx) * dy - (g["y"] - hy) * dx) / norm <= r)
        if shape == "cross":
            k = CROSS_SLOPE
            norm = (1 + k * k) ** 0.5
            return sum(1 for g in ghosts
                       if min(abs((g["y"] - ty) - k * (g["x"] - tx)), abs((g["y"] - ty) + k * (g["x"] - tx))) / norm <= r)
        return sum(1 for g in ghosts if (g["x"] - tx) ** 2 + (g["y"] - ty) ** 2 <= r ** 2)

    SPOT_MARGIN = 0.85      # plan with 85% of the spell's size so edge ghosts aren't just grazed

    def _best_spot(self, shape, ghosts, reach, front):
        """Where to centre a spell so it covers the most ghosts. Tries every
        ghost, the midpoint of every nearby pair and the centre of every
        cluster -- the best spot for a group is usually BETWEEN ghosts, not on
        one. Ties go to the most central spot. Once a ghost is close to the
        wall, the spot must cover it."""
        r = reach * self.SPOT_MARGIN
        must_cover = front if front["x"] < FRONT_DANGER_X else None
        cands = [dict(x=g["x"], y=g["y"]) for g in ghosts]
        if shape == "hline":
            lo, hi = GUST_BAND
            for g in ghosts:
                cands.append(dict(x=g["x"], y=g["y"] - lo - 10))     # g just inside the top of the band
                cands.append(dict(x=g["x"], y=g["y"] - hi + 10))     # g just inside the bottom
        for i, a in enumerate(ghosts):
            near = [b for b in ghosts if abs(b["x"] - a["x"]) <= 2 * reach and abs(b["y"] - a["y"]) <= 2 * reach]
            if len(near) > 1:
                cands.append(dict(x=sum(b["x"] for b in near) / len(near), y=sum(b["y"] for b in near) / len(near)))
            for b in ghosts[i + 1:]:
                if abs(b["x"] - a["x"]) <= 2 * reach and abs(b["y"] - a["y"]) <= 2 * reach:
                    cands.append(dict(x=(a["x"] + b["x"]) / 2, y=(a["y"] + b["y"]) / 2))
        best, best_key = None, None
        for c in cands:
            if must_cover is not None and not self._covers(shape, c, must_cover, r):
                continue
            covered = [g for g in ghosts if self._covers(shape, c, g, r)]
            if not covered:
                continue
            spread = sum(abs(g["x"] - c["x"]) + abs(g["y"] - c["y"]) for g in covered) / len(covered)
            key = (len(covered), -spread, -c["x"])
            if best_key is None or key > best_key:
                best, best_key = c, key
        if best is None:
            return front
        return {"x": int(best["x"]), "y": int(best["y"])}

    def _covers(self, shape, spot, ghost, reach):
        """Would a spell aimed at `spot` also hit `ghost`?"""
        return self._hits(shape, spot, [ghost], reach) == 1

    def _score(self, i, ghosts, target):
        """How good slot i is against this group: (score, shape, where to aim).
        Score = (not wasting a screen clear, ghosts hit, cheaper)."""
        name = self.slot_names[i]
        _, shape, cost = SPELLS[name]
        reach = SPELL_REACH.get(name)
        tgt = target
        if name in WALL_SPELLS:
            tgt = target
        elif shape == "cross":
            # Deuteronomy's X is centred where it's dropped and stays put: aim it at
            # the middle of the group (ghosts walk into it), not at the front ghost.
            tgt = {"x": int(sum(g["x"] for g in ghosts) / len(ghosts)),
                   "y": int(sum(g["y"] for g in ghosts) / len(ghosts))}
        elif shape != "field":
            tgt = self._best_spot(shape, ghosts, reach or DEFAULT_REACH.get(shape, 200), target)
        if shape == "cross" or name in WALL_SPELLS:
            hits = len(ghosts)
        else:
            hits = self._hits(shape, tgt, ghosts, reach)
        # field spell on a small, far group = last resort (keeps it for big waves)
        spare = not (shape == "field" and len(ghosts) < SAVE_FIELD_FOR and target["x"] >= FRONT_DANGER_X)
        return (spare, hits, -cost), shape, tgt

    def _pick(self, element, ghosts, usable):
        """Best usable slot for this colour: whichever hits the most ghosts (one
        cast for a whole group beats two), then the CHEAPEST -- screen clears
        are saved for groups the small spells can't handle. Unaffordable spells are already
        excluded (their icon has the blue no-mana tint)."""
        target = min(ghosts, key=lambda g: g["x"])
        best = None
        for i in usable:
            if SPELLS[self.slot_names[i]][0] != element:
                continue
            score, shape, tgt = self._score(i, ghosts, target)
            if best is None or score > best[0]:
                best = (score, i, shape, tgt)
        if best is None:
            return None, target
        score, i, shape, tgt = best
        return (score, i, shape), tgt

    def _better_soon(self, element, ghosts, best_score, to_wall):
        """A spell of this colour that would hit MORE ghosts but is only short on
        mana (cooldown done), and will be affordable in time: (name, seconds)."""
        target = min(ghosts, key=lambda g: g["x"])
        found = None
        for i, s in enumerate(self.last_bar or []):
            name = self.slot_names[i] if self.slot_names else None
            if not name or s["state"] != "nomana" or SPELLS[name][0] != element:
                continue
            score, _, _ = self._score(i, ghosts, target)
            if best_score is not None and (score[1] <= best_score[1] or score <= best_score):
                continue
            wait = max(0.0, (SPELLS[name][2] - self.mana) / MANA_REGEN) + 0.2
            if wait < to_wall - AFFORD_MARGIN_S and (found is None or wait < found[1]):
                found = (name, wait)
        return found

    # -- aiming --------------------------------------------------------------
    def _track(self, ghosts, now):
        """Measure how fast each colour of ghost is moving: every followed ghost's
        own movement over the last SPEED_WINDOW s, median per colour. (Matching
        frame-to-frame by distance mixed up neighbours in tight waves.)"""
        moves = {}
        for t in self.tracks:
            hist = t.get("hist", [])
            if t["t"] != now or len(hist) < 3 or hist[-1][0] - hist[0][0] < 0.25:
                continue
            (t0, x0, y0), (t1, x1, y1) = hist[0], hist[-1]
            el = max(t["votes"], key=t["votes"].get)
            moves.setdefault(el, []).append(((x1 - x0) / (t1 - t0), (y1 - y0) / (t1 - t0)))
        for el, mv in moves.items():
            vx = sorted(m[0] for m in mv)[len(mv) // 2]
            vy = sorted(m[1] for m in mv)[len(mv) // 2]
            old = self.speed.get(el)
            self.speed[el] = (vx, vy) if old is None else (0.5 * old[0] + 0.5 * vx, 0.5 * old[1] + 0.5 * vy)

    def _stabilize(self, ghosts, now):
        """Follow each ghost across frames. A ghost keeps the colour it was seen
        as most often, so a light ghost tinted red by a fire explosion (or
        flashed white) stays "light". Detections seen only once are ignored."""
        self.tracks = [t for t in self.tracks if now - t["t"] < TRACK_FORGET_S]
        used, out = set(), []
        for g in sorted(ghosts, key=lambda g: g["x"]):
            best, bd = None, TRACK_MATCH_PX
            for i, t in enumerate(self.tracks):
                d = max(abs(t["x"] - g["x"]), abs(t["y"] - g["y"]))
                if i not in used and d < bd:
                    best, bd = i, d
            if best is None:
                t = {"votes": {}, "frames": 0, "t0": now, "x0": g["x"]}
                self.tracks.append(t)
                best = len(self.tracks) - 1
            used.add(best)
            t = self.tracks[best]
            t.update(x=g["x"], y=g["y"], t=now)
            hist = t.setdefault("hist", [])
            hist.append((now, g["x"], g["y"]))
            while hist and now - hist[0][0] > SPEED_WINDOW:
                hist.pop(0)
            t["frames"] += 1
            t["votes"][g["element"]] = t["votes"].get(g["element"], 0) + 1
            if now - t.get("t0", now) > STILL_S and abs(g["x"] - t.get("x0", g["x"])) < STILL_PX:
                continue                       # not moving: not a ghost
            if t["frames"] >= MIN_TRACK_FRAMES:
                el = max(t["votes"], key=t["votes"].get)
                if t["frames"] == MIN_TRACK_FRAMES and g["x"] > SPAWN_ZONE_X:
                    self.last_new[el] = now
                out.append(dict(g, element=el))
        return out

    def _aim(self, element, target, shape="area", name=None):
        """Point just ahead of where the target will be when the spell lands:
        the frame's age (it was captured a moment ago) plus drag + landing.
        Column spells land almost instantly, so they get a much smaller lead."""
        vx, vy = self.speed.get(element, (-DEFAULT_SPEEDS.get(element, DEFAULT_SPEED), 0.0))
        base = VLINE_AHEAD_S if shape == "vline" else AIM_AHEAD_S
        ahead = base + max(0.0, min(0.5, time.monotonic() - self.frame_t))
        lead = max(MIN_LEAD, min(MAX_LEAD, -vx * ahead)) + EXTRA_LEAD.get(name, 0)
        drift = max(-60, min(60, vy * ahead))
        return max(420, int(target["x"] - lead)), int(target["y"] + drift), int(lead)

    # -- main --------------------------------------------------------------
    def step(self, img, frame_t=None):
        """Handle one frame of the ghost battle. Returns True if a spell was cast.
        frame_t = when the screenshot was taken (for tracking and aiming)."""
        if not self.rec.recording:
            self.rec.start()
            self.casts.reset()
        now = frame_t or time.monotonic()
        self.frame_t = now
        usable = self._read_bar(img, now)
        self.mana = self.vis.read_mana(img)
        # (hot-bar captures for building templates are done -- no longer saved)
        ghosts = self._stabilize(self.vis.find_ghosts(img), now)
        self._track(ghosts, now)
        statuses = {}       # element -> why the bot did / didn't cast (for the video)
        cast = self._decide(img, ghosts, usable, statuses)
        self.casts.frame(now, ghosts, any("NO SPELL" in s for s in statuses.values()))
        self.rec.frame(img, ghosts, self.last_bar, usable, self.slots, statuses, t=now)
        return cast

    def finish_recording(self, result):
        """End the battle video. result: "WIN", "LOSS" or "STOPPED"."""
        if self.rec.recording:
            self.casts.finish(result)
        return self.rec.finish(result)

    def _decide(self, img, ghosts, usable, statuses):
        by_element = {}
        for g in ghosts:
            by_element.setdefault(g["element"], []).append(g)
        now = time.monotonic()
        for el in by_element:
            if now - self.last_seen.get(el, -99) > NEW_WAVE_GAP:
                self.first_seen[el] = now
            self.last_seen[el] = now
        if not by_element:
            return False

        cast_done = False
        if now - self.last_cast_any < MIN_CAST_GAP:
            return False
        front_x = min(g["x"] for g in ghosts)
        # Most urgent colour first: the one closest to the wall.
        for element, group in sorted(by_element.items(), key=lambda kv: min(g["x"] for g in kv[1])):
            nearest = min(g["x"] for g in group)
            speed = self.speed.get(element)
            spd = f", {abs(speed[0]):.0f}px/s" if speed else ""
            head = f"{len(group)} ghost(s), nearest x={nearest}{spd} -> "
            if cast_done:
                statuses[element] = head + "next frame (one cast per frame)"
                continue
            front = nearest == front_x and nearest < FRONT_DANGER_X
            vx = speed[0] if speed else -DEFAULT_SPEEDS.get(element, DEFAULT_SPEED)
            to_wall = (nearest - WALL_X) / max(MIN_DANGER_SPEED, -vx)
            danger = front or to_wall < DANGER_S or nearest < URGENT_X
            waited = now - self.first_seen[element]
            settling = now - self.last_new.get(element, -99) < WAVE_SETTLE
            if not danger and waited < MAX_WAVE_WAIT and (waited < SPAWN_WAIT or settling):
                statuses[element] = head + f"waiting for wave ({to_wall:.1f}s to wall)"
                continue
            if not danger and len(group) <= SMALL_GROUP and to_wall > SMALL_GROUP_WAIT_S:
                statuses[element] = head + f"small group, waiting for the rest ({to_wall:.1f}s to wall)"
                continue
            since = now - self.last_cast_element.get(element, 0)
            if since < ELEMENT_RECAST_DELAY:
                statuses[element] = head + f"just cast, recast in {ELEMENT_RECAST_DELAY - since:.1f}s"
                continue
            best, target = self._pick(element, group, usable)
            soon = self._better_soon(element, group, best[0] if best else None, to_wall)
            if soon:
                statuses[element] = head + f"saving mana for {soon[0]} (affordable in {soon[1]:.1f}s, mana {self.mana})"
                continue
            if best is None:
                have = any(SPELLS[n][0] == element for n in self.slot_names if n)
                why = "on cooldown / no mana" if have else "not in the bar"
                statuses[element] = head + f"NO SPELL ({why})"
                if element not in self.missing_logged:
                    self.log(f"{element} ghosts but {element} spell {why}")
                    self.missing_logged.add(element)
                continue
            (_, hits, _), slot, shape = best
            if shape != "field" and len(group) >= SAVE_FIELD_FOR and to_wall > HOLD_S:
                # wait only for a screen clear that is short on MANA (not on cooldown)
                # and will be affordable well before the group gets close
                big = [n for i, n in enumerate(self.slot_names)
                       if n and SPELLS[n][0] == element and SPELLS[n][1] == "field"
                       and self.last_bar and self.last_bar[i]["state"] == "nomana"
                       and (SPELLS[n][2] - self.mana) / MANA_REGEN < to_wall - HOLD_S]
                if big:
                    statuses[element] = head + f"holding mana for {big[0]} (screen clear)"
                    continue
            lead = 0
            if shape == "field":
                dx, dy = FIELD_CENTER
            else:
                dx, dy, lead = self._aim(element, target, shape, self.slot_names[slot])
            sx, sy = ((self.slots[slot][0] + self.slots[slot][2]) // 2,
                      (self.slots[slot][1] + self.slots[slot][3]) // 2)
            time.sleep(humanize.ghost_pause())
            sx, sy = humanize.jitter(sx, sy, 14, 14)
            if shape != "field":
                dx, dy = humanize.jitter(dx, dy, 5, 8)   # small: keep the lead intact
            else:
                dx, dy = humanize.jitter(dx, dy, 120, 90)
            self.dev.swipe(sx, sy, dx, dy, humanize.drag_ms())
            self.last_cast_element[element] = now
            self.slot_busy_until[slot] = now + 0.8
            self.last_cast_any = now
            self.missing_logged.discard(element)
            name = self.slot_names[slot]
            aim = f", {lead}px ahead" if lead else ""
            self.log(f"{len(group)} {element} -> {name} (slot {slot + 1}, hits ~{hits}{aim})")
            statuses[element] = head + f"CAST {name} (hits ~{hits}{aim})"
            self.rec.note_cast((sx, sy), (dx, dy), name.replace("_", " "))
            self.casts.cast(now, ghosts, element, name, shape, (dx, dy), lead)
            self._save_shot(img, ghosts, slot, (dx, dy))
            cast_done = True
        return cast_done

    def _save_shot(self, img, ghosts, slot, drop):
        """Keep an annotated picture of every cast so misses can be diagnosed."""
        try:
            os.makedirs(SHOT_DIR, exist_ok=True)
            vis = img.copy()
            for g in ghosts:
                c = SHOT_COLORS.get(g["element"], (0, 255, 0))
                cv2.rectangle(vis, (g["x0"], g["y0"]), (g["x1"], g["y1"]), c, 3)
                cv2.putText(vis, g["element"], (g["x0"], g["y0"] - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.8, c, 2)
            x0, y0, x1, y1 = self.slots[slot]
            cv2.rectangle(vis, (x0, y0), (x1, y1), (0, 255, 0), 4)
            cv2.drawMarker(vis, drop, (0, 255, 0), cv2.MARKER_CROSS, 40, 4)
            self.shots += 1
            name = f"{time.strftime('%H%M%S')}_{self.shots:03d}.jpg"
            cv2.imwrite(os.path.join(SHOT_DIR, name), cv2.resize(vis, (960, 540)))
            files = sorted(os.listdir(SHOT_DIR))
            for old in files[:-150]:
                os.remove(os.path.join(SHOT_DIR, old))
        except OSError:
            pass
