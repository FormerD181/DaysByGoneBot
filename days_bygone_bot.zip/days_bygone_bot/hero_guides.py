"""Pulls teams, synergies and guides out of the Book of Heroes posts
(assets/heroes/*.json) so the Heroes tool can show them by topic.

Everything is the posts' own text -- nothing is rewritten, only sorted:
  teams(heroes)     -> {mode: [(hero, text), ...]}   "HERO TEAM" sections split by game mode
  synergies(heroes) -> {hero_key: Counter(partner_key)} heroes put on the same team line
  guides(heroes)    -> [(category, title, hero, text), ...]  how-to / mechanics sections
"""
import re
from collections import Counter, defaultdict

HEADING = re.compile(r"^(#{1,3}) (.*)")
EMOJI = re.compile(r":([A-Za-z0-9_]+):")

# Game modes, in the order they're shown. Keys are words looked for in headings.
MODES = [("Campaign", ["CAMPAIGN", "PUSHING", "REWIND"]),
         ("Expedition", ["EXPEDITION"]),
         ("Cyber", ["CYBER"]),
         ("Vermilion", ["VERMILION", "VERMILLION"]),
         ("Voidmaw", ["VOIDMAW"]),
         ("Void", ["VOID"]),
         ("Dungeon", ["DUNGEON"]),
         ("Hunt", ["HUNT"]),
         ("Idle", ["IDLE"])]
ALL_MODES = "All modes"
GENERAL = "General teams"
MODE_ORDER = [ALL_MODES] + [m for m, _ in MODES] + [GENERAL]

# Guide categories: (category, regex on the heading)
GUIDE_KINDS = [
    ("Evolutions", re.compile(r"HOW TO EVOLVE|EVOLUTION QUEST|PURCHASE REQUIREMENTS")),
    ("Unlocking heroes", re.compile(r"HOW (TO|DO I) SUMMON|WHEN SHOULD YOU GET")),
    ("How heroes work", re.compile(r"HOW DOES|HOW DO HIS|WHAT IS|HOW IT WORKS|STACKS|DAYS OF DAMAGE|"
                                   r"COMPARISION|COMPARISON|MULTI-STRIKE|EXPOSE|MARK HEROES")),
    ("Going to 15 stars", re.compile(r"CONSIDERING 15|GOOD AT 15|BEFORE 15")),
    ("Which hero to use", re.compile(r"SHOULD I USE")),
]


def _plain(heading):
    """Heading text without emojis/markdown, upper-case."""
    t = EMOJI.sub("", heading)
    t = re.sub(r"[*_`]", "", t)
    return re.sub(r"\s+", " ", t).strip().upper()


def _lines(hero):
    out = []
    for m in hero["messages"]:
        if m["txt"]:
            out += m["txt"].split("\n")
    return out


def _sections(hero):
    """[(level, heading_text, [body lines])] in post order; body = lines up to
    the next heading of any level."""
    secs = []
    cur = (0, "", [])
    for line in _lines(hero):
        mm = HEADING.match(line)
        if mm:
            secs.append(cur)
            cur = (len(mm.group(1)), mm.group(2), [])
        else:
            cur[2].append(line)
    secs.append(cur)
    return [s for s in secs if s[1] or any(l.strip() for l in s[2])]


def _modes_in(heading):
    h = _plain(heading)
    if "ANY GAMEMODE" in h or "ALL MODES" in h or "ANY GAME MODE" in h:
        return [ALL_MODES]
    found = []
    words = set(re.split(r"[^A-Z]+", h))
    for mode, keys in MODES:
        if any(k in words for k in keys):
            found.append(mode)
    return found


def _block(secs, start):
    """Text of section `start` plus every deeper heading under it."""
    lvl = secs[start][0]
    lines = list(secs[start][2])
    for lv, head, body in secs[start + 1:]:
        if lv <= lvl:
            break
        lines.append("#" * lv + " " + head)
        lines += body
    return "\n".join(lines).strip("\n")


def teams(heroes):
    """{mode: [(hero, text)]} from each post's HERO TEAM part."""
    out = defaultdict(list)
    for h in heroes:
        secs = _sections(h)
        in_team, team_lvl = False, 0
        cur_modes, buf = None, []

        def flush():
            text = "\n".join(buf).strip("\n")
            if text and any(EMOJI.search(l) for l in buf):
                for m in (cur_modes or [GENERAL]):
                    out[m].append((h, text))

        for lv, head, body in secs:
            p = _plain(head)
            if "HERO TEAM" in p or "HERO/MAGE TEAM" in p or p == "TEAMS":
                flush()
                in_team, team_lvl, cur_modes, buf = True, lv, None, list(body)
                continue
            if not in_team:
                continue
            modes = _modes_in(head)
            if modes:
                flush()
                cur_modes, buf = modes, list(body)
                continue
            if lv <= team_lvl and lv == 1 and not modes:
                # a new top-level topic (ARTIFACT, IS X GOOD?...) ends the team part
                flush()
                in_team, cur_modes, buf = False, None, []
                continue
            buf.append("#" * lv + " " + head)
            buf += body
        if in_team:
            flush()
    return {m: out[m] for m in MODE_ORDER if out.get(m)}


def _hero_key(emoji):
    """Hero_Saul -> 'saul' (lower-case, so Hero_paul and Hero_Paul match)."""
    return emoji[5:].lower() if emoji.lower().startswith("hero_") else None


def synergies(heroes):
    """{hero_key: Counter(partner_key: times on the same team line)} plus the
    lines themselves: (counts, lines_by_pair)."""
    counts = defaultdict(Counter)
    lines = defaultdict(list)
    seen = set()
    for mode, entries in teams(heroes).items():
        for h, text in entries:
            for line in text.split("\n"):
                if line.startswith("#"):
                    continue
                keys = []
                for e in EMOJI.findall(line):
                    k = _hero_key(e)
                    if k and k not in keys:
                        keys.append(k)
                # a team line is mostly heroes + slot dots, not a sentence
                words = len(EMOJI.sub("", line).split())
                if len(keys) < 2 or words > 8:
                    continue
                if (h["name"], line) in seen:
                    continue
                seen.add((h["name"], line))
                for a in keys:
                    for b in keys:
                        if a != b:
                            counts[a][b] += 1
                            lines[a].append((mode, h, line))
    return counts, lines


def guides(heroes):
    """[(category, title, hero, text)] -- how-to and mechanics sections."""
    out = []
    for h in heroes:
        secs = _sections(h)
        taken = set()
        for i, (lv, head, body) in enumerate(secs):
            if i in taken or not head:
                continue
            p = _plain(head)
            for cat, rx in GUIDE_KINDS:
                if rx.search(p):
                    text = _block(secs, i)
                    # skip headings that are only a label for the next one
                    if len(text) < 15:
                        break
                    title = EMOJI.sub("", head).replace("*", "").strip(" ?:") or p.title()
                    out.append((cat, title, h, text))
                    for j in range(i + 1, len(secs)):
                        if secs[j][0] <= lv:
                            break
                        taken.add(j)
                    break
    order = {c: n for n, (c, _) in enumerate(GUIDE_KINDS)}
    out.sort(key=lambda g: (order[g[0]], g[2]["name"]))
    return out


def portrait_key(hero):
    """Lower-case hero key from the post's portrait emoji (Hero_Saul -> 'saul')."""
    return _hero_key(hero.get("portrait") or "") or ""
