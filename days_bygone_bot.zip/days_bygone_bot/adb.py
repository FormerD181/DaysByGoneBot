"""Thin ADB wrapper: fast raw screenshots + a persistent shell for input."""
import gzip
import os
import subprocess
import threading
import time

import numpy as np

ADB_CANDIDATES = [
    r"C:\Program Files\BlueStacks_nxt\HD-Adb.exe",
    "adb",
]
DEFAULT_SERIAL = "127.0.0.1:5555"

# Hide the console window that subprocess would otherwise flash on Windows.
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def find_adb():
    for path in ADB_CANDIDATES:
        if os.path.isabs(path) and os.path.exists(path):
            return path
    return ADB_CANDIDATES[-1]


class Device:
    def __init__(self, serial=DEFAULT_SERIAL, adb_path=None):
        self.adb = adb_path or find_adb()
        self.serial = serial
        self._shell = None
        self._lock = threading.Lock()

    # -- plumbing ---------------------------------------------------------
    def _run(self, *args, timeout=10):
        return subprocess.run(
            [self.adb, "-s", self.serial, *args],
            capture_output=True, timeout=timeout, creationflags=_NO_WINDOW,
        )

    def connect(self):
        subprocess.run([self.adb, "connect", self.serial], capture_output=True,
                       timeout=10, creationflags=_NO_WINDOW)
        out = self._run("get-state").stdout.decode().strip()
        if out != "device":
            raise RuntimeError(f"ADB device {self.serial} not ready (state={out!r}). Is BlueStacks running?")

    def _ensure_shell(self):
        if self._shell is None or self._shell.poll() is not None:
            self._shell = subprocess.Popen(
                [self.adb, "-s", self.serial, "shell"],
                stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=_NO_WINDOW,
            )
        return self._shell

    def _send(self, cmd):
        with self._lock:
            sh = self._ensure_shell()
            try:
                sh.stdin.write((cmd + "\n").encode())
                sh.stdin.flush()
            except OSError:
                self._shell = None
                sh = self._ensure_shell()
                sh.stdin.write((cmd + "\n").encode())
                sh.stdin.flush()

    # -- public API -------------------------------------------------------
    def screenshot(self):
        """Return the screen as a BGR numpy array (raw capture, no PNG encode)."""
        return self._decode(self._run("exec-out", "screencap", timeout=10).stdout)

    def screenshot_fast(self):
        """Same, but compressed inside the emulator first: ~8x less data to
        send, so it's quicker and several can run side by side."""
        packed = self._run("exec-out", "screencap | gzip -1", timeout=10).stdout
        return self._decode(gzip.decompress(packed))

    @staticmethod
    def _decode(raw):
        if len(raw) < 16:
            raise RuntimeError("screencap returned no data")
        w = int.from_bytes(raw[0:4], "little")
        h = int.from_bytes(raw[4:8], "little")
        header = len(raw) - w * h * 4  # 12 bytes on Android <= 8, 16 on newer
        rgba = np.frombuffer(raw, dtype=np.uint8, offset=header, count=w * h * 4).reshape(h, w, 4)
        return np.ascontiguousarray(rgba[:, :, 2::-1])  # RGBA -> BGR

    def tap(self, x, y):
        self._send(f"input tap {int(x)} {int(y)} &")

    def swipe(self, x1, y1, x2, y2, ms=120):
        self._send(f"input swipe {int(x1)} {int(y1)} {int(x2)} {int(y2)} {int(ms)} &")

    def close(self):
        if self._shell and self._shell.poll() is None:
            try:
                self._shell.stdin.write(b"exit\n")
                self._shell.stdin.flush()
            except OSError:
                pass
            self._shell.terminate()
        self._shell = None


class FastCapture:
    """Keeps several compressed screenshots in flight at once (~14 fps with 3
    workers instead of ~4 fps). Used only during ghost battles."""

    def __init__(self, device, workers=3):
        self.dev = device
        self.workers = workers
        self.lock = threading.Condition()
        self.frame = None          # (capture start time, image)
        self.running = False
        self.avg = 0.3             # average seconds per capture (measured)
        self.last_start = 0.0

    def start(self):
        if self.running:
            return
        self.running = True
        self.frame = None
        for _ in range(self.workers):
            threading.Thread(target=self._work, daemon=True).start()

    def stop(self):
        self.running = False

    def _work(self):
        while self.running:
            # Stagger the workers so frames arrive evenly, not in bunches.
            with self.lock:
                t = max(time.monotonic(), self.last_start + self.avg / self.workers)
                self.last_start = t
            time.sleep(max(0.0, t - time.monotonic()))
            try:
                img = self.dev.screenshot_fast()
            except Exception:  # noqa: BLE001 - keep the other workers going
                time.sleep(0.2)
                continue
            with self.lock:
                self.avg = 0.8 * self.avg + 0.2 * (time.monotonic() - t)
                # workers finish out of order: only keep the newest capture
                if self.frame is None or t > self.frame[0]:
                    self.frame = (t, img)
                    self.lock.notify_all()

    def next(self, after, timeout=1.0):
        """Newest frame captured after time `after`: (time, image) or None."""
        with self.lock:
            self.lock.wait_for(lambda: self.frame is not None and self.frame[0] > after, timeout)
            return self.frame if self.frame and self.frame[0] > after else None
