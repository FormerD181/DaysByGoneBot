"""Bot version. Bump this every time the zip is repacked."""
VERSION = "1.7"

# Where the bot looks for updates (the release repo's latest.json, raw file link).
UPDATE_URL = "https://raw.githubusercontent.com/FormerD181/DaysByGoneBot/main/latest.json"
