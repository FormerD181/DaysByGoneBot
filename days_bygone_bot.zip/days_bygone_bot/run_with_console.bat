@echo off
cd /d "%~dp0"
python ui.py
if errorlevel 1 pause
