"""Day Guide, shown in the right-hand panel: pick your day, read the guide's
advice for it.

Text is the "Updated Days Bygone Guide" (Gala, Evl and many more, built on
Mundus' guide), stored word for word in assets/guide.json.
"""
import json
import os
import tkinter as tk
from tkinter import ttk

from widgets import ACCENT, LOG_BG, MUTED, PILL, TEXT

HERE = os.path.dirname(os.path.abspath(__file__))
GUIDE = os.path.join(HERE, "assets", "guide.json")
BG = "#121216"
FIELD_BG = "#26262d"


def load_guide():
    with open(GUIDE, encoding="utf-8") as f:
        return json.load(f)


def section_for_day(guide, day):
    for s in guide["sections"]:
        if s["start"] <= day <= s["end"]:
            return s
    return guide["sections"][0] if day < guide["sections"][0]["start"] else guide["sections"][-1]


def _range(s):
    return f"Day {s['start']:,}+" if s["end"] > 10 ** 8 else f"Days {s['start']:,}-{s['end']:,}"


def _button(parent, text, cmd, primary=False):
    return tk.Button(parent, text=text, command=cmd, relief="flat", cursor="hand2", padx=8, pady=3,
                     font=("Segoe UI", 9, "bold" if primary else "normal"),
                     bg=ACCENT if primary else PILL, fg="#111111" if primary else TEXT,
                     activebackground="#ffd84d" if primary else "#3a3a43",
                     activeforeground="#111111" if primary else TEXT)


class GuidePanel:
    def __init__(self, parent, settings, save, read_day=None):
        self.guide = load_guide()
        self.settings = settings
        self.save = save
        self.read_day = read_day
        f = self.frame = tk.Frame(parent, bg=BG)
        f.pack(fill="both", expand=True)

        top = tk.Frame(f, bg=BG)
        top.pack(fill="x")
        tk.Label(top, text="Day", bg=BG, fg=TEXT, font=("Segoe UI", 10, "bold")).pack(side="left")
        self.day = tk.StringVar(value=str(settings.get("guide_day", "")))
        e = tk.Entry(top, textvariable=self.day, width=8, bg=FIELD_BG, fg=TEXT, insertbackground=TEXT,
                     relief="flat", font=("Segoe UI", 10))
        e.pack(side="left", padx=6, ipady=2)
        e.bind("<Return>", lambda ev: self.show_day())
        _button(top, "Show", self.show_day, primary=True).pack(side="left")
        self.read_btn = _button(top, "Read from game", self.read_game)
        if read_day:
            self.read_btn.pack(side="left", padx=6)

        self.section_names = ["Before you start"] + [f"{_range(s)}  ·  {s['title']}" for s in self.guide["sections"]]
        self.pick = ttk.Combobox(f, values=self.section_names, state="readonly")
        self.pick.pack(fill="x", pady=(8, 4))
        self.pick.bind("<<ComboboxSelected>>", lambda ev: self.show_index(self.pick.current()))
        self.topic = ttk.Combobox(f, state="readonly")
        self.topic.pack(fill="x", pady=(0, 6))
        self.topic.bind("<<ComboboxSelected>>", self.jump)

        box = tk.Frame(f, bg=BG)
        box.pack(fill="both", expand=True)
        self.text = tk.Text(box, bg=LOG_BG, fg="#dcdce2", relief="flat", wrap="word", padx=10, pady=8,
                            font=("Segoe UI", 10), spacing1=1, spacing3=5, cursor="arrow")
        sb = tk.Scrollbar(box, command=self.text.yview)
        self.text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.text.pack(fill="both", expand=True)
        self.text.tag_configure("title", foreground=ACCENT, font=("Segoe UI", 12, "bold"), spacing3=1)
        self.text.tag_configure("range", foreground=MUTED, font=("Segoe UI", 8))
        self.text.tag_configure("h", foreground=ACCENT, font=("Segoe UI", 10, "bold"), spacing1=10)
        self.text.tag_configure("li", lmargin1=10, lmargin2=22)
        self.text.tag_configure("muted", foreground=MUTED, font=("Segoe UI", 9))
        tk.Label(f, text="Guide by Gala, Evl & the community (built on Mundus' guide)", bg=BG, fg=MUTED,
                 font=("Segoe UI", 7)).pack(anchor="w", pady=(4, 0))

        if self.day.get().strip().isdigit():
            self.show_day()
        else:
            self.show_index(0)

    # -- showing -------------------------------------------------------------
    def show_day(self):
        txt = self.day.get().strip().replace(",", "")
        if not txt.isdigit():
            self.show_index(0)
            return
        day = int(txt)
        self.settings["guide_day"] = day
        self.save(self.settings)
        self.show_section(section_for_day(self.guide, day), note=f"tips for day {day:,}")

    def show_index(self, i):
        self.show_section(self.guide["general"] if i <= 0 else self.guide["sections"][i - 1], note="")

    def show_section(self, s, note):
        is_general = s is self.guide["general"]
        self.pick.current(0 if is_general else self.guide["sections"].index(s) + 1)
        t = self.text
        t.configure(state="normal")
        t.delete("1.0", "end")
        t.insert("end", s["title"] + "\n", "title")
        if not is_general:
            t.insert("end", _range(s) + (f"  ·  {note}" if note else "") + "\n", "range")
        self.marks = [("Jump to topic...", "1.0")]
        for kind, line in s["blocks"]:
            if kind == "h":
                self.marks.append((line, t.index("end-1c")))
                t.insert("end", line + "\n", "h")
            elif kind == "li":
                t.insert("end", "•  " + line + "\n", "li")
            else:
                t.insert("end", line + "\n")
        t.configure(state="disabled")
        t.yview_moveto(0)
        self.topic["values"] = [m[0] for m in self.marks]
        self.topic.current(0)
        self.topic.configure(state="readonly" if len(self.marks) > 1 else "disabled")

    def jump(self, _ev):
        i = self.topic.current()
        if i >= 0:
            self.text.yview(self.marks[i][1])

    # -- read from game ----------------------------------------------------------
    def read_game(self):
        self.read_btn.config(state="disabled", text="Reading...")
        self.read_day(self)

    def apply_day(self, day, error=None):
        self.read_btn.config(state="normal", text="Read from game")
        if error or day is None:
            self.text.configure(state="normal")
            self.text.delete("1.0", "end")
            self.text.insert("end", f"{error or 'Could not read the day -- type it in.'}\n", "muted")
            self.text.configure(state="disabled")
            return
        self.day.set(str(day))
        self.show_day()
