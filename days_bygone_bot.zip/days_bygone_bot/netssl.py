"""HTTPS for phone alerts and updates.

Windows' own certificate list can lag behind: when a site switches to a new
certificate chain (ntfy.sh did in Oct 2026), Python reports "certificate has
expired". So the bot carries an up-to-date list (assets/cacert.pem, from the
certifi package) and tries that first, then Windows' list.
"""
import os
import ssl
import urllib.error
import urllib.request

BUNDLE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "cacert.pem")
_contexts = None


def _all_contexts():
    global _contexts
    if _contexts is None:
        _contexts = []
        try:
            import certifi                      # newest list, if it's installed
            _contexts.append(ssl.create_default_context(cafile=certifi.where()))
        except Exception:  # noqa: BLE001
            pass
        if os.path.exists(BUNDLE):
            _contexts.append(ssl.create_default_context(cafile=BUNDLE))
        _contexts.append(ssl.create_default_context())      # Windows' list
    return _contexts


def urlopen(req, timeout):
    """urllib.request.urlopen that retries with the next certificate list on a
    certificate error. Never turns certificate checking off."""
    err = None
    for ctx in _all_contexts():
        try:
            return urllib.request.urlopen(req, timeout=timeout, context=ctx)
        except urllib.error.URLError as e:
            if not isinstance(getattr(e, "reason", None), ssl.SSLCertVerificationError):
                raise
            err = e
    raise err
