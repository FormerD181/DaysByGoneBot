# Days Bygone Bot

Plays Days Bygone in BlueStacks (1920x1080) over ADB.

## Version
The current version shows in the window title and top-right of the bot panel
(set in `version.py`). Zips are named `days_bygone_bot_vX.Y.zip`.

- **v1.4** – World Tree planner finds the exact best build (checks every
  combination) and shows the next 5 apples with changes marked; Read from game
  also reads Starforce + 15-star heroes, and Health/Mana from the Stats screen.
  Ghost battle loss counters (streak, longest, total).
- **v1.3** – World Tree planner (port of the community Worldtree Calc): best
  builds for your apples; "Read from game" fills in apples, Elixir Mastery,
  Starforce, 15-star heroes, Health and Mana. World Tree / Settings / Journal no longer trigger the
  human-check alarm.
- **v1.2** – Update button: the bot checks GitHub on launch and can install
  new versions itself (keeps your settings and progress).
- **v1.1** – ghost battles: ~10-14 screenshots/s instead of ~4 (compressed,
  staggered captures), aiming accounts for screenshot age, front ghost first.
- **v1.0** – version numbers; spells on cooldown are now identified (no more "?");
  bot holds mana for the screen-clearing spell of a colour when ghosts are still far.

## Setup (first time)
1. Install Python 3.11+ (python.org -- tick "Add Python to PATH").
2. In a terminal run: `pip install opencv-python numpy pillow`
3. BlueStacks 5: resolution 1920x1080, Settings -> Advanced -> turn on
   Android Debug Bridge. The bot connects on port 5555 (change
   `DEFAULT_SERIAL` in `adb.py` if yours differs).
4. Open Days Bygone (English), then double-click `Days Bygone Bot.vbs`.

## Loop
1. Battle → Campaign → **X2** → push to max day. If the Campaign tile already
   shows just "DAY N" (max day), it closes the menu and skips to step 2.
2. VICTORY → red back → buy the chosen stat (Damage / Gold / Critical Damage).
3. World Tree → Rewind button:
   - **Medallion** (every 5th rewind) → OK → ghost battle (drag the matching
     spell onto each ghost; red=fire, yellow=light, purple=lightning,
     blue=ice, white=wind) → VICTORY red back → back to the tree.
     On DEFEAT it presses green retry.
   - **Elixir button** (+elixir) → green Rewind.
4. If "Spend elixir on Elixir Mastery" is ticked: Elixir Mastery → OK.
5. Stats → buy the chosen stat again → back to step 1.

## Run
Double-click **`Days Bygone Bot.vbs`** (no console window). `run_with_console.bat` does the same but shows a console, handy if something breaks. Pick the stat, the Elixir Mastery toggle and where to start, then press **START**.
You can change the stat while it runs. **Stop** halts it at any time.

When the bot sees a screen it doesn't know it waits and saves a screenshot to `debug/`.
You can click through it yourself and the bot picks back up.

## Files
- `ui.py` – control window (background: `assets/background.png`)
- `bot.py` – state machine
- `ghost.py` – ghost battle logic
- `vision.py` – screen / spell / ghost recognition
- `adb.py` – screenshots + taps via BlueStacks' `HD-Adb.exe`
- `templates/` – image snippets the bot matches against (`templates/bar/` = exact spell icons, ready + no-mana)
- `samples/` – reference screenshots used to tune detection

## Human checks
The game sometimes shows a "Select the ___" / "Tap the ___" / "Tap! xN" check.
The bot never answers these. When the menu is darkened with no OK button it
stops, plays the alarm for 3 seconds, flashes the window and saves a screenshot
to `debug/`. Answer the check yourself, then press START to continue where it
left off. Pick your own alarm (.wav/.mp3/.wma) under "Human check alarm".
