"""Small random variations so the bot doesn't click like a machine."""
import random

# Menu clicks: random pause before each click (seconds). Mostly short, never
# longer than MAX_PAUSE.
MIN_PAUSE = 0.15
MAX_PAUSE = 2.0
TYPICAL_PAUSE = 0.5

# Ghost battle: ghosts are fast, so only a tiny delay there.
GHOST_MAX_PAUSE = 0.1


def pause():
    """Random wait before a menu click: usually ~0.5s, never over 2s."""
    return random.triangular(MIN_PAUSE, MAX_PAUSE, TYPICAL_PAUSE)


def ghost_pause():
    return random.uniform(0.0, GHOST_MAX_PAUSE)


def jitter(x, y, spread_x=12, spread_y=9):
    """Random point near (x, y): clustered around the centre like a real
    finger, but clipped so it can't leave the button."""
    dx = max(-spread_x, min(spread_x, random.gauss(0, spread_x / 2.2)))
    dy = max(-spread_y, min(spread_y, random.gauss(0, spread_y / 2.2)))
    return int(round(x + dx)), int(round(y + dy))


def drag_ms():
    return random.randint(90, 150)
