"""Auto-Revive while the bot is NOT running (you're playing yourself).

Every couple of seconds it takes a screenshot from BlueStacks; if the campaign
DEFEAT popup with the blue REVIVE button is showing, it presses REVIVE. It never
taps anything else. The bot stops this watcher while it's running (the bot
handles defeats itself).
"""
import threading
import time
import types

import humanize
from adb import Device
from bot import Bot
from vision import Vision

CHECK_EVERY = 2.0
AFTER_REVIVE = 5.0


class ReviveWatcher:
    def __init__(self, log, on_revive=None):
        self.log = log
        self.on_revive = on_revive or (lambda: None)
        self.stop_event = threading.Event()
        self.thread = None
        self._finder = None

    def running(self):
        return bool(self.thread and self.thread.is_alive())

    def start(self):
        if self.running():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()

    def _run(self):
        if self._finder is None:
            self._finder = types.SimpleNamespace(vis=Vision(), REVIVE_SEARCH=Bot.REVIVE_SEARCH)
        dev = None
        while not self.stop_event.is_set():
            try:
                if dev is None:
                    dev = Device()
                    dev.connect()
                img = dev.screenshot()
                found = Bot.campaign_defeat(self._finder, img)
                if found and found[0]:
                    dev.tap(*humanize.jitter(*found[0]))
                    self.log("Auto-Revive: campaign defeat -> pressed Revive")
                    self.on_revive()
                    self.stop_event.wait(AFTER_REVIVE)
                    continue
            except Exception:  # noqa: BLE001 - BlueStacks closed / not connected: try again later
                if dev is not None:
                    try:
                        dev.close()
                    except Exception:  # noqa: BLE001
                        pass
                dev = None
                self.stop_event.wait(10)
                continue
            self.stop_event.wait(CHECK_EVERY)
        if dev is not None:
            try:
                dev.close()
            except Exception:  # noqa: BLE001
                pass
