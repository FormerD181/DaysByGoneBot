"""Alert sound playback via the Windows media player API (MCI).

MCI plays .wav and .mp3 (and .wma), can loop, and lets us force the app's own
volume to max. It can't go louder than the Windows volume itself.
"""
import ctypes
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_SOUND = os.path.join(HERE, "assets", "alarm.wav")
SUPPORTED = (".wav", ".mp3", ".wma")
_ALIAS = "bbalert"


def _mci(command):
    buf = ctypes.create_unicode_buffer(256)
    err = ctypes.windll.winmm.mciSendStringW(command, buf, 255, 0)
    return err == 0


def play(path=None, loop=False, volume=100):
    """Play the alert (default alarm if path is empty/missing) at volume 0-100.
    Returns True on success."""
    path = path if path and os.path.exists(path) else DEFAULT_SOUND
    stop()
    if not _mci(f'open "{path}" type mpegvideo alias {_ALIAS}'):
        return False
    set_volume(volume)
    return _mci(f"play {_ALIAS}{' repeat' if loop else ''}")


def set_volume(volume):
    """0-100 (% of the Windows volume). Works while playing."""
    level = max(0, min(100, int(volume))) * 10
    _mci(f"setaudio {_ALIAS} volume to {level}")


def stop():
    _mci(f"stop {_ALIAS}")
    _mci(f"close {_ALIAS}")
