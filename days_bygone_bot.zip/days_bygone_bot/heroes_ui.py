"""Heroes tool (right-hand panel): the Book of Heroes from the Days Bygone
Discord, with its custom emojis shown inline.

Data: assets/heroes/<hero>.json  (text + picture file names)
      assets/heroes/emojis/<Name>.png   (custom Discord emojis)
      assets/heroes/images/*.webp       (pictures from the posts)
"""
import glob
import json
import os
import re
import tkinter as tk

from PIL import Image, ImageTk

from widgets import ACCENT, LOG_BG, MUTED, PILL, TEXT

HERE = os.path.dirname(os.path.abspath(__file__))
HERO_DIR = os.path.join(HERE, "assets", "heroes")
BG = "#121216"
FIELD_BG = "#26262d"
EMOJI_PX = 20
GREEN, RED, YELLOW = "#5fd38a", "#ff6b6b", "#ffcd00"
# Unicode emojis Tk can't always draw in colour -> coloured text stand-ins
UNICODE = {"✅": ("✔", GREEN), "❌": ("✘", RED), "🟡": ("●", YELLOW), "🟢": ("●", GREEN),
           "🔴": ("●", RED), "🔵": ("●", "#5aa9ff"), "🟣": ("●", "#c86cff"), "⭐": ("★", YELLOW)}
GROUP_ORDER = ["Common", "Rare", "Epic", "Legendary", "World"]
TOKEN = re.compile(r"(:[A-Za-z0-9_]+:|\*\*|" + "|".join(map(re.escape, UNICODE)) + ")")


def _group_rank(group):
    for i, word in enumerate(GROUP_ORDER):
        if group.startswith(word):
            return i
    return len(GROUP_ORDER)


def load_heroes():
    heroes = []
    for path in sorted(glob.glob(os.path.join(HERO_DIR, "*.json"))):
        try:
            with open(path, encoding="utf-8") as f:
                heroes.append(json.load(f))
        except (OSError, ValueError):
            pass
    return heroes


def _button(parent, text, cmd):
    return tk.Button(parent, text=text, command=cmd, relief="flat", cursor="hand2", padx=10, pady=3,
                     font=("Segoe UI", 9), bg=PILL, fg=TEXT, activebackground="#3a3a43", activeforeground=TEXT)


class HeroesPanel:
    def __init__(self, parent, width):
        self.width = width
        self.heroes = load_heroes()
        self.photos = []                    # keep picture references alive
        self.emoji_cache = {}
        f = self.frame = tk.Frame(parent, bg=BG)
        f.pack(fill="both", expand=True)

        # ---- page 1: list -------------------------------------------------
        p1 = self.page_list = tk.Frame(f, bg=BG)
        row = tk.Frame(p1, bg=BG)
        row.pack(fill="x", pady=(0, 6))
        tk.Label(row, text="Search", bg=BG, fg=TEXT, font=("Segoe UI", 10)).pack(side="left")
        self.query = tk.StringVar()
        e = tk.Entry(row, textvariable=self.query, bg=FIELD_BG, fg=TEXT, insertbackground=TEXT,
                     relief="flat", font=("Segoe UI", 10))
        e.pack(side="left", fill="x", expand=True, padx=(8, 0), ipady=2)
        self.query.trace_add("write", lambda *a: self._fill_list())
        lbox = tk.Frame(p1, bg=BG)
        lbox.pack(fill="both", expand=True)
        self.list = tk.Text(lbox, bg=LOG_BG, fg=TEXT, relief="flat", wrap="none", padx=8, pady=6,
                            font=("Segoe UI", 11), cursor="arrow", spacing1=3, spacing3=3)
        lsb = tk.Scrollbar(lbox, command=self.list.yview)
        self.list.configure(yscrollcommand=lsb.set)
        lsb.pack(side="right", fill="y")
        self.list.pack(fill="both", expand=True)
        self.list.tag_configure("group", foreground=MUTED, font=("Segoe UI", 8, "bold"), spacing1=8)
        self.list.tag_configure("sub", foreground=MUTED, font=("Segoe UI", 8))
        tk.Label(p1, text="From #book-of-heroes on the Days Bygone Discord", bg=BG, fg=MUTED,
                 font=("Segoe UI", 7)).pack(anchor="w", pady=(4, 0))

        # ---- page 2: one hero ---------------------------------------------
        p2 = self.page_hero = tk.Frame(f, bg=BG)
        top = tk.Frame(p2, bg=BG)
        top.pack(fill="x", pady=(0, 6))
        _button(top, "◂  All heroes", lambda: self._page(1)).pack(side="left")
        box = tk.Frame(p2, bg=BG)
        box.pack(fill="both", expand=True)
        self.text = tk.Text(box, bg=LOG_BG, fg="#dcdce2", relief="flat", wrap="word", padx=10, pady=8,
                            font=("Segoe UI", 10), spacing1=1, spacing3=4, cursor="arrow")
        sb = tk.Scrollbar(box, command=self.text.yview)
        self.text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.text.pack(fill="both", expand=True)
        t = self.text
        t.tag_configure("title", foreground=ACCENT, font=("Segoe UI", 13, "bold"), spacing3=2)
        t.tag_configure("h1", foreground=ACCENT, font=("Segoe UI", 11, "bold"), spacing1=10)
        t.tag_configure("h2", foreground=TEXT, font=("Segoe UI", 10, "bold"), spacing1=8)
        t.tag_configure("h3", foreground=MUTED, font=("Segoe UI", 9, "bold"), spacing1=6)
        t.tag_configure("bold", font=("Segoe UI", 10, "bold"))
        t.tag_configure("li", lmargin1=10, lmargin2=22)
        t.tag_configure("muted", foreground=MUTED, font=("Segoe UI", 8))
        for ch, (_, color) in UNICODE.items():
            t.tag_configure("u" + color, foreground=color)

        self._fill_list()
        self._page(1)

    # -- pages -------------------------------------------------------------------
    def _page(self, n):
        (self.page_hero if n == 1 else self.page_list).pack_forget()
        (self.page_list if n == 1 else self.page_hero).pack(fill="both", expand=True)

    def _emoji(self, name, px=EMOJI_PX):
        key = (name, px)
        if key not in self.emoji_cache:
            path = os.path.join(HERO_DIR, "emojis", name + ".png")
            if not os.path.exists(path):
                self.emoji_cache[key] = None
            else:
                img = Image.open(path).convert("RGBA")
                img.thumbnail((px, px), Image.LANCZOS)
                self.emoji_cache[key] = ImageTk.PhotoImage(img)
        return self.emoji_cache[key]

    def _fill_list(self):
        q = self.query.get().strip().lower()
        L = self.list
        L.configure(state="normal")
        L.delete("1.0", "end")
        last_group = None
        shown = 0
        for i, h in enumerate(sorted(self.heroes, key=lambda h: (_group_rank(h.get("group", "")), h.get("group", ""), h["name"]))):
            if q and q not in h["name"].lower() and q not in h["title"].lower():
                continue
            if h.get("group") != last_group:
                last_group = h.get("group")
                L.insert("end", (last_group or "Heroes").upper() + "\n", "group")
            tag = f"hero{i}"
            img = self._emoji(h.get("portrait", ""), 28)
            if img:
                L.image_create("end", image=img, padx=4)
            L.insert("end", " " + h["name"], tag)
            sub = h["title"].split(":", 1)[1].strip() if ":" in h["title"] else ""
            L.insert("end", (f"   {sub}" if sub else "") + "\n", ("sub", tag))
            L.tag_bind(tag, "<Button-1>", lambda e, h=h: self.show(h))
            L.tag_bind(tag, "<Enter>", lambda e, t=tag: L.tag_configure(t, foreground=ACCENT))
            L.tag_bind(tag, "<Leave>", lambda e, t=tag: L.tag_configure(t, foreground=TEXT))
            shown += 1
        if not shown:
            L.insert("end", "No heroes match that search.\n", "sub")
        L.configure(state="disabled")

    # -- one hero ----------------------------------------------------------------
    def show(self, h):
        t = self.text
        self.photos = []
        t.configure(state="normal")
        t.delete("1.0", "end")
        img = self._emoji(h.get("portrait", ""), 32)
        if img:
            t.image_create("end", image=img, padx=2)
        t.insert("end", " " + h["title"] + "\n", "title")
        t.insert("end", h.get("group", "") + "\n", "muted")
        for msg in h["messages"]:
            if msg["txt"]:
                self._render(msg["txt"])
            for name in msg.get("images", []):
                self._picture(os.path.join(HERO_DIR, "images", name))
        t.insert("end", "\nFrom #book-of-heroes on the Days Bygone Discord.\n", "muted")
        t.configure(state="disabled")
        t.yview_moveto(0)
        self._page(2)

    def _render(self, text):
        t = self.text
        for line in text.split("\n"):
            tags = ()
            if line.startswith("### "):
                line, tags = line[4:], ("h3",)
            elif line.startswith("## "):
                line, tags = line[3:], ("h2",)
            elif line.startswith("# "):
                line, tags = line[2:], ("h1",)
            elif line.startswith("- "):
                t.insert("end", "•  ", "li")
                line, tags = line[2:], ("li",)
            bold = False
            for part in TOKEN.split(line):
                if not part:
                    continue
                if part == "**":
                    bold = not bold
                elif part.startswith(":") and part.endswith(":") and len(part) > 2:
                    img = self._emoji(part.strip(":"))
                    if img:
                        t.image_create("end", image=img, padx=1)
                    else:
                        t.insert("end", part, tags)
                elif part in UNICODE:
                    ch, color = UNICODE[part]
                    t.insert("end", ch, tags + ("u" + color,))
                else:
                    t.insert("end", part, tags + (("bold",) if bold else ()))
            t.insert("end", "\n", tags)

    def _picture(self, path):
        if not os.path.exists(path):
            return
        img = Image.open(path).convert("RGBA")
        max_w = self.width - 50
        if img.width > max_w:
            img = img.resize((max_w, int(img.height * max_w / img.width)), Image.LANCZOS)
        photo = ImageTk.PhotoImage(img)
        self.photos.append(photo)
        t = self.text
        t.insert("end", "\n")
        tag = f"pic{len(self.photos)}"
        t.image_create("end", image=photo)
        t.tag_add(tag, "end-2c", "end-1c")
        t.insert("end", "\n")
        t.insert("end", "click picture to open it full size\n", ("muted", tag))
        t.tag_bind(tag, "<Button-1>", lambda e, p=path: os.startfile(p))
        t.tag_bind(tag, "<Enter>", lambda e: t.configure(cursor="hand2"))
        t.tag_bind(tag, "<Leave>", lambda e: t.configure(cursor="arrow"))
