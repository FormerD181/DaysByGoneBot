"""Heroes tool (right-hand panel): the Book of Heroes from the Days Bygone
Discord, with its custom emojis shown inline.

Tabs:  Heroes   - every hero post
       Teams    - every recommended team, sorted by game mode
       Synergy  - which heroes the guides put on the same team
       Guides   - the how-to parts (evolutions, unlocks, mechanics, 15 stars)

Data: assets/heroes/<hero>.json  (text + picture file names)
      assets/heroes/emojis/<Name>.png   (custom Discord emojis)
      assets/heroes/images/*.webp       (pictures from the posts)
"""
import glob
import json
import os
import re
import tkinter as tk
from tkinter import ttk

from PIL import Image, ImageTk

import hero_guides
from widgets import ACCENT, LOG_BG, MUTED, PILL, TEXT

HERE = os.path.dirname(os.path.abspath(__file__))
HERO_DIR = os.path.join(HERE, "assets", "heroes")
BG = "#121216"
FIELD_BG = "#26262d"
EMOJI_PX = 20
GREEN, RED, YELLOW = "#5fd38a", "#ff6b6b", "#ffcd00"
# Unicode emojis Tk can't always draw in colour -> coloured text stand-ins
UNICODE = {"✅": ("✔", GREEN), "❌": ("✘", RED), "🟡": ("●", YELLOW), "🟢": ("●", GREEN),
           "🔴": ("●", RED), "🔵": ("●", "#5aa9ff"), "🟣": ("●", "#c86cff"), "⭐": ("★", YELLOW)}
GROUP_ORDER = ["Common", "Rare", "Epic", "Legendary", "World"]
TOKEN = re.compile(r"(:[A-Za-z0-9_]+:|\*\*|" + "|".join(map(re.escape, UNICODE)) + ")")
TABS = ["Heroes", "Teams", "Synergy", "Guides"]
CREDIT = "From #book-of-heroes on the Days Bygone Discord"


def _group_rank(group):
    for i, word in enumerate(GROUP_ORDER):
        if group.startswith(word):
            return i
    return len(GROUP_ORDER)


def load_heroes():
    heroes = []
    for path in sorted(glob.glob(os.path.join(HERO_DIR, "*.json"))):
        try:
            with open(path, encoding="utf-8") as f:
                heroes.append(json.load(f))
        except (OSError, ValueError):
            pass
    return heroes


def _button(parent, text, cmd):
    return tk.Button(parent, text=text, command=cmd, relief="flat", cursor="hand2", padx=10, pady=3,
                     font=("Segoe UI", 9), bg=PILL, fg=TEXT, activebackground="#3a3a43", activeforeground=TEXT)


def _split_camel(name):
    return re.sub(r"(?<=[a-z])(?=[A-Z])", " ", name)


SMALL_WORDS = {"to", "into", "a", "an", "of", "the", "is", "do", "does", "for", "or", "and", "at", "his", "her",
               "should", "use", "work", "how", "when", "you", "get", "what", "before", "vs", "those", "people",
               "considering", "good", "on", "hit", "effect", "summon", "evolve"}


def _nice(title):
    """ALL-CAPS heading -> readable: small words lower-case, names capitalised."""
    if not title.isupper():
        return title
    words = []
    for n, w in enumerate(title.lower().split()):
        core = w.strip("?.,()")
        if core == "i":
            w = w.replace("i", "I", 1)
        elif n == 0 or core not in SMALL_WORDS:
            w = w[:1].upper() + w[1:]
        words.append(w)
    return " ".join(words)


class HeroesPanel:
    def __init__(self, parent, width):
        self.width = width
        self.heroes = sorted(load_heroes(), key=lambda h: (_group_rank(h.get("group", "")),
                                                           h.get("group", ""), h["name"]))
        self.photos = []                    # keep picture references alive
        self.emoji_cache = {}
        self.tab = "Heroes"
        self.back_tab = "Heroes"
        self._emoji_files = {os.path.splitext(f)[0].lower(): os.path.splitext(f)[0]
                             for f in os.listdir(os.path.join(HERO_DIR, "emojis"))} \
            if os.path.isdir(os.path.join(HERO_DIR, "emojis")) else {}
        self._names = self._hero_names()
        self._teams = self._syn = self._guides = None     # built on first use
        f = self.frame = tk.Frame(parent, bg=BG)
        f.pack(fill="both", expand=True)

        # ---- tab row ----------------------------------------------------------
        bar = tk.Frame(f, bg=BG)
        bar.pack(fill="x", pady=(0, 6))
        self.tab_btns = {}
        for name in TABS:
            b = tk.Button(bar, text=name, relief="flat", cursor="hand2", padx=8, pady=2,
                          font=("Segoe UI", 9, "bold"), command=lambda n=name: self.show_tab(n))
            b.pack(side="left", padx=(0, 4))
            self.tab_btns[name] = b
        self.body = tk.Frame(f, bg=BG)
        self.body.pack(fill="both", expand=True)
        tk.Label(f, text=CREDIT, bg=BG, fg=MUTED, font=("Segoe UI", 7)).pack(anchor="w", pady=(4, 0))

        # ---- Heroes: list -----------------------------------------------------
        p = self.page_list = tk.Frame(self.body, bg=BG)
        row = tk.Frame(p, bg=BG)
        row.pack(fill="x", pady=(0, 6))
        tk.Label(row, text="Search", bg=BG, fg=TEXT, font=("Segoe UI", 10)).pack(side="left")
        self.query = tk.StringVar()
        e = tk.Entry(row, textvariable=self.query, bg=FIELD_BG, fg=TEXT, insertbackground=TEXT,
                     relief="flat", font=("Segoe UI", 10))
        e.pack(side="left", fill="x", expand=True, padx=(8, 0), ipady=2)
        self.query.trace_add("write", lambda *a: self._fill_list())
        self.list = self._textbox(p, wrap="none", font=("Segoe UI", 11), spacing1=3, spacing3=3, padx=8, pady=6)
        self.list.tag_configure("group", foreground=MUTED, font=("Segoe UI", 8, "bold"), spacing1=8)
        self.list.tag_configure("sub", foreground=MUTED, font=("Segoe UI", 8))

        # ---- Teams --------------------------------------------------------------
        p = self.page_teams = tk.Frame(self.body, bg=BG)
        row = tk.Frame(p, bg=BG)
        row.pack(fill="x", pady=(0, 6))
        tk.Label(row, text="Game mode", bg=BG, fg=TEXT, font=("Segoe UI", 10)).pack(side="left")
        self.mode_pick = ttk.Combobox(row, state="readonly", width=24)
        self.mode_pick.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.mode_pick.bind("<<ComboboxSelected>>", lambda ev: self._fill_teams())
        self.teams_text = self._doc_box(p)

        # ---- Synergy ------------------------------------------------------------
        p = self.page_syn = tk.Frame(self.body, bg=BG)
        row = tk.Frame(p, bg=BG)
        row.pack(fill="x", pady=(0, 6))
        tk.Label(row, text="Hero", bg=BG, fg=TEXT, font=("Segoe UI", 10)).pack(side="left")
        self.syn_pick = ttk.Combobox(row, state="readonly", width=24)
        self.syn_pick.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.syn_pick.bind("<<ComboboxSelected>>", lambda ev: self._fill_syn())
        self.syn_text = self._doc_box(p)

        # ---- Guides: list -------------------------------------------------------
        p = self.page_guides = tk.Frame(self.body, bg=BG)
        self.guide_list = self._textbox(p, wrap="word", font=("Segoe UI", 10), spacing1=2, spacing3=2,
                                        padx=8, pady=6)
        self.guide_list.tag_configure("group", foreground=ACCENT, font=("Segoe UI", 9, "bold"), spacing1=10)
        self.guide_list.tag_configure("sub", foreground=MUTED, font=("Segoe UI", 8))

        # ---- one hero / one guide -------------------------------------------------
        p = self.page_doc = tk.Frame(self.body, bg=BG)
        top = tk.Frame(p, bg=BG)
        top.pack(fill="x", pady=(0, 6))
        self.back_btn = _button(top, "◂  Back", lambda: self.show_tab(self.back_tab))
        self.back_btn.pack(side="left")
        self.text = self._doc_box(p)

        self._fill_list()
        self.show_tab("Heroes")

    # -- building blocks ---------------------------------------------------------
    def _textbox(self, parent, **kw):
        box = tk.Frame(parent, bg=BG)
        box.pack(fill="both", expand=True)
        t = tk.Text(box, bg=LOG_BG, fg=TEXT, relief="flat", cursor="arrow", **kw)
        sb = tk.Scrollbar(box, command=t.yview)
        t.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        t.pack(fill="both", expand=True)
        return t

    def _doc_box(self, parent):
        t = self._textbox(parent, wrap="word", font=("Segoe UI", 10), spacing1=1, spacing3=4, padx=10, pady=8)
        t.configure(fg="#dcdce2")
        t.tag_configure("title", foreground=ACCENT, font=("Segoe UI", 13, "bold"), spacing3=2)
        t.tag_configure("h1", foreground=ACCENT, font=("Segoe UI", 11, "bold"), spacing1=10)
        t.tag_configure("h2", foreground=TEXT, font=("Segoe UI", 10, "bold"), spacing1=8)
        t.tag_configure("h3", foreground=MUTED, font=("Segoe UI", 9, "bold"), spacing1=6)
        t.tag_configure("bold", font=("Segoe UI", 10, "bold"))
        t.tag_configure("li", lmargin1=10, lmargin2=22)
        t.tag_configure("muted", foreground=MUTED, font=("Segoe UI", 8))
        t.tag_configure("herohead", foreground=TEXT, font=("Segoe UI", 11, "bold"), spacing1=12)
        for ch, (_, color) in UNICODE.items():
            t.tag_configure("u" + color, foreground=color)
        return t

    @staticmethod
    def _link(t, tag, cmd):
        t.tag_bind(tag, "<Button-1>", lambda e: cmd())
        t.tag_bind(tag, "<Enter>", lambda e: (t.tag_configure(tag, foreground=ACCENT), t.configure(cursor="hand2")))
        t.tag_bind(tag, "<Leave>", lambda e: (t.tag_configure(tag, foreground=""), t.configure(cursor="arrow")))

    def _hero_names(self):
        """hero key (e.g. 'saul') -> (display name, the post that covers it)."""
        names = {}
        for h in self.heroes:
            k = hero_guides.portrait_key(h)
            if k:
                nice = _split_camel(h["portrait"][5:])
                names[k] = (nice[:1].upper() + nice[1:], h)
        flat = [(re.sub(r"[^a-z]", "", x["name"].lower()), x) for x in self.heroes]
        for h in self.heroes:
            for m in h["messages"]:
                for e in hero_guides.EMOJI.findall(m["txt"]):
                    k = hero_guides._hero_key(e)
                    if not k or k in names:
                        continue
                    nice = _split_camel(e[5:])
                    post = next((x for n, x in flat if n == k), None) \
                        or next((x for n, x in flat if n.startswith(k)), None) \
                        or next((x for n, x in flat if k in n), None)
                    names[k] = (nice[:1].upper() + nice[1:], post)
        return names

    def _hero_emoji(self, key):
        """Emoji file name for a hero key (case-insensitive lookup)."""
        return self._emoji_files.get("hero_" + key, "")

    # -- tabs ------------------------------------------------------------------
    def show_tab(self, name):
        self.tab = name
        for n, b in self.tab_btns.items():
            on = n == name
            b.configure(bg=ACCENT if on else PILL, fg="#111111" if on else TEXT,
                        activebackground=ACCENT if on else "#3a3a43")
        page = {"Heroes": self.page_list, "Teams": self.page_teams,
                "Synergy": self.page_syn, "Guides": self.page_guides}[name]
        if name == "Teams" and self._teams is None:
            self._teams = hero_guides.teams(self.heroes)
            self.mode_pick.configure(values=[f"{m}  ({len(v)})" for m, v in self._teams.items()])
            modes = list(self._teams)
            if modes:
                self.mode_pick.current(modes.index("Campaign") if "Campaign" in modes else 0)
            self._fill_teams()
        if name == "Synergy" and self._syn is None:
            self._syn = hero_guides.synergies(self.heroes)
            counts = self._syn[0]
            self._syn_keys = sorted(counts, key=lambda k: self._names.get(k, (k,))[0].lower())
            self.syn_pick.configure(values=[self._names.get(k, (k,))[0] for k in self._syn_keys])
            self._fill_syn()
        if name == "Guides" and self._guides is None:
            self._guides = hero_guides.guides(self.heroes)
            self._fill_guide_list()
        self._show_page(page)

    def _show_page(self, page):
        for p in (self.page_list, self.page_teams, self.page_syn, self.page_guides, self.page_doc):
            if p is not page:
                p.pack_forget()
        page.pack(fill="both", expand=True)

    # -- emojis + markdown -------------------------------------------------------
    def _emoji(self, name, px=EMOJI_PX):
        key = (name, px)
        if key not in self.emoji_cache:
            path = os.path.join(HERO_DIR, "emojis", (name or "") + ".png")
            if not name or not os.path.exists(path):
                self.emoji_cache[key] = None
            else:
                img = Image.open(path).convert("RGBA")
                img.thumbnail((px, px), Image.LANCZOS)
                self.emoji_cache[key] = ImageTk.PhotoImage(img)
        return self.emoji_cache[key]

    def _render(self, text, t=None):
        t = t or self.text
        for line in text.split("\n"):
            tags = ()
            if line.startswith("### "):
                line, tags = line[4:], ("h3",)
            elif line.startswith("## "):
                line, tags = line[3:], ("h2",)
            elif line.startswith("# "):
                line, tags = line[2:], ("h1",)
            elif line.startswith("- "):
                t.insert("end", "•  ", "li")
                line, tags = line[2:], ("li",)
            bold = False
            for part in TOKEN.split(line):
                if not part:
                    continue
                if part == "**":
                    bold = not bold
                elif part.startswith(":") and part.endswith(":") and len(part) > 2:
                    img = self._emoji(part.strip(":"))
                    if img:
                        t.image_create("end", image=img, padx=1)
                    else:
                        t.insert("end", part, tags)
                elif part in UNICODE:
                    ch, color = UNICODE[part]
                    t.insert("end", ch, tags + ("u" + color,))
                else:
                    t.insert("end", part, tags + (("bold",) if bold else ()))
            t.insert("end", "\n", tags)

    def _hero_header(self, t, h, tag, note=""):
        """Portrait + clickable hero name (opens the hero's page)."""
        t.insert("end", "\n", "herohead")
        img = self._emoji(h.get("portrait", ""), 24)
        if img:
            t.image_create("end", image=img, padx=2)
        t.insert("end", " " + h["name"], ("herohead", tag))
        if note:
            t.insert("end", "   " + note, "muted")
        t.insert("end", "\n")
        self._link(t, tag, lambda h=h, back=self.tab: self.show(h, back=back))

    # -- Heroes tab --------------------------------------------------------------
    def _fill_list(self):
        q = self.query.get().strip().lower()
        L = self.list
        L.configure(state="normal")
        L.delete("1.0", "end")
        last_group = None
        shown = 0
        for i, h in enumerate(self.heroes):
            if q and q not in h["name"].lower() and q not in h["title"].lower():
                continue
            if h.get("group") != last_group:
                last_group = h.get("group")
                L.insert("end", (last_group or "Heroes").upper() + "\n", "group")
            tag = f"hero{i}"
            img = self._emoji(h.get("portrait", ""), 28)
            if img:
                L.image_create("end", image=img, padx=4)
            L.insert("end", " " + h["name"], tag)
            sub = h["title"].split(":", 1)[1].strip() if ":" in h["title"] else ""
            L.insert("end", (f"   {sub}" if sub else "") + "\n", ("sub", tag))
            L.tag_bind(tag, "<Button-1>", lambda e, h=h: self.show(h, back="Heroes"))
            L.tag_bind(tag, "<Enter>", lambda e, t=tag: L.tag_configure(t, foreground=ACCENT))
            L.tag_bind(tag, "<Leave>", lambda e, t=tag: L.tag_configure(t, foreground=TEXT))
            shown += 1
        if not shown:
            L.insert("end", "No heroes match that search.\n", "sub")
        L.configure(state="disabled")

    # -- Teams tab ---------------------------------------------------------------
    def _fill_teams(self):
        t = self.teams_text
        t.configure(state="normal")
        t.delete("1.0", "end")
        modes = list(self._teams)
        i = self.mode_pick.current()
        if i < 0 or not modes:
            t.insert("end", "No teams found.\n", "muted")
            t.configure(state="disabled")
            return
        mode = modes[i]
        t.insert("end", f"{mode} teams\n", "title")
        t.insert("end", "Every team the hero guides recommend for this mode, in their own words. "
                        "Click a hero's name for their full guide.\n", "muted")
        for n, (h, text) in enumerate(self._teams[mode]):
            self._hero_header(t, h, f"tm{n}", "from this hero's guide")
            self._render(text, t)
        t.configure(state="disabled")
        t.yview_moveto(0)

    # -- Synergy tab ---------------------------------------------------------------
    def _plural(self, k):
        return f"{k} team{'s' if k != 1 else ''}"

    def _fill_syn(self):
        t = self.syn_text
        t.configure(state="normal")
        t.delete("1.0", "end")
        counts, lines = self._syn
        i = self.syn_pick.current()
        if i < 0:
            # overview: the pairs that show up together most often
            t.insert("end", "Best pairs\n", "title")
            t.insert("end", "Heroes the guides put on the same team most often. "
                            "Pick a hero above to see all of their partners and teams.\n", "muted")
            pairs = {}
            for a, c in counts.items():
                for b, n in c.items():
                    if a < b:
                        pairs[(a, b)] = n
            for a, b in sorted(pairs, key=lambda p: -pairs[p])[:25]:
                t.insert("end", "\n")
                for key in (a, b):
                    img = self._emoji(self._hero_emoji(key), 22)
                    if img:
                        t.image_create("end", image=img, padx=2)
                t.insert("end", f"  {self._names.get(a, (a,))[0]} + {self._names.get(b, (b,))[0]}", "bold")
                t.insert("end", "   " + self._plural(pairs[(a, b)]), "muted")
            t.insert("end", "\n")
            t.configure(state="disabled")
            return
        key = self._syn_keys[i]
        name, post = self._names.get(key, (key, None))
        img = self._emoji(self._hero_emoji(key), 32)
        if img:
            t.image_create("end", image=img, padx=2)
        t.insert("end", f" {name}\n", "title")
        if post is not None:
            t.insert("end", "Open " + post["name"] + "'s guide", ("muted", "openpost"))
            t.insert("end", "\n")
            self._link(t, "openpost", lambda: self.show(post, back="Synergy"))
        t.insert("end", "Teamed with most often\n", "h1")
        for n, (b, k) in enumerate(counts[key].most_common()):
            img = self._emoji(self._hero_emoji(b), 22)
            if img:
                t.image_create("end", image=img, padx=2)
            bname, bpost = self._names.get(b, (b, None))
            tag = f"syn{n}"
            t.insert("end", f"  {bname}", ("bold", tag))
            t.insert("end", "   " + self._plural(k) + "\n", "muted")
            if bpost is not None:
                self._link(t, tag, lambda p=bpost: self.show(p, back="Synergy"))
        t.insert("end", "Teams with this hero\n", "h1")
        shown = set()
        for mode, h, line in lines[key]:
            if (mode, h["name"], line) in shown:
                continue
            shown.add((mode, h["name"], line))
            t.insert("end", f"{mode}  ·  from {h['name']}'s guide\n", "h3")
            self._render(line, t)
        t.configure(state="disabled")
        t.yview_moveto(0)

    # -- Guides tab ----------------------------------------------------------------
    def _fill_guide_list(self):
        L = self.guide_list
        L.configure(state="normal")
        L.delete("1.0", "end")
        last = None
        for n, (cat, title, h, text) in enumerate(self._guides):
            if cat != last:
                last = cat
                L.insert("end", cat.upper() + "\n", "group")
            img = self._emoji(h.get("portrait", ""), 20)
            if img:
                L.image_create("end", image=img, padx=3)
            tag = f"g{n}"
            L.insert("end", " " + _nice(title), tag)
            L.insert("end", f"   {h['name']}\n", ("sub", tag))
            self._link(L, tag, lambda g=(cat, title, h, text): self.show_guide(*g))
        if not self._guides:
            L.insert("end", "No guides found.\n", "sub")
        L.configure(state="disabled")

    def show_guide(self, cat, title, h, text):
        t = self.text
        self.photos = []
        t.configure(state="normal")
        t.delete("1.0", "end")
        t.insert("end", _nice(title) + "\n", "title")
        t.insert("end", cat + "\n", "muted")
        self._render(text, t)
        self.tab = "Guides"
        self._hero_header(t, h, "guidehero", "open the full hero guide")
        t.insert("end", "\n" + CREDIT + ".\n", "muted")
        t.configure(state="disabled")
        t.yview_moveto(0)
        self.back_tab = "Guides"
        self.back_btn.configure(text="◂  Guides")
        self._show_page(self.page_doc)

    # -- one hero ----------------------------------------------------------------
    def show(self, h, back="Heroes"):
        t = self.text
        self.photos = []
        t.configure(state="normal")
        t.delete("1.0", "end")
        img = self._emoji(h.get("portrait", ""), 32)
        if img:
            t.image_create("end", image=img, padx=2)
        t.insert("end", " " + h["title"] + "\n", "title")
        t.insert("end", h.get("group", "") + "\n", "muted")
        for msg in h["messages"]:
            if msg["txt"]:
                self._render(msg["txt"])
            for name in msg.get("images", []):
                self._picture(os.path.join(HERO_DIR, "images", name))
        t.insert("end", "\n" + CREDIT + ".\n", "muted")
        t.configure(state="disabled")
        t.yview_moveto(0)
        self.back_tab = back
        self.back_btn.configure(text="◂  " + ("All heroes" if back == "Heroes" else back))
        self._show_page(self.page_doc)

    def _page(self, n):
        """1 = hero list, 2 = the open hero page (kept for older callers)."""
        if n == 1:
            self.show_tab("Heroes")
        else:
            self._show_page(self.page_doc)

    def _picture(self, path):
        if not os.path.exists(path):
            return
        img = Image.open(path).convert("RGBA")
        max_w = self.width - 50
        if img.width > max_w:
            img = img.resize((max_w, int(img.height * max_w / img.width)), Image.LANCZOS)
        photo = ImageTk.PhotoImage(img)
        self.photos.append(photo)
        t = self.text
        t.insert("end", "\n")
        tag = f"pic{len(self.photos)}"
        t.image_create("end", image=photo)
        t.tag_add(tag, "end-2c", "end-1c")
        t.insert("end", "\n")
        t.insert("end", "click picture to open it full size\n", ("muted", tag))
        t.tag_bind(tag, "<Button-1>", lambda e, p=path: os.startfile(p))
        t.tag_bind(tag, "<Enter>", lambda e: t.configure(cursor="hand2"))
        t.tag_bind(tag, "<Leave>", lambda e: t.configure(cursor="arrow"))
