"""Canvas-drawn widgets and styling shared by the bot window and the clicker game."""


# Change this one number to make the whole window bigger or smaller.
SCALE = 0.78


def s(v):
    return int(round(v * SCALE))


# Colours
TEXT = "#ffffff"
MUTED = "#a3a3ad"
ACCENT = "#ffcd00"               # Waffle House yellow
ACCENT_TEXT = "#111111"
PILL = "#2b2b32"
PILL_HOVER = "#3a3a43"
GREEN = "#2fb35a"
RED = "#d6453d"
DISABLED = "#3b3b42"
LOG_BG = "#141418"

FONT = "Segoe UI"


def font(size, bold=False):
    return (FONT, max(7, s(size)), "bold" if bold else "normal")


def rounded_rect(canvas, x0, y0, x1, y1, r, **kw):
    pts = [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y1 - r, x1, y1,
           x1 - r, y1, x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]
    return canvas.create_polygon(pts, smooth=True, **kw)


class CanvasButton:
    """Rounded button drawn on the canvas (so it sits on the picture cleanly)."""

    def __init__(self, canvas, box, text, on_click, size=11, tags=()):
        self.c = canvas
        self.on_click = on_click
        self.colors = (PILL, TEXT)
        self.enabled = True
        x0, y0, x1, y1 = box
        tag = f"btn{id(self)}"
        all_tags = (tag,) + tuple(tags)
        self.bg = rounded_rect(canvas, x0, y0, x1, y1, s(12), fill=PILL, outline="", tags=all_tags)
        self.label = canvas.create_text((x0 + x1) / 2, (y0 + y1) / 2, text=text, fill=TEXT,
                                        font=font(size, True), tags=all_tags, justify="center")
        canvas.tag_bind(tag, "<Button-1>", self._click)
        canvas.tag_bind(tag, "<Enter>", lambda e: self._hover(True))
        canvas.tag_bind(tag, "<Leave>", lambda e: self._hover(False))

    def set_text(self, text):
        self.c.itemconfigure(self.label, text=text)

    def style(self, bg, fg, enabled=True):
        self.colors = (bg, fg)
        self.enabled = enabled
        self.c.itemconfigure(self.bg, fill=bg)
        self.c.itemconfigure(self.label, fill=fg)

    def _hover(self, inside):
        self.c.configure(cursor="hand2" if inside and self.enabled else "")
        if self.enabled and self.colors[0] == PILL:
            self.c.itemconfigure(self.bg, fill=PILL_HOVER if inside else PILL)

    def _click(self, _event):
        if self.enabled:
            self.on_click()


class Toggle:
    """iOS-style switch drawn on the canvas."""

    def __init__(self, canvas, x, y, value, on_change):
        self.c = canvas
        self.value = value
        self.on_change = on_change
        self.x, self.y = x, y
        self.w, self.h = s(50), s(28)
        tag = f"tog{id(self)}"
        self.track = rounded_rect(canvas, x, y, x + self.w, y + self.h, self.h // 2, outline="", tags=tag)
        self.knob = canvas.create_oval(0, 0, 0, 0, fill=TEXT, outline="", tags=tag)
        canvas.tag_bind(tag, "<Button-1>", self._click)
        canvas.tag_bind(tag, "<Enter>", lambda e: canvas.configure(cursor="hand2"))
        canvas.tag_bind(tag, "<Leave>", lambda e: canvas.configure(cursor=""))
        self.draw()

    def draw(self):
        self.c.itemconfigure(self.track, fill=ACCENT if self.value else PILL)
        m = s(3)
        d = self.h - 2 * m
        kx = self.x + (self.w - d - m if self.value else m)
        self.c.coords(self.knob, kx, self.y + m, kx + d, self.y + m + d)

    def _click(self, _event):
        self.value = not self.value
        self.draw()
        self.on_change(self.value)


class Slider:
    """Horizontal 0-100 slider drawn on the canvas."""

    def __init__(self, canvas, x0, y, x1, value, on_change):
        self.c = canvas
        self.x0, self.x1, self.y = x0, x1, y
        self.on_change = on_change
        self.value = max(0, min(100, int(value)))
        tag = f"sld{id(self)}"
        th = s(6)
        rounded_rect(canvas, x0, y - th / 2, x1, y + th / 2, th / 2, fill=PILL, outline="", tags=tag)
        self.fill = rounded_rect(canvas, x0, y - th / 2, x0 + 1, y + th / 2, th / 2, fill=ACCENT,
                                 outline="", tags=tag)
        r = s(9)
        self.r = r
        self.knob = canvas.create_oval(0, 0, 0, 0, fill=TEXT, outline="", tags=tag)
        # Invisible wider hit area so the thin track is easy to grab.
        canvas.create_rectangle(x0 - r, y - r - 4, x1 + r, y + r + 4, fill="", outline="", tags=tag)
        canvas.tag_bind(tag, "<Button-1>", self._drag)
        canvas.tag_bind(tag, "<B1-Motion>", self._drag)
        canvas.tag_bind(tag, "<Enter>", lambda e: canvas.configure(cursor="hand2"))
        canvas.tag_bind(tag, "<Leave>", lambda e: canvas.configure(cursor=""))
        self.draw()

    def contains(self, x, y):
        return self.x0 - self.r <= x <= self.x1 + self.r and abs(y - self.y) <= self.r + 4

    def draw(self):
        th = s(6)
        kx = self.x0 + (self.x1 - self.x0) * self.value / 100
        self.c.delete(self.fill)
        self.fill = rounded_rect(self.c, self.x0, self.y - th / 2, max(self.x0 + th, kx), self.y + th / 2,
                                 th / 2, fill=ACCENT, outline="")
        self.c.tag_lower(self.fill, self.knob)
        self.c.coords(self.knob, kx - self.r, self.y - self.r, kx + self.r, self.y + self.r)

    def _drag(self, event):
        v = round((event.x - self.x0) / (self.x1 - self.x0) * 100)
        v = max(0, min(100, v))
        if v != self.value:
            self.value = v
            self.draw()
            self.on_change(v)


class RangeSlider:
    """Horizontal slider with two knobs (a low and a high value) drawn on the canvas."""

    def __init__(self, canvas, x0, y, x1, lo, hi, vmin, vmax, on_change):
        self.c = canvas
        self.x0, self.x1, self.y = x0, x1, y
        self.vmin, self.vmax = vmin, vmax
        self.on_change = on_change
        self.lo = max(vmin, min(vmax, int(lo)))
        self.hi = max(self.lo, min(vmax, int(hi)))
        self.tag = tag = f"rng{id(self)}"
        th = s(6)
        self.r = r = s(9)
        rounded_rect(canvas, x0, y - th / 2, x1, y + th / 2, th / 2, fill=PILL, outline="", tags=tag)
        self.fill = None
        self.knobs = [canvas.create_oval(0, 0, 0, 0, fill=TEXT, outline="", tags=tag) for _ in range(2)]
        canvas.create_rectangle(x0 - r, y - r - 4, x1 + r, y + r + 4, fill="", outline="", tags=tag)
        self.active = None
        canvas.tag_bind(tag, "<Button-1>", self._press)
        canvas.tag_bind(tag, "<B1-Motion>", self._drag)
        canvas.tag_bind(tag, "<Enter>", lambda e: canvas.configure(cursor="hand2"))
        canvas.tag_bind(tag, "<Leave>", lambda e: canvas.configure(cursor=""))
        self.draw()

    def _x(self, v):
        return self.x0 + (self.x1 - self.x0) * (v - self.vmin) / (self.vmax - self.vmin)

    def _v(self, x):
        v = round(self.vmin + (x - self.x0) / (self.x1 - self.x0) * (self.vmax - self.vmin))
        return max(self.vmin, min(self.vmax, v))

    def draw(self):
        th = s(6)
        a, b = self._x(self.lo), self._x(self.hi)
        if self.fill:
            self.c.delete(self.fill)
        self.fill = rounded_rect(self.c, a, self.y - th / 2, max(a + th, b), self.y + th / 2, th / 2,
                                 fill=ACCENT, outline="", tags=self.tag)
        self.c.tag_lower(self.fill, self.knobs[0])
        for knob, x in zip(self.knobs, (a, b)):
            self.c.coords(knob, x - self.r, self.y - self.r, x + self.r, self.y + self.r)

    def _press(self, event):
        v = self._v(event.x)
        # grab the nearer knob (the high one if they overlap and we're to the right)
        self.active = 0 if abs(v - self.lo) < abs(v - self.hi) or (v < self.lo) else 1
        if self.lo == self.hi:
            self.active = 1 if v >= self.hi else 0
        self._drag(event)

    def _drag(self, event):
        v = self._v(event.x)
        lo, hi = self.lo, self.hi
        if self.active == 0:
            lo = min(v, hi)
        else:
            hi = max(v, lo)
        if (lo, hi) != (self.lo, self.hi):
            self.lo, self.hi = lo, hi
            self.draw()
            self.on_change(lo, hi)
