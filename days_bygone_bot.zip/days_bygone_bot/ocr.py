"""Reads numbers in the game's pixel font (e.g. "0/24", "6122", "Lv. 11.74ab").

Each character is cut out by its colour, scaled to a fixed size and compared
with known characters in templates/glyphs/ (learned from real screenshots).
"""
import glob
import os

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
GLYPH_DIR = os.path.join(HERE, "templates", "glyphs")
GW, GH = 12, 16                 # normalised glyph size
MATCH_MAX = 0.125               # correct matches score <=0.12, the nearest wrong one 0.134+
# Fonts that share a typeface: if a character isn't known in the first,
# try the next (the level and journal numbers are the same font, different size).
FALLBACK = {"level": ["level", "journal"], "journal": ["journal", "level"], "counter": ["counter"],
            "info": ["info", "journal", "level"]}

# Text fill colours (OpenCV HSV)
COLORS = {
    "white": [((0, 0, 200), (180, 70, 255))],
    "yellow": [((22, 150, 200), (34, 255, 255))],   # World Tree info text
    "orange": [((12, 240, 240), (18, 255, 255))],   # level text is pure orange (15,255,255)
}


def text_mask(crop, color):
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    m = np.zeros(hsv.shape[:2], np.uint8)
    for lo, hi in COLORS[color]:
        m |= cv2.inRange(hsv, lo, hi)
    return m


def segment(crop, color, join=False):
    """Character boxes left to right: list of (x, y, w, h, bitmap).
    Works on columns (a character = a run of columns with ink), so thin dotted
    strokes still count as one character."""
    m = text_mask(crop, color)
    if join:   # thin dotted fonts (apple counter): join the dots into strokes
        m = cv2.dilate(m, np.ones((3, 3), np.uint8))
    else:      # bold fonts: erase thin lines (frames, sparkles) touching the text
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    # keep only the text band (drops bits of frames above/below the text)
    rows = (m > 0).sum(1)
    if rows.max() == 0:
        return [], 0
    on = rows >= 0.15 * rows.max()
    best, cur = (0, 0), None
    for y, v in enumerate(list(on) + [False]):
        if v and cur is None:
            cur = y
        elif not v and cur is not None:
            if y - cur > best[1] - best[0]:
                best = (cur, y)
            cur = None
    y0, y1 = best
    band = m[y0:y1]
    cols = (band > 0).sum(0)
    out, x = [], 0
    while x < len(cols):
        if cols[x] == 0:
            x += 1
            continue
        x0 = x
        while x < len(cols) and cols[x] > 0:
            x += 1
        piece = band[:, x0:x]
        ys = np.where(piece.sum(1) > 0)[0]
        if piece.sum() / 255 >= 6:
            out.append((x0, y0 + ys[0], x - x0, ys[-1] - ys[0] + 1, piece[ys[0]:ys[-1] + 1]))
    return out, y1 - y0


def _norm(bm):
    return (cv2.resize(bm, (GW, GH), interpolation=cv2.INTER_AREA) > 100)


def _features(x, y, w, h, bm, line_top, line_h):
    # shape + where the character sits on the line (tells '.' from 'o', etc.)
    return _norm(bm), w / line_h, h / line_h, (y - line_top) / line_h


class GlyphReader:
    def __init__(self):
        self.glyphs = {}   # font -> [(char, bitmap, aspect, height, top)]
        for path in glob.glob(os.path.join(GLYPH_DIR, "*", "*.png")):
            font = os.path.basename(os.path.dirname(path))
            name = os.path.splitext(os.path.basename(path))[0]
            char = bytes.fromhex(name.split("_")[0]).decode()
            bm = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
            meta = name.split("_")[1:4]
            self.glyphs.setdefault(font, []).append((char, bm > 100, *[int(v) / 100 for v in meta]))

    def classify(self, chars, line_h, font):
        """Best character for each cut-out piece, '?' where unsure."""
        if not chars:
            return ""
        line_top = min(c[1] for c in chars)
        pool = [g for f in FALLBACK.get(font, [font]) for g in self.glyphs.get(f, [])]
        out = []
        for x, y, w, h, bm in chars:
            f, a, hh, top = _features(x, y, w, h, bm, line_top, line_h)
            best = min(((np.mean(f != g) + 0.5 * abs(a - ga) + 0.5 * abs(hh - gh) + 0.3 * abs(top - gt), ch)
                        for ch, g, ga, gh, gt in pool), default=(9, "?"))
            out.append(best[1] if best[0] <= MATCH_MAX else "?")
        return "".join(out)

    def read_fraction(self, crop, color, font):
        """Find 'N/M' anywhere in a line of text (e.g. '... 490/450 Starforce').
        Returns (N, M) as ints, or None."""
        chars, line_h = segment(crop, color, True)
        text = self.classify(chars, line_h, font)
        import re
        m = re.search(r"(\d+)/(\d+)", text)
        return (int(m.group(1)), int(m.group(2))) if m else None

    def read(self, crop, color, font, join=False):
        """Return the text, or None if any character isn't recognised."""
        chars, line_h = segment(crop, color, join)
        if not chars:
            return None
        line_top = min(c[1] for c in chars)
        text = []
        for x, y, w, h, bm in chars:
            f, a, hh, top = _features(x, y, w, h, bm, line_top, line_h)
            best = None
            for ch, g, ga, gh, gt in [g for f in FALLBACK.get(font, [font]) for g in self.glyphs.get(f, [])]:
                shape = np.mean(f != g)
                score = shape + 0.5 * abs(a - ga) + 0.5 * abs(hh - gh) + 0.3 * abs(top - gt)
                if best is None or score < best[0]:
                    best = (score, ch)
            if best is None or best[0] > MATCH_MAX:
                return None
            text.append(best[1])
        return "".join(text)


def learn(crop, color, font, text, join=False):
    """Save the characters of a crop whose text is known. Returns True if the
    number of characters found matches the text."""
    chars, _ = segment(crop, color, join)
    text = text.replace(" ", "")
    if len(chars) != len(text):
        return False
    return learn_chars(chars, text, font)


def learn_chars(chars, text, font):
    """Save already-cut characters (from segment) with their known text."""
    out_dir = os.path.join(GLYPH_DIR, font)
    os.makedirs(out_dir, exist_ok=True)
    line_top = min(c[1] for c in chars)
    line_h = max(c[1] + c[3] for c in chars) - line_top
    for (x, y, w, h, bm), ch in zip(chars, text):
        f, a, hh, top = _features(x, y, w, h, bm, line_top, line_h)
        name = f"{ch.encode().hex()}_{int(a * 100)}_{int(hh * 100)}_{int(top * 100)}_{len(os.listdir(out_dir))}"
        cv2.imwrite(os.path.join(out_dir, name + ".png"), f.astype(np.uint8) * 255)
    return True
