"""World Tree planner: a line-for-line Python port of the community
"Worldtree Calc" Google Sheet (Apps Script PLAN_AHEAD / DAMAGES / APPLES).

plan(...) returns the best builds for your apples (and the next few apple counts).
Each build's score is "days": log base 1.066 of its total damage multiplier.
Keep this file faithful to the original script so results match the sheet.
"""
import math

HEADERS = ["IN", "TD", "AT", "GW", "RD", "AS", "TE", "BL", "S", "BT", "EA", "AC",
           "FA", "AP", "MS", "LB", "SM", "PS", "TS", "LS"]
# Skill names as they appear in the game (from the Worldtree Calc sheet;
# Third Eye / Raison D'etre / Ascende Superius confirmed on the game screen).
NODE_NAMES = {
    "IN": "Influence", "TD": "Time Dilation", "AT": "Astral Travel", "GW": "Gawain",
    "RD": "Raison D'etre", "AS": "Ascende Superius", "TE": "Third Eye", "BL": "Bloodlust",
    "S": "Smite", "BT": "Bloodthirster", "EA": "Excruciating Agony", "AC": "Astaroth's Curse",
    "FA": "Forbidden Arts", "AP": "Arcane Pulse", "MS": "Mana Surge", "LB": "Limit Break",
    "SM": "Spellmaster", "PS": "Perfect Storm", "TS": "Thirster", "LS": "L3 Magic Smite",
    "PM": "Middle node (unlocks Astral Travel)",
}
# Which World Tree tab each skill is on (for grouping the output)
NODE_TAB = {
    "TE": "Defender", "BL": "Defender", "S": "Defender", "BT": "Defender", "EA": "Defender", "AC": "Defender",
    "IN": "Traveller", "TD": "Traveller", "AT": "Traveller", "GW": "Traveller", "RD": "Traveller",
    "AS": "Traveller", "PM": "Traveller",
    "FA": "Conjurer", "AP": "Conjurer", "MS": "Conjurer", "LB": "Conjurer", "SM": "Conjurer",
    "PS": "Enhancer", "TS": "Enhancer", "LS": "Enhancer",
}


def build_name(levels):
    """Short readable name for a build, e.g. 'Bloodthirster 5 + Astaroth's Curse 2'."""
    main = [h for h in ("MS", "SM", "BT", "AC", "GW", "EA", "LB", "TS") if levels.get(h)]
    return " + ".join(f"{NODE_NAMES[h]} {levels[h]}" for h in main) or "Basics only"


LB_MAX = 9
LN_1066 = math.log(1.066)
LOOK = 10
WT4_TYPES = {"None": 0, "Perfect Storm": 1, "Wind": 2, "Cold": 3, "Holy": 4}

# Elixir Mastery level -> milestone (1 = 10K, 2 = 100K, ... 42 = 1ak)
_SUFFIX = ["K", "M", "B", "T"] + ["a" + c for c in "abcdefghijklmnopqrstuvwxyz"]


def milestone_from_level(level):
    """Milestone for an Elixir Mastery level given as a number."""
    if level < 10_000:
        return 0
    return int(math.floor(math.log10(level) + 1e-9)) - 3


def parse_game_number(text):
    """'5.72ab' -> 5.72e48 (K=1e3, M=1e6, B=1e9, T=1e12, aa=1e15, ab=1e18, ...)."""
    text = text.strip().replace(",", "")
    i = len(text)
    while i and text[i - 1].isalpha():
        i -= 1
    num, suf = float(text[:i]), text[i:]
    if not suf:
        return num
    return num * 1000 ** (_SUFFIX.index(suf) + 1)


def _pow(a, b):
    try:
        return float(a) ** b
    except OverflowError:   # JS gives Infinity here, match it
        return math.inf


def _simple_apples(lb_max, wt4):
    lb_max = min(int(lb_max), LB_MAX)
    return {
        "IN": [0] + [1] * 10,
        "TD": [0, 1, 2],
        "PM": [0, 1],
        "AT": [0, 1, 2],
        "GW": [0, 1, 2, 3, 4],
        "RD": [0] + [1] * 11,
        "AS": [0] + [1] * 9,
        "TE": [0] + [1] * 10,
        "BL": [0, 1, 2],
        "S": [0, 1],
        "BT": list(range(12)),
        "EA": [0, 1, 2, 3, 4, 5],
        "AC": [0, 2, 2, 3, 4, 5, 6, 7, 8],
        "FA": [0] + [1] * 10,
        "AP": [0, 1, 2],
        "MS": [0, 3, 2, 3, 4, 5, 6, 7],
        "LB": list(range(10))[:lb_max + 1],
        "SM": [0, 1, 2, 3, 4],
        "PS": [0] + [1] * 10 if wt4 > 0 else [0],
        "TS": [0, 2, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] if wt4 > 1 else [0],
        "LS": [0, 1, 2] if wt4 > 1 else [0],
    }


def _apples(lb_max, wt4):
    a = _simple_apples(lb_max, wt4)
    for row in a.values():
        for i in range(1, len(row)):
            row[i] += row[i - 1]
    return a


def _damages(milestones, hp, mana, fifteen, max_ascension, starforce, wt4, lb_max):
    if max_ascension > 20:
        raise ValueError("Max Ascension must be <= 20")
    lb_max = min(lb_max, LB_MAX)
    LS = {2: [1, 1250, 1280000], 3: [1, 250, 256000], 4: [1, 50, 51200]}.get(wt4, [1])
    return {
        "IN": [_pow(n / 2, milestones) for n in range(2, 13)],
        "TD": [1, 50, 51200],
        "PM": [1, 1],
        "AT": [_pow(n, max_ascension) for n in (1, 1.4, 2)],
        "GW": [_pow(n, 60) for n in (1, 1.103, 1.3025, 1.5871, 1.96)],
        "RD": [_pow(1.03, min(starforce, n)) for n in range(0, 1651, 150)],
        "AS": [_pow(2, min(fifteen, n)) for n in range(0, 91, 10)],
        "TE": [_pow(n / 2, milestones) for n in range(2, 13)],
        "BL": [1, 50, 51200],
        "S": [1, 100],
        "BT": [_pow(k, e) for k, e in [(1, 50), (1.05, 100), (1.1, 150), (1.15, 200), (1.2, 250), (1.25, 300),
                                       (1.3, 350), (1.35, 400), (1.4, 450), (1.45, 500), (1.5, 550), (1.55, 600)]],
        "EA": [_pow(1.066, 67 * n * (n + 1) / 2 + 5 * n) for n in range(6)],
        "AC": [1] + [_pow(1.005 + 0.0015 * i, min((i + 2) * 1000, hp - 1)) for i in range(8)],
        "FA": [_pow(n / 2, milestones) for n in range(2, 13)],
        "AP": [1, 50, 51200],
        "MS": [1] + [_pow(1.005 + 0.0025 * i, min((i + 1) * 1000, mana - 1)) for i in range(1, 7)]
              + [_pow(1.0225, min(7500, mana - 1))],
        "LB": [_pow(83, i) for i in (0, 1, 3, 6, 10, 15, 21, 28, 36, 45)][:lb_max + 1],
        "SM": [_pow(i, 10) for i in (1, 1.8, 4.89, 15.98, 56.69)],
        "PS": [_pow(1 + 0.15 * n / 2, milestones * 2) for n in range(11)] if wt4 > 0 else [1],
        "TS": [_pow(k, e) for k, e in [(1, 100), (1.05, 150), (1.10, 200), (1.15, 250), (1.20, 300), (1.25, 350),
                                       (1.30, 400), (1.35, 450), (1.40, 500), (1.45, 550), (1.50, 600), (1.55, 650)]]
        if wt4 > 1 else [1],
        "LS": LS,
    }


def _simple_damages(*args):
    d = _damages(*args)
    for row in d.values():
        for i in range(len(row) - 1, 0, -1):
            row[i] = row[i] / row[i - 1] if row[i - 1] else math.inf
    return d


class _OrderedMap:
    """Mimics a JS Map: insertion order kept, set() on an existing key keeps its
    place, and keys added during iteration are still visited."""

    def __init__(self, items=()):
        self.keys, self.vals = [], {}
        for k, v in items:
            self.set(k, v)

    def set(self, k, v):
        if k not in self.vals:
            self.keys.append(k)
        self.vals[k] = v

    def get(self, k):
        return self.vals.get(k)

    def iter_values(self):
        i = 0
        while i < len(self.keys):
            yield self.vals[self.keys[i]]
            i += 1

    def entries(self):
        return [(k, self.vals[k]) for k in self.keys]

    def __len__(self):
        return len(self.keys)


def plan(apples, milestones, hp, mana, fifteen, max_ascension, starforce,
         mage=False, smite_push=True, use_bt=True, use_gw=True,
         max_ea=0, min_ea=0, lb_max=0, lb_min=0, wt4="None"):
    """Best World Tree builds. Returns a list of {"apples", "day", "builds": [...]}
    for apples .. apples+9; each build has name, levels {node: level}, days, delta."""
    if min_ea > max_ea:
        raise ValueError(f"EA Max < EA Min ({max_ea} < {min_ea})")
    if mage and lb_min > lb_max:
        raise ValueError(f"LB Max < LB Min ({lb_max} < {lb_min})")
    wt4 = WT4_TYPES.get(wt4, 0) if isinstance(wt4, str) else int(wt4)
    lb_max = min(int(lb_max), LB_MAX)
    apples = int(apples)
    if wt4 > 0 and apples < 73:
        raise ValueError("Apples must be >= 73")

    args = (milestones, hp, mana, fifteen, max_ascension, starforce, wt4, lb_max)
    APPLES_ = _apples(lb_max, wt4)
    SIMPLE_APPLES_ = _simple_apples(lb_max, wt4)
    SIMPLE_DAMAGES_ = _simple_damages(*args)
    if not smite_push:
        SIMPLE_DAMAGES_["S"] = [1, 1]
    MAX_APPLES = apples + LOOK

    def sa(h, i):
        row = SIMPLE_APPLES_[h]
        return row[i] if 0 <= i < len(row) else None

    def sd(h, i):
        row = SIMPLE_DAMAGES_[h]
        return row[i] if 0 <= i < len(row) else None

    class Node:
        __slots__ = ("lv", "apples", "damage", "name")

        def __init__(self, other=None):
            if other:
                self.lv = dict(other.lv)
                self.apples, self.damage, self.name = other.apples, other.damage, other.name
            else:
                self.lv = {h: 0 for h in HEADERS + ["PM"]}
                self.apples, self.damage, self.name = 0, 1.0, ""

        def __getitem__(self, h):
            return self.lv[h]

        def increment(self, h):
            n = self.lv[h]
            cost = sa(h, n + 1)
            if not cost:
                return None
            if self.apples + cost >= MAX_APPLES:
                return None
            new = Node(self)
            new.lv[h] += 1
            new.apples += cost
            new.damage *= sd(h, n + 1)
            return new

        def compute_name(self):
            lv, names = self.lv, []
            for h in ("MS", "SM", "BT", "AC", "GW"):
                if lv[h]:
                    names.append(f"{h}{lv[h]}")
            if lv["EA"] > 2:
                names.append(f"EA{lv['EA']}")
            if lv["LB"] > 2:
                names.append(f"LB{lv['LB']}")
            if lv["TS"]:
                names.append(f"TS{lv['TS']}")
            self.name = "+".join(names)

        def days(self):
            return math.log(self.damage) / LN_1066 if self.damage > 0 else -math.inf

    def inc(node, h, times=1):
        for _ in range(times):
            if node is None:
                return None
            node = node.increment(h)
        return node

    dp = [_OrderedMap() for _ in range(MAX_APPLES + 1)]

    def insert(node):
        if node is None:
            return
        node.compute_name()
        dp[node.apples].set(node.name, node)

    start_node = Node()
    start = 0
    if mage and lb_min > 0:
        start_node = start_node.increment("FA")
        start += 1
        for _ in range(lb_min):
            start_node = start_node.increment("LB")
        start += APPLES_["LB"][lb_min]
    if wt4 > 0:
        start_node = inc(inc(inc(start_node, "TE"), "S"), "BT", 3)
        start_node = start_node.increment("PS")
        start += 9
        if min_ea < 0:
            min_ea = 1
    for _ in range(int(min_ea)):
        start_node = start_node.increment("EA")
    start += APPLES_["EA"][int(min_ea)]
    insert(start_node)

    # Phase 1: grow trees along each class's path
    for i in range(start, MAX_APPLES):
        for node in dp[i].iter_values():
            # Defender
            te = node if node["TE"] else node.increment("TE")
            if te is not None:
                if use_bt or max_ea:
                    s = te if te["S"] else te.increment("S")
                    if s is not None:
                        insert(s.increment("BT"))
                        if max_ea > 2:
                            if not s["EA"]:
                                insert(inc(s, "EA", 3))
                            if s["EA"] == 1:
                                insert(inc(s, "EA", 2))
                            if 2 < s["EA"] < max_ea:
                                insert(s.increment("EA"))
                insert(te.increment("AC"))
            # Traveller
            if not mage:
                inn = node if node["IN"] else node.increment("IN")
                if inn and use_gw:
                    pm = inn if inn["PM"] else inn.increment("PM")
                    if pm:
                        at = pm if pm["AT"] else pm.increment("AT")
                        if at:
                            insert(at.increment("GW"))
            # Conjurer
            if mage:
                fa = node if node["FA"] else node.increment("FA")
                if fa is not None:
                    insert(fa.increment("MS"))
                    lb = fa if fa["LB"] else fa.increment("LB")
                    if lb is not None:
                        insert(inc(lb, "LB", 2) if lb["LB"] == 1 else lb.increment("LB"))
                        insert(lb.increment("SM"))
            # Enhancer
            if wt4 > 0:
                insert(node.increment("TS"))

    # Phase 2: prune and fill in the cheap "flat" nodes
    for i in range(start, MAX_APPLES - 1):
        if i > start:
            nodes = sorted(dp[i].entries(), key=lambda kv: -kv[1].damage)
            if not nodes:
                continue
            prev_nodes = dp[i - 1]
            best_damage = nodes[0][1].damage
            first_prev = prev_nodes.entries()[0][1] if len(prev_nodes) else None
            prev_best = first_prev.damage if first_prev else 0
            j = 10
            while j < len(nodes):
                node = nodes[j][1]
                prev = prev_nodes.get(node.name)
                if prev:
                    delta = best_damage / node.damage
                    prev_delta = prev_best / prev.damage
                    if delta / prev_delta > 1.1:     # downward death spiral
                        nodes.pop(j)
                        continue
                j += 1
            dp[i] = _OrderedMap(nodes)

        for node in dp[i].iter_values():
            name = node.name
            prev1 = dp[i - 1].get(name) if i >= 1 else None
            prev2 = dp[i - 2].get(name) if i >= 2 else None
            prev3 = dp[i - 3].get(name) if i >= 3 else None
            best = [None, 0.0]

            def test(n):
                if n is None:
                    return
                if n.damage > best[1]:
                    best[0] = n
                    best[1] = n.damage * 1.001

            def consider(h, base=node):
                if not sd(h, base[h] + 1):
                    return
                test(base.increment(h))

            # Defender
            consider("TE")
            if node["TE"]:
                if not node["BL"]:
                    consider("BL")
                if smite_push and not node["S"]:
                    consider("S")
            if prev1 is not None and prev1["TE"] and prev1["BL"]:
                consider("BL", prev1)
            if node["TE"] and max_ea > 0 and node["BT"] >= 3 and not node["EA"]:
                consider("EA")
            if prev1 is not None and prev1["TE"] and max_ea > 1 and prev1["EA"] == 1:
                consider("EA", prev1)
            # Traveller
            if not mage:
                consider("IN")
                if node["IN"]:
                    if not node["TD"]:
                        consider("TD")
                    # (the original has `addConsideration['AT']` here -- a typo that does nothing)
                    consider("RD")
                    if node["RD"]:
                        consider("AS")
                if prev1 is not None and prev1["IN"]:
                    if prev1["TD"]:
                        consider("TD", prev1)
                    if prev1["PM"] and prev1["AT"] == 1:
                        test(prev1.increment("AT"))
                    if not prev1["PM"]:
                        test(inc(inc(prev1, "PM"), "AT"))
                    if not prev1["RD"]:
                        test(inc(inc(prev1, "RD"), "AS"))
                if prev2 is not None and prev2["IN"]:
                    if prev2["PM"] and not prev2["AT"]:
                        test(inc(prev2, "AT", 2))
                    if not prev2["RD"]:
                        test(inc(inc(prev2, "RD"), "AS", 2))
                if prev3 is not None and prev3["IN"]:
                    if not prev3["PM"]:
                        test(inc(inc(prev3, "PM"), "AT", 2))
                    if not prev3["RD"]:
                        test(inc(inc(prev3, "RD"), "AS", 3))
            # Conjurer
            if mage:
                consider("FA")
                if node["FA"]:
                    if not node["AP"]:
                        consider("AP")
                    if not node["LB"]:
                        consider("LB")
                if prev1 is not None and prev1["FA"]:
                    if prev1["AP"]:
                        consider("AP", prev1)
                    if prev1["LB"] == 1:
                        consider("LB", prev1)
            # Enhancer
            if wt4 > 0:
                consider("PS")
                if mage:
                    if node["TS"] and not node["LS"]:
                        consider("LS")
                    if prev1 is not None and prev1["TS"] and prev1["LS"]:
                        consider("LS", prev1)

            if best[0] is not None:
                insert(best[0])

    results = []
    for k in range(apples, MAX_APPLES):
        values = sorted(dp[k].iter_values(), key=lambda n: -n.damage)
        best_days = values[0].days() if values else None
        builds = []
        for n in values[:10]:
            d = n.days()
            builds.append({"name": n.name or " - ",
                           "levels": {h: n.lv[h] for h in HEADERS if n.lv[h] > 0},
                           "days": d, "delta": d - best_days})
        builds.sort(key=lambda b: b["name"])
        results.append({"apples": k, "day": 9855 + k * 365, "builds": builds})
    return results


# ---------------------------------------------------------------------------
# Exact optimiser
# ---------------------------------------------------------------------------
# The sheet's PLAN_AHEAD (above) is a heuristic that only grows a few paths, so
# it can miss the best build. plan_exact() checks every level combination in
# each World Tree tab (respecting the tree's prerequisites), keeps the best
# days for every apple cost, then combines the tabs. Same costs and damage
# formulas as the sheet, so for any apple count it finds the true maximum.

# Each tab: skills in order, and the prerequisite (skill, min level) of each.
TREES = {
    "Defender": [("TE", None), ("BL", ("TE", 1)), ("S", ("TE", 1)), ("BT", ("S", 1)),
                 ("EA", ("BT", 3)), ("AC", ("TE", 1))],   # EA needs Bloodthirster 3 (sheet rule)
    "Traveller": [("IN", None), ("TD", ("IN", 1)), ("PM", ("IN", 1)), ("AT", ("PM", 1)),
                  ("GW", ("AT", 1)), ("RD", ("IN", 1)), ("AS", ("RD", 1))],
    "Conjurer": [("FA", None), ("AP", ("FA", 1)), ("MS", ("FA", 1)), ("LB", ("FA", 1)), ("SM", ("LB", 1))],
    "Enhancer": [("PS", None), ("TS", ("PS", 1)), ("LS", ("TS", 1))],
}


def _tab_frontier(skills, cost, logd, max_lv, min_lv, budget):
    """Best (days, levels) for every total apple cost within one tab."""
    best = {}

    def rec(i, lv, c, d):
        if i == len(skills):
            if d > best.get(c, (-1.0,))[0]:
                best[c] = (d, dict(lv))
            return
        h, pre = skills[i]
        top = max_lv[h]
        if pre is not None and lv[pre[0]] < pre[1]:
            top = 0
        for n in range(min_lv.get(h, 0), top + 1):
            cc = c + cost[h][n]
            if cc > budget:
                break
            lv[h] = n
            rec(i + 1, lv, cc, d + logd[h][n])
        lv[h] = 0

    rec(0, {h: 0 for h, _ in skills}, 0, 0.0)
    return best


def plan_exact(apples, milestones, hp, mana, fifteen, max_ascension, starforce,
               mage=False, smite_push=True, use_bt=True, use_gw=True,
               max_ea=0, min_ea=0, lb_max=0, lb_min=0, wt4="None", ahead=LOOK):
    """Absolute best build for apples, apples+1, ... (same output shape as plan())."""
    if min_ea > max_ea:
        raise ValueError(f"EA Max < EA Min ({max_ea} < {min_ea})")
    if mage and lb_min > lb_max:
        raise ValueError(f"LB Max < LB Min ({lb_max} < {lb_min})")
    wt4 = WT4_TYPES.get(wt4, 0) if isinstance(wt4, str) else int(wt4)
    lb_max = min(int(lb_max), LB_MAX)
    apples = int(apples)
    budget = apples + ahead - 1

    cost = _apples(lb_max, wt4)
    dmg = _damages(milestones, hp, mana, fifteen, max_ascension, starforce, wt4, lb_max)
    if not smite_push:
        dmg["S"] = [1, 1]
    logd = {h: [math.log(v) / LN_1066 if v > 0 else -math.inf for v in row] for h, row in dmg.items()}
    max_lv = {h: len(cost[h]) - 1 for h in cost}
    min_lv = {}
    if not use_bt:
        max_lv["BT"] = 0
    if not use_gw:
        max_lv["GW"] = 0
    max_lv["EA"] = min(max_lv["EA"], int(max_ea))
    min_lv["EA"] = int(min_ea)
    if mage:
        min_lv["LB"] = int(lb_min)
    if wt4 > 0:      # the sheet's Enhancer start: TE, S, BT3, PS
        for h, n in (("TE", 1), ("S", 1), ("BT", 3), ("PS", 1)):
            min_lv[h] = max(min_lv.get(h, 0), n)
    if not (wt4 > 1 and mage):
        max_lv["LS"] = 0

    # Hero (Traveller) and spell (Conjurer) multipliers boost different things,
    # so like the sheet, Mage mode swaps Traveller for Conjurer.
    tabs = ["Defender", "Conjurer" if mage else "Traveller"] + (["Enhancer"] if wt4 > 0 else [])

    total = {0: (0.0, {})}
    for tab in tabs:
        front = _tab_frontier(TREES[tab], cost, logd, max_lv, min_lv, budget)
        new = {}
        for c1, (d1, l1) in total.items():
            for c2, (d2, l2) in front.items():
                c = c1 + c2
                if c <= budget and d1 + d2 > new.get(c, (-math.inf,))[0]:
                    new[c] = (d1 + d2, {**l1, **l2})
        total = new

    results = []
    best = (-math.inf, {})
    for k in range(budget + 1):
        if k in total and total[k][0] > best[0]:
            best = total[k]
        if k >= apples:
            levels = {h: n for h, n in best[1].items() if n > 0}
            order = HEADERS[:2] + ["PM"] + HEADERS[2:]
            builds = [{"name": build_name(levels), "levels": {h: levels[h] for h in order if h in levels},
                       "days": best[0], "delta": 0.0}] if best[1] else []
            results.append({"apples": k, "day": 9855 + k * 365, "builds": builds})
    return results
